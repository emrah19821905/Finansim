package com.example

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.model.AccountType
import com.example.model.BankAccount
import com.example.model.BillReminder
import com.example.model.BudgetGoal
import com.example.model.CategoryBreakdownItem
import com.example.model.CustomCategory
import com.example.model.ExpenseCategory
import com.example.model.FinancialTransaction
import com.example.model.MonthlyChartPoint
import com.example.model.TransactionType
import com.example.model.VaultSnapshotPayload
import com.example.model.formatCompactTry
import com.example.model.formatTry
import com.example.model.safeFiniteDouble
import com.example.model.safeOpaqueColor
import com.example.security.VaultCryptoManager
import com.example.ui.components.TrendChartMode
import com.example.ui.components.VicoCategoryDistributionChart
import com.example.ui.components.VicoMonthlyTrendChart
import com.example.ui.theme.FinansimTheme
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class FinansimLogicTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `vault crypto pin wrap unwrap and encryption roundtrip`() {
        val userId = "user_test_123"
        val pin = "147258"
        val salt = VaultCryptoManager.generateRandomSaltBase64()
        val pinHash = VaultCryptoManager.hashPin(pin, salt)

        assertTrue(VaultCryptoManager.verifyPin(pin, salt, pinHash))
        assertFalse(VaultCryptoManager.verifyPin("000000", salt, pinHash))

        val vaultKey = VaultCryptoManager.generateVaultDataKey()
        val wrapped = VaultCryptoManager.wrapVaultKeyWithPin(vaultKey, pin, userId, salt)
        val check = VaultCryptoManager.createVerificationCheck(vaultKey)

        val unwrapped = VaultCryptoManager.unwrapVaultKeyWithPin(wrapped, pin, userId, salt)
        assertTrue(VaultCryptoManager.verifyVaultKey(unwrapped, check))
        assertEquals(
            VaultCryptoManager.keyFingerprint(vaultKey),
            VaultCryptoManager.keyFingerprint(unwrapped)
        )

        val secretPayload = """{"title":"Migros","amount":450.75}"""
        val encrypted = VaultCryptoManager.encryptString(secretPayload, vaultKey)
        val decrypted = VaultCryptoManager.decryptString(encrypted, unwrapped)
        assertEquals(secretPayload, decrypted)
    }

    @Test
    fun `finance models sanitize NaN and transparent colors cleanly`() {
        assertEquals(0.0, safeFiniteDouble(Double.NaN), 0.0001)
        assertEquals(0.0, safeFiniteDouble(Double.POSITIVE_INFINITY), 0.0001)
        assertEquals(42.5, safeFiniteDouble(42.5), 0.0001)

        val fallback = safeOpaqueColor(0L, 0xFF0F6B4E)
        assertEquals(Color(0xFF0F6B4E), fallback)

        val alphaFixed = safeOpaqueColor(0x0016A37A)
        assertEquals(Color(0xFF16A37A), alphaFixed)

        val badAccount = BankAccount(
            bankName = "Ziraat",
            accountName = "Vadesiz",
            accountType = AccountType.CHECKING,
            ibanSuffix = "1234",
            balance = Double.NaN,
            colorHex = 0L
        )
        val jsonStr = badAccount.toJson().toString()
        val restored = BankAccount.fromJson(badAccount.id, JSONObject(jsonStr))
        assertEquals(0.0, restored.balance, 0.0001)
        assertEquals(Color(0xFF0F6B4E), restored.cardColor)
        assertTrue(formatTry(Double.NaN).contains("0"))
        assertTrue(formatCompactTry(Double.POSITIVE_INFINITY).contains("0"))
    }

    @Test
    fun `vault snapshot json roundtrip preserves all collections`() {
        val snapshot = VaultSnapshotPayload(
            accounts = listOf(BankAccount(id = "acc1", bankName = "Garanti", accountName = "Maaş", balance = 12500.0)),
            transactions = listOf(
                FinancialTransaction(
                    id = "tx1",
                    title = "Market",
                    amount = 640.5,
                    type = TransactionType.EXPENSE,
                    category = ExpenseCategory.MARKET
                )
            ),
            budgets = listOf(BudgetGoal(id = "b1", category = ExpenseCategory.MARKET, monthlyLimit = 4000.0)),
            bills = listOf(BillReminder(id = "bill1", title = "İnternet", amount = 599.0, dueDayOfMonth = 12)),
            customCategories = listOf(CustomCategory(id = "cat1", name = "Kahve", iconKey = "CAFE", colorHex = 0xFF7C3AED))
        )

        val parsed = VaultSnapshotPayload.fromJsonString(snapshot.toJsonString())
        assertEquals(1, parsed.accounts.size)
        assertEquals(1, parsed.transactions.size)
        assertEquals(1, parsed.budgets.size)
        assertEquals(1, parsed.bills.size)
        assertEquals(1, parsed.customCategories.size)
        assertEquals("Kahve", parsed.customCategories.first().name)
    }

    @Test
    fun `vico charts render and toggle modes without crashing`() {
        val modeState = androidx.compose.runtime.mutableStateOf(TrendChartMode.AREA_LINE)
        val points = listOf(
            MonthlyChartPoint("Oca", 25000.0, 14000.0),
            MonthlyChartPoint("Şub", 26000.0, 15500.0),
            MonthlyChartPoint("Mar", Double.NaN, 12000.0)
        )
        val categories = listOf(
            CategoryBreakdownItem(ExpenseCategory.MARKET, 4500.0, 0.6f),
            CategoryBreakdownItem(ExpenseCategory.FATURA, 3000.0, 0.4f)
        )

        composeRule.setContent {
            FinansimTheme {
                androidx.compose.foundation.layout.Column {
                    VicoMonthlyTrendChart(points = points, mode = modeState.value)
                    VicoCategoryDistributionChart(items = categories)
                }
            }
        }
        composeRule.waitForIdle()

        composeRule.runOnUiThread {
            modeState.value = TrendChartMode.GROUPED_COLUMNS
        }
        composeRule.waitForIdle()

        composeRule.runOnUiThread {
            modeState.value = TrendChartMode.AREA_LINE
        }
        composeRule.waitForIdle()
    }
}
