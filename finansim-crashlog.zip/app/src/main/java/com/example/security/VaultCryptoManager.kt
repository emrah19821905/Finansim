package com.example.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

data class EncryptedBlob(
    val ciphertextBase64: String,
    val ivBase64: String
)

object VaultCryptoManager {
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEYSTORE_MASTER_ALIAS = "finansim_device_master_aes256"
    private const val AES_GCM_TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_TAG_LENGTH_BITS = 128
    private const val GCM_IV_LENGTH_BYTES = 12
    private const val PBKDF2_ALGORITHM = "PBKDF2WithHmacSHA256"
    private const val PBKDF2_ITERATIONS = 100_000
    private const val KEY_SIZE_BITS = 256
    private const val VERIFICATION_MARKER = "FINANSIM_VAULT_VERIFIED_V1"

    private val secureRandom = SecureRandom()

    fun generateRandomSaltBase64(): String {
        val salt = ByteArray(16)
        secureRandom.nextBytes(salt)
        return Base64.encodeToString(salt, Base64.NO_WRAP)
    }

    fun generateVaultDataKey(): SecretKey {
        val keyBytes = ByteArray(32)
        secureRandom.nextBytes(keyBytes)
        return SecretKeySpec(keyBytes, "AES")
    }

    fun hashPin(pin: String, saltBase64: String): String {
        val saltBytes = Base64.decode(saltBase64, Base64.NO_WRAP)
        val spec = PBEKeySpec(pin.toCharArray(), saltBytes, PBKDF2_ITERATIONS, KEY_SIZE_BITS)
        val factory = SecretKeyFactory.getInstance(PBKDF2_ALGORITHM)
        val hash = factory.generateSecret(spec).encoded
        return Base64.encodeToString(hash, Base64.NO_WRAP)
    }

    fun verifyPin(pin: String, saltBase64: String, expectedHashBase64: String): Boolean {
        val candidate = hashPin(pin, saltBase64)
        return MessageDigest.isEqual(
            candidate.toByteArray(StandardCharsets.UTF_8),
            expectedHashBase64.toByteArray(StandardCharsets.UTF_8)
        )
    }

    fun derivePinKek(pin: String, userId: String, saltBase64: String): SecretKey {
        val saltBytes = Base64.decode(saltBase64, Base64.NO_WRAP) + userId.toByteArray(StandardCharsets.UTF_8)
        val spec = PBEKeySpec(pin.toCharArray(), saltBytes, PBKDF2_ITERATIONS, KEY_SIZE_BITS)
        val factory = SecretKeyFactory.getInstance(PBKDF2_ALGORITHM)
        val derived = factory.generateSecret(spec).encoded
        return SecretKeySpec(derived, "AES")
    }

    fun wrapVaultKeyWithPin(vaultKey: SecretKey, pin: String, userId: String, saltBase64: String): EncryptedBlob {
        val kek = derivePinKek(pin, userId, saltBase64)
        return encryptBytes(vaultKey.encoded, kek)
    }

    fun unwrapVaultKeyWithPin(
        wrappedBlob: EncryptedBlob,
        pin: String,
        userId: String,
        saltBase64: String
    ): SecretKey {
        val kek = derivePinKek(pin, userId, saltBase64)
        val keyBytes = decryptBytes(wrappedBlob, kek)
        return SecretKeySpec(keyBytes, "AES")
    }

    fun wrapVaultKeyWithDeviceKeystore(vaultKey: SecretKey): EncryptedBlob {
        return try {
            val masterKey = getOrCreateDeviceKeystoreKey()
            encryptBytes(vaultKey.encoded, masterKey)
        } catch (_: Exception) {
            deleteDeviceKeystoreKey()
            val regenerated = getOrCreateDeviceKeystoreKey()
            encryptBytes(vaultKey.encoded, regenerated)
        }
    }

    fun unwrapVaultKeyWithDeviceKeystore(wrappedBlob: EncryptedBlob): SecretKey {
        val masterKey = getOrCreateDeviceKeystoreKey()
        val keyBytes = decryptBytes(wrappedBlob, masterKey)
        return SecretKeySpec(keyBytes, "AES")
    }

    fun createVerificationCheck(vaultKey: SecretKey): EncryptedBlob {
        return encryptString(VERIFICATION_MARKER, vaultKey)
    }

    fun verifyVaultKey(vaultKey: SecretKey, checkBlob: EncryptedBlob): Boolean {
        return try {
            decryptString(checkBlob, vaultKey) == VERIFICATION_MARKER
        } catch (_: Exception) {
            false
        }
    }

    fun encryptString(plaintext: String, key: SecretKey): EncryptedBlob {
        return encryptBytes(plaintext.toByteArray(StandardCharsets.UTF_8), key)
    }

    fun decryptString(blob: EncryptedBlob, key: SecretKey): String {
        val bytes = decryptBytes(blob, key)
        return String(bytes, StandardCharsets.UTF_8)
    }

    fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray(StandardCharsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun keyFingerprint(key: SecretKey): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(key.encoded)
        return digest.take(6).joinToString(":") { "%02X".format(it) }
    }

    private fun encryptBytes(plainBytes: ByteArray, key: SecretKey): EncryptedBlob {
        val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val cipherBytes = cipher.doFinal(plainBytes)
        val ivBytes = cipher.iv
        return EncryptedBlob(
            ciphertextBase64 = Base64.encodeToString(cipherBytes, Base64.NO_WRAP),
            ivBase64 = Base64.encodeToString(ivBytes, Base64.NO_WRAP)
        )
    }

    private fun decryptBytes(blob: EncryptedBlob, key: SecretKey): ByteArray {
        val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
        val ivBytes = Base64.decode(blob.ivBase64, Base64.NO_WRAP)
        val cipherBytes = Base64.decode(blob.ciphertextBase64, Base64.NO_WRAP)
        val spec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, ivBytes)
        cipher.init(Cipher.DECRYPT_MODE, key, spec)
        return cipher.doFinal(cipherBytes)
    }

    private fun deleteDeviceKeystoreKey() {
        try {
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            if (keyStore.containsAlias(KEYSTORE_MASTER_ALIAS)) {
                keyStore.deleteEntry(KEYSTORE_MASTER_ALIAS)
            }
        } catch (_: Exception) {
            // Ignore cleanup errors
        }
    }

    private fun getOrCreateDeviceKeystoreKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existingKey = runCatching {
            keyStore.getKey(KEYSTORE_MASTER_ALIAS, null) as? SecretKey
        }.getOrNull()
        if (existingKey != null) return existingKey

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEYSTORE_MASTER_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(KEY_SIZE_BITS)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }
}
