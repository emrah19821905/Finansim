package com.example.security

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.crypto.SecretKey

private val Context.vaultDataStore by preferencesDataStore(name = "finansim_vault_prefs")

class VaultSessionStore(private val context: Context) {
    private fun wrappedKeyKey(uid: String) = stringPreferencesKey("wrapped_key_$uid")
    private fun wrappedKeyIvKey(uid: String) = stringPreferencesKey("wrapped_key_iv_$uid")
    private fun biometricLocalKey(uid: String) = booleanPreferencesKey("biometric_local_$uid")
    private val reminderSummaryKey = stringPreferencesKey("bill_reminder_cache")

    suspend fun saveDeviceWrappedVaultKey(uid: String, vaultKey: SecretKey): Boolean {
        return runCatching {
            val wrapped = VaultCryptoManager.wrapVaultKeyWithDeviceKeystore(vaultKey)
            context.vaultDataStore.edit { prefs ->
                prefs[wrappedKeyKey(uid)] = wrapped.ciphertextBase64
                prefs[wrappedKeyIvKey(uid)] = wrapped.ivBase64
            }
            true
        }.getOrElse {
            false
        }
    }

    suspend fun loadDeviceWrappedVaultKey(uid: String): SecretKey? {
        return try {
            val prefs = context.vaultDataStore.data.first()
            val cipher = prefs[wrappedKeyKey(uid)] ?: return null
            val iv = prefs[wrappedKeyIvKey(uid)] ?: return null
            VaultCryptoManager.unwrapVaultKeyWithDeviceKeystore(EncryptedBlob(cipher, iv))
        } catch (_: Exception) {
            null
        }
    }

    suspend fun setBiometricLocalEnabled(uid: String, enabled: Boolean) {
        context.vaultDataStore.edit { prefs ->
            prefs[biometricLocalKey(uid)] = enabled
        }
    }

    suspend fun isBiometricLocalEnabled(uid: String): Boolean {
        return context.vaultDataStore.data.map { it[biometricLocalKey(uid)] ?: false }.first()
    }

    suspend fun saveReminderSummaryCache(summary: String) {
        context.vaultDataStore.edit { prefs ->
            prefs[reminderSummaryKey] = summary
        }
    }

    suspend fun loadReminderSummaryCache(): String? {
        return context.vaultDataStore.data.map { it[reminderSummaryKey] }.first()
    }

    suspend fun clearUserSession(uid: String) {
        context.vaultDataStore.edit { prefs ->
            prefs.remove(wrappedKeyKey(uid))
            prefs.remove(wrappedKeyIvKey(uid))
            prefs.remove(biometricLocalKey(uid))
        }
    }
}
