package com.example.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AiFinanceRepository
import com.example.data.FinanceVaultRepository
import com.example.model.AccountType
import com.example.model.ActivityAlert
import com.example.model.AlertSeverity
import com.example.model.AiBudgetAdviceResponse
import com.example.model.AiCategoryPrediction
import com.example.model.BackupSummary
import com.example.model.BankAccount
import com.example.model.BillReminder
import com.example.model.BudgetGoal
import com.example.model.CategoryBreakdownItem
import com.example.model.CustomCategory
import com.example.model.ExpenseCategory
import com.example.model.FinancialTransaction
import com.example.model.MonthlyChartPoint
import com.example.model.PdfStatementMetadata
import com.example.model.SpendingHabitProfile
import com.example.model.StatementParseResult
import com.example.model.TransactionType
import com.example.model.UiState
import com.example.model.UserVaultProfile
import com.example.model.VaultSnapshotPayload
import com.example.model.formatDateShort
import com.example.model.formatTry
import com.example.notifications.BillReminderWorker
import com.example.notifications.FinanceNotificationHelper
import com.example.security.VaultCryptoManager
import com.example.security.VaultSessionStore
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.crypto.SecretKey

data class VaultDashboardMetrics(
    val totalBankBalance: Double = 0.0,
    val monthlyIncome: Double = 0.0,
    val monthlyExpense: Double = 0.0,
    val lastMonthExpense: Double = 0.0,
    val sixMonthExpense: Double = 0.0,
    val monthOverMonthSpendingDeltaPct: Int? = null,
    val netMonthlyCashflow: Double = 0.0,
    val monthlyTrend: List<MonthlyChartPoint> = emptyList(),
    val monthlyTrend12Months: List<MonthlyChartPoint> = emptyList(),
    val categoryBreakdown: List<CategoryBreakdownItem> = emptyList(),
    val lastMonthCategoryBreakdown: List<CategoryBreakdownItem> = emptyList(),
    val sixMonthCategoryBreakdown: List<CategoryBreakdownItem> = emptyList(),
    val categorySpendingThisMonth: Map<ExpenseCategory, Double> = emptyMap(),
    val upcomingBillsCount: Int = 0,
    val unreadAlertsCount: Int = 0
)

data class ChatMessage(
    val id: String,
    val isFromUser: Boolean,
    val text: String
)

class FinanceViewModel(
    private val appContext: Context,
    private val vaultRepo: FinanceVaultRepository,
    private val aiRepo: AiFinanceRepository,
    private val sessionStore: VaultSessionStore,
    private val userId: String,
    private val vaultKey: SecretKey
) : ViewModel() {

    val keyFingerprint: String = VaultCryptoManager.keyFingerprint(vaultKey)

    private val _snackbarMessage = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val snackbarMessage = _snackbarMessage.asSharedFlow()

    val profileState: StateFlow<UiState<UserVaultProfile?>> =
        vaultRepo.observeUserVaultProfile(userId)
            .map<UserVaultProfile?, UiState<UserVaultProfile?>> { UiState.Success(it) }
            .unwrapFirestoreErrors("Profil yüklenemedi")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val accountsState: StateFlow<UiState<List<BankAccount>>> =
        vaultRepo.observeAccounts(userId, vaultKey)
            .map<List<BankAccount>, UiState<List<BankAccount>>> { list ->
                UiState.Success(list.sortedByDescending { it.balance })
            }
            .unwrapFirestoreErrors("Banka hesapları yüklenemedi")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val transactionsState: StateFlow<UiState<List<FinancialTransaction>>> =
        vaultRepo.observeTransactions(userId, vaultKey)
            .map<List<FinancialTransaction>, UiState<List<FinancialTransaction>>> { list ->
                UiState.Success(list.sortedByDescending { it.dateMillis })
            }
            .unwrapFirestoreErrors("İşlemler yüklenemedi")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val budgetsState: StateFlow<UiState<List<BudgetGoal>>> =
        vaultRepo.observeBudgets(userId, vaultKey)
            .map<List<BudgetGoal>, UiState<List<BudgetGoal>>> { list ->
                UiState.Success(list.sortedBy { it.category.labelTr })
            }
            .unwrapFirestoreErrors("Bütçe hedefleri yüklenemedi")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val billsState: StateFlow<UiState<List<BillReminder>>> =
        vaultRepo.observeBills(userId, vaultKey)
            .map<List<BillReminder>, UiState<List<BillReminder>>> { list ->
                val sorted = list.sortedWith(compareBy<BillReminder> { it.paidForCurrentMonth }.thenBy { it.dueDateMillis })
                cacheBillRemindersForWorker(sorted)
                UiState.Success(sorted)
            }
            .unwrapFirestoreErrors("Fatura takvimi yüklenemedi")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val alertsState: StateFlow<UiState<List<ActivityAlert>>> =
        vaultRepo.observeAlerts(userId, vaultKey)
            .map<List<ActivityAlert>, UiState<List<ActivityAlert>>> { list ->
                UiState.Success(list.sortedByDescending { it.timestampMillis })
            }
            .unwrapFirestoreErrors("Bildirim geçmişi yüklenemedi")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val categoriesState: StateFlow<UiState<List<CustomCategory>>> =
        vaultRepo.observeCategories(userId, vaultKey)
            .map<List<CustomCategory>, UiState<List<CustomCategory>>> { list ->
                val trLocale = Locale.forLanguageTag("tr-TR")
                UiState.Success(
                    list.sortedWith(
                        compareBy<CustomCategory> { it.forIncome }
                            .thenBy { it.name.lowercase(trLocale) }
                    )
                )
            }
            .unwrapFirestoreErrors("Kategoriler yüklenemedi")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val backupsState: StateFlow<UiState<List<BackupSummary>>> =
        vaultRepo.observeBackups(userId)
            .map<List<BackupSummary>, UiState<List<BackupSummary>>> { UiState.Success(it) }
            .unwrapFirestoreErrors("Yedekler yüklenemedi")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val dashboardMetrics: StateFlow<VaultDashboardMetrics> = combine(
        accountsState,
        transactionsState,
        billsState,
        alertsState,
        categoriesState
    ) { accState, txState, billState, alertState, catState ->
        val accounts = (accState as? UiState.Success)?.data ?: emptyList()
        val transactions = (txState as? UiState.Success)?.data ?: emptyList()
        val bills = (billState as? UiState.Success)?.data ?: emptyList()
        val alerts = (alertState as? UiState.Success)?.data ?: emptyList()
        val customCategories = (catState as? UiState.Success)?.data ?: emptyList()

        computeMetrics(accounts, transactions, bills, alerts, customCategories)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), VaultDashboardMetrics())

    val spendingHabitProfile: StateFlow<SpendingHabitProfile> = combine(
        transactionsState,
        budgetsState,
        dashboardMetrics
    ) { txState, budgetState, metrics ->
        val transactions = (txState as? UiState.Success)?.data ?: emptyList()
        val budgets = (budgetState as? UiState.Success)?.data ?: emptyList()
        computeHabitProfile(transactions, budgets, metrics)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), SpendingHabitProfile())

    // AI States
    private val _aiAdviceState = MutableStateFlow<UiState<AiBudgetAdviceResponse>>(UiState.Idle)
    val aiAdviceState: StateFlow<UiState<AiBudgetAdviceResponse>> = _aiAdviceState.asStateFlow()

    private val _aiCategorizationState = MutableStateFlow<UiState<List<AiCategoryPrediction>>>(UiState.Idle)
    val aiCategorizationState: StateFlow<UiState<List<AiCategoryPrediction>>> = _aiCategorizationState.asStateFlow()

    private val _coachMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val coachMessages: StateFlow<List<ChatMessage>> = _coachMessages.asStateFlow()

    private val _isCoachStreaming = MutableStateFlow(false)
    val isCoachStreaming: StateFlow<Boolean> = _isCoachStreaming.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _statementImportState = MutableStateFlow<UiState<StatementParseResult>>(UiState.Idle)
    val statementImportState: StateFlow<UiState<StatementParseResult>> = _statementImportState.asStateFlow()

    init {
        BillReminderWorker.schedulePeriodicCheck(appContext)
    }

    // --- Bank Account Actions ---
    fun addOrUpdateAccount(account: BankAccount, isNew: Boolean) {
        viewModelScope.launch {
            val res = vaultRepo.saveAccount(userId, account, vaultKey, isNew)
            res.fold(
                onSuccess = {
                    updateLastSync("Hesap şifrelenerek kaydedildi")
                    _snackbarMessage.emit("${account.bankName} hesabı kaydedildi.")
                },
                onFailure = { _snackbarMessage.emit(it.localizedMessage ?: "Hesap kaydedilemedi.") }
            )
        }
    }

    fun deleteAccount(accountId: String) {
        viewModelScope.launch {
            vaultRepo.deleteAccount(userId, accountId).fold(
                onSuccess = { _snackbarMessage.emit("Hesap silindi.") },
                onFailure = { _snackbarMessage.emit(it.localizedMessage ?: "Hesap silinemedi.") }
            )
        }
    }

    fun transferBetweenAccounts(from: BankAccount, to: BankAccount, amount: Double, note: String) {
        if (amount <= 0.0 || from.id == to.id) return
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val updatedFrom = from.copy(balance = from.balance - amount, updatedAtMillis = now)
            val updatedTo = to.copy(balance = to.balance + amount, updatedAtMillis = now)
            val fromRes = vaultRepo.saveAccount(userId, updatedFrom, vaultKey, isNew = false)
            if (fromRes.isFailure) {
                _snackbarMessage.emit(fromRes.exceptionOrNull()?.localizedMessage ?: "Transfer başarısız oldu.")
                return@launch
            }
            val toRes = vaultRepo.saveAccount(userId, updatedTo, vaultKey, isNew = false)
            if (toRes.isFailure) {
                // Roll back source account balance if destination update fails
                vaultRepo.saveAccount(userId, from.copy(updatedAtMillis = System.currentTimeMillis()), vaultKey, isNew = false)
                _snackbarMessage.emit(toRes.exceptionOrNull()?.localizedMessage ?: "Alıcı hesap güncellenemedi, transfer geri alındı.")
                return@launch
            }
            val alert = ActivityAlert(
                title = "Hesaplar Arası Transfer",
                message = "${from.bankName} → ${to.bankName}: ${formatTry(amount)}${if (note.isNotBlank()) " ($note)" else ""}",
                severity = AlertSeverity.INFO
            )
            vaultRepo.saveAlert(userId, alert, vaultKey, isNew = true)
            updateLastSync("Hesaplar arası transfer")
            _snackbarMessage.emit("${formatTry(amount)} transfer tamamlandı.")
        }
    }

    // --- Transaction Actions ---
    fun addTransaction(tx: FinancialTransaction) {
        viewModelScope.launch {
            val res = vaultRepo.saveTransaction(userId, tx, vaultKey, isNew = true)
            res.fold(
                onSuccess = {
                    // Update linked bank account balance if selected
                    val accounts = (accountsState.value as? UiState.Success)?.data ?: emptyList()
                    val linkedAccount = accounts.firstOrNull { it.id == tx.accountId }
                    if (linkedAccount != null) {
                        val delta = if (tx.type == TransactionType.INCOME) tx.amount else -tx.amount
                        val updatedAcc = linkedAccount.copy(
                            balance = linkedAccount.balance + delta,
                            updatedAtMillis = System.currentTimeMillis()
                        )
                        vaultRepo.saveAccount(userId, updatedAcc, vaultKey, isNew = false)
                    }

                    // Instant notification & alert log
                    triggerInstantTransactionAlerts(tx, linkedAccount?.bankName ?: tx.accountName.ifBlank { "Genel" })
                    updateLastSync("İşlem şifrelendi ve senkronize edildi")
                    _snackbarMessage.emit("${tx.title} kaydedildi.")
                },
                onFailure = { _snackbarMessage.emit(it.localizedMessage ?: "İşlem kaydedilemedi.") }
            )
        }
    }

    fun updateTransaction(tx: FinancialTransaction) {
        viewModelScope.launch {
            val oldTx = (transactionsState.value as? UiState.Success)?.data?.firstOrNull { it.id == tx.id }
            vaultRepo.saveTransaction(userId, tx, vaultKey, isNew = false).fold(
                onSuccess = {
                    if (oldTx != null) {
                        val accounts = (accountsState.value as? UiState.Success)?.data ?: emptyList()
                        val oldSigned = if (oldTx.type == TransactionType.INCOME) oldTx.amount else -oldTx.amount
                        val newSigned = if (tx.type == TransactionType.INCOME) tx.amount else -tx.amount
                        if (oldTx.accountId == tx.accountId) {
                            val diff = newSigned - oldSigned
                            if (diff != 0.0) {
                                accounts.firstOrNull { it.id == tx.accountId }?.let { acc ->
                                    vaultRepo.saveAccount(
                                        userId,
                                        acc.copy(balance = acc.balance + diff, updatedAtMillis = System.currentTimeMillis()),
                                        vaultKey,
                                        isNew = false
                                    )
                                }
                            }
                        } else {
                            accounts.firstOrNull { it.id == oldTx.accountId }?.let { oldAcc ->
                                vaultRepo.saveAccount(
                                    userId,
                                    oldAcc.copy(balance = oldAcc.balance - oldSigned, updatedAtMillis = System.currentTimeMillis()),
                                    vaultKey,
                                    isNew = false
                                )
                            }
                            accounts.firstOrNull { it.id == tx.accountId }?.let { newAcc ->
                                vaultRepo.saveAccount(
                                    userId,
                                    newAcc.copy(balance = newAcc.balance + newSigned, updatedAtMillis = System.currentTimeMillis()),
                                    vaultKey,
                                    isNew = false
                                )
                            }
                        }
                    }
                    updateLastSync("İşlem güncellendi")
                    _snackbarMessage.emit("İşlem güncellendi.")
                },
                onFailure = { _snackbarMessage.emit(it.localizedMessage ?: "İşlem güncellenemedi.") }
            )
        }
    }

    fun deleteTransaction(tx: FinancialTransaction) {
        viewModelScope.launch {
            vaultRepo.deleteTransaction(userId, tx.id).fold(
                onSuccess = {
                    val accounts = (accountsState.value as? UiState.Success)?.data ?: emptyList()
                    val linkedAccount = accounts.firstOrNull { it.id == tx.accountId }
                    if (linkedAccount != null) {
                        val reverseDelta = if (tx.type == TransactionType.INCOME) -tx.amount else tx.amount
                        vaultRepo.saveAccount(
                            userId,
                            linkedAccount.copy(
                                balance = linkedAccount.balance + reverseDelta,
                                updatedAtMillis = System.currentTimeMillis()
                            ),
                            vaultKey,
                            isNew = false
                        )
                    }
                    _snackbarMessage.emit("İşlem silindi.")
                },
                onFailure = { _snackbarMessage.emit(it.localizedMessage ?: "İşlem silinemedi.") }
            )
        }
    }

    // --- Custom Category Management (Firestore Encrypted) ---
    fun addCustomCategory(
        name: String,
        iconKey: String,
        colorHex: Long,
        forIncome: Boolean
    ) {
        val cleaned = name.trim().take(40)
        if (cleaned.isBlank()) {
            viewModelScope.launch { _snackbarMessage.emit("Kategori adı boş olamaz.") }
            return
        }
        val existing = (categoriesState.value as? UiState.Success)?.data.orEmpty()
        val trLocale = Locale.forLanguageTag("tr-TR")
        val duplicateCustom = existing.any {
            it.forIncome == forIncome && it.name.trim().lowercase(trLocale) == cleaned.lowercase(trLocale)
        }
        val duplicateBuiltIn = ExpenseCategory.entries.any {
            it.labelTr.lowercase(trLocale) == cleaned.lowercase(trLocale)
        }
        if (duplicateCustom || duplicateBuiltIn) {
            viewModelScope.launch { _snackbarMessage.emit("\"$cleaned\" adlı bir kategori zaten mevcut.") }
            return
        }

        val category = CustomCategory(
            name = cleaned,
            iconKey = iconKey,
            colorHex = colorHex,
            forIncome = forIncome,
            updatedAtMillis = System.currentTimeMillis()
        )
        viewModelScope.launch {
            vaultRepo.saveCategory(userId, category, vaultKey, isNew = true).fold(
                onSuccess = {
                    updateLastSync("Özel kategori eklendi")
                    _snackbarMessage.emit("\"${category.name}\" kategorisi buluta eklendi.")
                },
                onFailure = {
                    _snackbarMessage.emit(it.localizedMessage ?: "Kategori eklenemedi.")
                }
            )
        }
    }

    fun updateCustomCategory(updated: CustomCategory) {
        val cleanedName = updated.name.trim().take(40)
        if (cleanedName.isBlank()) {
            viewModelScope.launch { _snackbarMessage.emit("Kategori adı boş olamaz.") }
            return
        }
        val existing = (categoriesState.value as? UiState.Success)?.data.orEmpty()
        val trLocale = Locale.forLanguageTag("tr-TR")
        val duplicate = existing.any {
            it.id != updated.id &&
                it.forIncome == updated.forIncome &&
                it.name.trim().lowercase(trLocale) == cleanedName.lowercase(trLocale)
        }
        if (duplicate) {
            viewModelScope.launch { _snackbarMessage.emit("\"$cleanedName\" adlı başka bir kategori zaten var.") }
            return
        }

        val cleanCategory = updated.copy(
            name = cleanedName,
            updatedAtMillis = System.currentTimeMillis()
        )
        viewModelScope.launch {
            vaultRepo.saveCategory(userId, cleanCategory, vaultKey, isNew = false).fold(
                onSuccess = {
                    val txs = (transactionsState.value as? UiState.Success)?.data.orEmpty()
                    txs.filter { it.customCategoryId == cleanCategory.id }.forEach { tx ->
                        vaultRepo.saveTransaction(
                            userId,
                            tx.copy(
                                customCategoryName = cleanCategory.name,
                                customCategoryColorHex = cleanCategory.colorHex,
                                customCategoryIconKey = cleanCategory.iconKey
                            ),
                            vaultKey,
                            isNew = false
                        )
                    }
                    updateLastSync("Özel kategori güncellendi")
                    _snackbarMessage.emit("\"${cleanCategory.name}\" kategorisi güncellendi.")
                },
                onFailure = {
                    _snackbarMessage.emit(it.localizedMessage ?: "Kategori güncellenemedi.")
                }
            )
        }
    }

    fun deleteCustomCategory(category: CustomCategory) {
        viewModelScope.launch {
            vaultRepo.deleteCategory(userId, category.id).fold(
                onSuccess = {
                    val txs = (transactionsState.value as? UiState.Success)?.data.orEmpty()
                    txs.filter { it.customCategoryId == category.id }.forEach { tx ->
                        vaultRepo.saveTransaction(
                            userId,
                            tx.copy(
                                customCategoryId = "",
                                customCategoryName = "",
                                customCategoryColorHex = 0L,
                                customCategoryIconKey = ""
                            ),
                            vaultKey,
                            isNew = false
                        )
                    }
                    updateLastSync("Özel kategori silindi")
                    _snackbarMessage.emit("\"${category.name}\" kategorisi silindi.")
                },
                onFailure = {
                    _snackbarMessage.emit(it.localizedMessage ?: "Kategori silinemedi.")
                }
            )
        }
    }

    // --- Budget Goals ---
    fun saveBudgetGoal(category: ExpenseCategory, monthlyLimit: Double, aiRecommended: Boolean = false) {
        viewModelScope.launch {
            val existing = (budgetsState.value as? UiState.Success)?.data?.firstOrNull { it.category == category }
            val goal = existing?.copy(
                monthlyLimit = monthlyLimit,
                aiRecommended = aiRecommended,
                updatedAtMillis = System.currentTimeMillis()
            ) ?: BudgetGoal(
                category = category,
                monthlyLimit = monthlyLimit,
                aiRecommended = aiRecommended
            )
            vaultRepo.saveBudget(userId, goal, vaultKey, isNew = existing == null).fold(
                onSuccess = { _snackbarMessage.emit("${category.labelTr} bütçe hedefi: ${formatTry(monthlyLimit)}") },
                onFailure = { _snackbarMessage.emit(it.localizedMessage ?: "Bütçe kaydedilemedi.") }
            )
        }
    }

    fun deleteBudgetGoal(budgetId: String) {
        viewModelScope.launch {
            vaultRepo.deleteBudget(userId, budgetId)
        }
    }

    // --- Bills & Calendar ---
    fun saveBill(bill: BillReminder, isNew: Boolean) {
        viewModelScope.launch {
            vaultRepo.saveBill(userId, bill, vaultKey, isNew).fold(
                onSuccess = {
                    _snackbarMessage.emit("${bill.title} faturası kaydedildi.")
                },
                onFailure = { _snackbarMessage.emit(it.localizedMessage ?: "Fatura kaydedilemedi.") }
            )
        }
    }

    fun markBillAsPaid(bill: BillReminder) {
        viewModelScope.launch {
            val updated = bill.copy(paidForCurrentMonth = !bill.paidForCurrentMonth)
            vaultRepo.saveBill(userId, updated, vaultKey, isNew = false).fold(
                onSuccess = {
                    if (updated.paidForCurrentMonth) {
                        val accounts = (accountsState.value as? UiState.Success)?.data ?: emptyList()
                        val account = accounts.firstOrNull { it.id == bill.accountId } ?: accounts.firstOrNull()
                        val tx = FinancialTransaction(
                            title = "Fatura Ödemesi: ${bill.title}",
                            amount = bill.amount,
                            type = TransactionType.EXPENSE,
                            category = bill.category,
                            accountId = account?.id ?: "",
                            accountName = account?.let { "${it.bankName} • ${it.accountName}" } ?: "Fatura",
                            dateMillis = System.currentTimeMillis(),
                            note = "Fatura takviminden ödendi olarak işaretlendi"
                        )
                        addTransaction(tx)
                    } else {
                        _snackbarMessage.emit("${bill.title} ödenmedi olarak güncellendi.")
                    }
                },
                onFailure = { _snackbarMessage.emit(it.localizedMessage ?: "Fatura güncellenemedi.") }
            )
        }
    }

    fun markBillCalendarAdded(bill: BillReminder) {
        viewModelScope.launch {
            vaultRepo.saveBill(userId, bill.copy(addedToCalendar = true), vaultKey, isNew = false)
        }
    }

    fun deleteBill(billId: String) {
        viewModelScope.launch {
            vaultRepo.deleteBill(userId, billId)
        }
    }

    fun sendBillTestReminder(bill: BillReminder) {
        val now = System.currentTimeMillis()
        val daysLeft = ((bill.dueDateMillis - now) / (24L * 60L * 60L * 1000L)).toInt()
        FinanceNotificationHelper.notifyBillReminder(appContext, bill.title, bill.amount, daysLeft)
        viewModelScope.launch {
            vaultRepo.saveAlert(
                userId,
                ActivityAlert(
                    title = "Fatura Hatırlatması: ${bill.title}",
                    message = "${formatTry(bill.amount)} tutarlı fatura için hatırlatma tetiklendi.",
                    severity = AlertSeverity.WARNING
                ),
                vaultKey,
                isNew = true
            )
            _snackbarMessage.emit("Fatura hatırlatma bildirimi gönderildi.")
        }
    }

    // --- AI Auto-Categorization & Budget Coach ---
    fun runAiAutoCategorization(targetTransactions: List<FinancialTransaction>) {
        viewModelScope.launch {
            _aiCategorizationState.value = UiState.Loading
            aiRepo.autoCategorizeTransactions(targetTransactions).fold(
                onSuccess = { _aiCategorizationState.value = UiState.Success(it) },
                onFailure = { _aiCategorizationState.value = UiState.Error(it.localizedMessage ?: "Sınıflandırma başarısız.") }
            )
        }
    }

    fun suggestSingleTransactionCategory(
        title: String,
        type: TransactionType,
        amount: Double,
        onResult: (ExpenseCategory, Int) -> Unit,
        onError: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val tempTx = FinancialTransaction(
                id = "preview_single",
                title = title,
                type = type,
                amount = amount
            )
            aiRepo.autoCategorizeTransactions(listOf(tempTx)).fold(
                onSuccess = { list ->
                    val first = list.firstOrNull()
                    if (first != null) {
                        onResult(first.suggestedCategory, first.confidence)
                    } else {
                        onError()
                        _snackbarMessage.emit("AI kategori önerisi bulunamadı.")
                    }
                },
                onFailure = {
                    onError()
                    _snackbarMessage.emit(it.localizedMessage ?: "AI kategori önerisi alınamadı.")
                }
            )
        }
    }

    fun applyCategoryPrediction(prediction: AiCategoryPrediction) {
        viewModelScope.launch {
            val txs = (transactionsState.value as? UiState.Success)?.data ?: return@launch
            val target = txs.firstOrNull { it.id == prediction.transactionId } ?: return@launch
            val updated = target.copy(
                category = prediction.suggestedCategory,
                customCategoryId = "",
                customCategoryName = "",
                customCategoryColorHex = 0L,
                customCategoryIconKey = "",
                aiCategorized = true,
                aiConfidence = prediction.confidence
            )
            vaultRepo.saveTransaction(userId, updated, vaultKey, isNew = false).fold(
                onSuccess = {
                    val current = (_aiCategorizationState.value as? UiState.Success)?.data.orEmpty()
                    _aiCategorizationState.value = UiState.Success(current.filterNot { it.transactionId == prediction.transactionId })
                    _snackbarMessage.emit("${target.title} → ${prediction.suggestedCategory.labelTr} olarak güncellendi.")
                },
                onFailure = { _snackbarMessage.emit("Kategori güncellenemedi.") }
            )
        }
    }

    fun applyAllPredictions() {
        val predictions = (_aiCategorizationState.value as? UiState.Success)?.data ?: return
        if (predictions.isEmpty()) return
        viewModelScope.launch {
            val txs = (transactionsState.value as? UiState.Success)?.data ?: return@launch
            var updatedCount = 0
            predictions.forEach { pred ->
                val target = txs.firstOrNull { it.id == pred.transactionId }
                if (target != null) {
                    val updated = target.copy(
                        category = pred.suggestedCategory,
                        customCategoryId = "",
                        customCategoryName = "",
                        customCategoryColorHex = 0L,
                        customCategoryIconKey = "",
                        aiCategorized = true,
                        aiConfidence = pred.confidence
                    )
                    if (vaultRepo.saveTransaction(userId, updated, vaultKey, isNew = false).isSuccess) {
                        updatedCount++
                    }
                }
            }
            _aiCategorizationState.value = UiState.Success(emptyList())
            _snackbarMessage.emit("$updatedCount işlem yapay zeka önerisiyle sınıflandırıldı.")
        }
    }

    fun generateAiBudgetAdvice() {
        viewModelScope.launch {
            _aiAdviceState.value = UiState.Loading
            val summary = buildFinancialContextString()
            aiRepo.generateBudgetAndSavingsAdvice(summary).fold(
                onSuccess = { _aiAdviceState.value = UiState.Success(it) },
                onFailure = { _aiAdviceState.value = UiState.Error(it.localizedMessage ?: "AI analizi başarısız.") }
            )
        }
    }

    fun askAiCoach(question: String) {
        if (question.isBlank() || _isCoachStreaming.value) return
        val priorHistory = _coachMessages.value
            .filter {
                it.isFromUser || (
                    !it.text.startsWith("Yanıt alınamadı:") &&
                        it.text != "Firestore verileriniz analiz ediliyor..."
                    )
            }
            .map { it.isFromUser to it.text }
        val userMsg = ChatMessage(id = "u_${System.currentTimeMillis()}", isFromUser = true, text = question.trim())
        val botId = "ai_${System.currentTimeMillis()}"
        _coachMessages.value = _coachMessages.value + userMsg + ChatMessage(botId, isFromUser = false, text = "Firestore verileriniz analiz ediliyor...")
        _isCoachStreaming.value = true

        viewModelScope.launch {
            try {
                val ctx = buildFinancialContextString()
                aiRepo.streamCoachResponse(question.trim(), ctx, priorHistory).collect { partial ->
                    _coachMessages.value = _coachMessages.value.map {
                        if (it.id == botId) it.copy(text = partial) else it
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _coachMessages.value = _coachMessages.value.map {
                    if (it.id == botId) it.copy(text = "Yanıt alınamadı: ${e.localizedMessage ?: "Bağlantı hatası"}") else it
                }
            } finally {
                _isCoachStreaming.value = false
            }
        }
    }

    fun clearCoachChat() {
        if (_isCoachStreaming.value) return
        _coachMessages.value = emptyList()
    }

    // --- Bank Statement Upload & Routing ---
    fun resetStatementImport() {
        _statementImportState.value = UiState.Idle
    }

    fun parseStatementFromUri(uri: Uri, fallbackLabel: String = "Ekstre Dosyası") {
        viewModelScope.launch {
            _statementImportState.value = UiState.Loading
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val resolver = appContext.contentResolver
                    val displayName = resolveDisplayName(uri) ?: fallbackLabel
                    val mimeType = resolver.getType(uri)?.lowercase(Locale.ROOT).orEmpty()

                    val declaredSize = runCatching {
                        resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
                    }.getOrDefault(-1L)
                    val maxBytes = 15L * 1024L * 1024L
                    if (declaredSize > maxBytes) {
                        throw IllegalArgumentException("Dosya boyutu 15 MB sınırını aşıyor.")
                    }

                    val lowerName = displayName.lowercase(Locale.ROOT)
                    val isPdf = mimeType == "application/pdf" || lowerName.endsWith(".pdf")
                    val isImage = mimeType.startsWith("image/") ||
                        lowerName.endsWith(".png") ||
                        lowerName.endsWith(".jpg") ||
                        lowerName.endsWith(".jpeg") ||
                        lowerName.endsWith(".webp") ||
                        lowerName.endsWith(".heic")

                    when {
                        isPdf -> {
                            val bytes = readBoundedBytes(uri, maxBytes.toInt())
                            if (bytes.isEmpty()) throw IllegalStateException("PDF dosyası okunamadı.")
                            val headerSample = bytes.take(32).toByteArray().toString(Charsets.US_ASCII)
                            if (!headerSample.contains("%PDF")) {
                                throw IllegalStateException("Seçilen dosya geçerli bir PDF belgesi değil.")
                            }
                            val pdfMetadata = inspectPdfDocument(uri, displayName, bytes)
                            val parsed = aiRepo.parseBankStatementDocument(
                                sourceLabel = displayName,
                                pdfBytes = bytes,
                                pdfMetadata = pdfMetadata
                            ).getOrThrow()
                            annotateDuplicateTransactions(parsed)
                        }
                        isImage -> {
                            val bitmap = decodeScaledBitmap(uri, maxDim = 1600)
                                ?: throw IllegalStateException("Ekstre görseli çözümlenemedi.")
                            try {
                                val parsed = aiRepo.parseBankStatementDocument(
                                    sourceLabel = displayName,
                                    bitmap = bitmap
                                ).getOrThrow()
                                annotateDuplicateTransactions(parsed)
                            } finally {
                                if (!bitmap.isRecycled) bitmap.recycle()
                            }
                        }
                        else -> {
                            val bytes = readBoundedBytes(uri, 512 * 1024)
                            val rawText = bytes.toString(Charsets.UTF_8).trim()
                            if (rawText.isBlank()) {
                                throw IllegalStateException("Seçilen dosyada okunabilir ekstre metni bulunamadı.")
                            }
                            val parsed = aiRepo.parseBankStatementDocument(
                                sourceLabel = displayName,
                                rawText = rawText
                            ).getOrThrow()
                            annotateDuplicateTransactions(parsed)
                        }
                    }
                }
            }
            _statementImportState.value = result.fold(
                onSuccess = { UiState.Success(it) },
                onFailure = { UiState.Error(it.localizedMessage ?: "Ekstre analiz edilemedi.") }
            )
        }
    }

    fun parseStatementFromRawText(rawText: String) {
        val cleaned = rawText.trim()
        if (cleaned.isBlank()) {
            _statementImportState.value = UiState.Error("Lütfen analiz edilecek ekstre metnini yapıştırın.")
            return
        }
        viewModelScope.launch {
            _statementImportState.value = UiState.Loading
            aiRepo.parseBankStatementDocument(
                sourceLabel = "Yapıştırılan Ekstre",
                rawText = cleaned
            ).fold(
                onSuccess = { _statementImportState.value = UiState.Success(annotateDuplicateTransactions(it)) },
                onFailure = { _statementImportState.value = UiState.Error(it.localizedMessage ?: "Metin analiz edilemedi.") }
            )
        }
    }

    fun toggleStatementTxSelection(tempId: String) {
        val current = (_statementImportState.value as? UiState.Success)?.data ?: return
        val updated = current.copy(
            transactions = current.transactions.map {
                if (it.tempId == tempId) it.copy(selected = !it.selected) else it
            }
        )
        _statementImportState.value = UiState.Success(updated)
    }

    fun setAllStatementTxSelection(selected: Boolean, filterType: TransactionType? = null) {
        val current = (_statementImportState.value as? UiState.Success)?.data ?: return
        val updated = current.copy(
            transactions = current.transactions.map {
                if (filterType == null || it.type == filterType) it.copy(selected = selected) else it
            }
        )
        _statementImportState.value = UiState.Success(updated)
    }

    fun toggleStatementTxType(tempId: String) {
        val current = (_statementImportState.value as? UiState.Success)?.data ?: return
        val updated = current.copy(
            transactions = current.transactions.map {
                if (it.tempId == tempId) {
                    val nextType = if (it.type == TransactionType.EXPENSE) TransactionType.INCOME else TransactionType.EXPENSE
                    val nextCat = if (nextType == TransactionType.INCOME && it.category != ExpenseCategory.MAAS && it.category != ExpenseCategory.YATIRIM) {
                        ExpenseCategory.MAAS
                    } else if (nextType == TransactionType.EXPENSE && it.category == ExpenseCategory.MAAS) {
                        ExpenseCategory.DIGER
                    } else {
                        it.category
                    }
                    it.copy(type = nextType, category = nextCat)
                } else {
                    it
                }
            }
        )
        _statementImportState.value = UiState.Success(updated)
    }

    fun updateStatementTxCategory(tempId: String, category: ExpenseCategory) {
        val current = (_statementImportState.value as? UiState.Success)?.data ?: return
        val updated = current.copy(
            transactions = current.transactions.map {
                if (it.tempId == tempId) it.copy(category = category) else it
            }
        )
        _statementImportState.value = UiState.Success(updated)
    }

    fun toggleStatementBillSelection(tempId: String) {
        val current = (_statementImportState.value as? UiState.Success)?.data ?: return
        val updated = current.copy(
            detectedBills = current.detectedBills.map {
                if (it.tempId == tempId) it.copy(selected = !it.selected) else it
            }
        )
        _statementImportState.value = UiState.Success(updated)
    }

    private fun inspectPdfDocument(
        uri: Uri,
        fileName: String,
        bytes: ByteArray
    ): PdfStatementMetadata {
        val fileSizeBytes = bytes.size.toLong()
        val directPfd = runCatching { appContext.contentResolver.openFileDescriptor(uri, "r") }.getOrNull()
        var tempFile: File? = null
        val pfd = directPfd ?: run {
            val file = File.createTempFile("pdf_inspect_", ".pdf", appContext.cacheDir)
            tempFile = file
            file.writeBytes(bytes)
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        }
        return try {
            pfd.use { descriptor ->
                try {
                    PdfRenderer(descriptor).use { renderer ->
                        val count = renderer.pageCount
                        if (count <= 0) {
                            throw IllegalStateException("PDF dosyası boş veya sayfa içermiyor.")
                        }
                        PdfStatementMetadata(
                            fileName = fileName,
                            pageCount = count,
                            fileSizeBytes = fileSizeBytes
                        )
                    }
                } catch (_: SecurityException) {
                    throw IllegalStateException("Bu PDF dosyası şifre korumalı görünüyor. Banka uygulamanızdan şifresiz PDF ekstre indirip yükleyin.")
                } catch (e: IllegalStateException) {
                    throw e
                } catch (_: Exception) {
                    throw IllegalStateException("PDF belgesi okunamadı. Dosyanın geçerli bir banka ekstresi PDF'i olduğundan emin olun.")
                }
            }
        } finally {
            tempFile?.delete()
        }
    }

    private fun annotateDuplicateTransactions(parsed: StatementParseResult): StatementParseResult {
        val existing = (transactionsState.value as? UiState.Success)?.data.orEmpty()
        if (existing.isEmpty() || parsed.transactions.isEmpty()) return parsed

        val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val trLocale = Locale.forLanguageTag("tr-TR")
        val existingKeys = existing.map { tx ->
            val dayKey = dayFmt.format(Date(tx.dateMillis))
            Triple(dayKey, tx.type, tx.title.trim().lowercase(trLocale)) to tx.amount
        }

        val annotated = parsed.transactions.map { item ->
            val dayKey = dayFmt.format(Date(item.dateMillis))
            val normTitle = item.title.trim().lowercase(trLocale)
            val isDup = existingKeys.any { (triple, amt) ->
                triple.first == dayKey &&
                    triple.second == item.type &&
                    kotlin.math.abs(amt - item.amount) < 0.01 &&
                    (triple.third == normTitle || triple.third.contains(normTitle) || normTitle.contains(triple.third))
            }
            if (isDup) item.copy(isDuplicate = true, selected = false) else item
        }
        return parsed.copy(transactions = annotated)
    }

    fun commitStatementImport(
        createNewAccount: Boolean,
        targetAccountId: String?,
        applyDetectedBalance: Boolean
    ) {
        val parsed = (_statementImportState.value as? UiState.Success)?.data ?: return
        val selectedTxs = parsed.transactions.filter { it.selected }
        val selectedBills = parsed.detectedBills.filter { it.selected }

        if (selectedTxs.isEmpty() && selectedBills.isEmpty() && !createNewAccount) {
            viewModelScope.launch {
                _snackbarMessage.emit("Aktarılacak işlem veya fatura seçilmedi.")
            }
            return
        }

        viewModelScope.launch {
            _isSyncing.value = true
            try {
                val existingAccounts = (accountsState.value as? UiState.Success)?.data.orEmpty()
                val existingBills = (billsState.value as? UiState.Success)?.data.orEmpty()
                val netImportedDelta = selectedTxs.sumOf {
                    if (it.type == TransactionType.INCOME) it.amount else -it.amount
                }

                // 1. Route / create or update BankAccount
                var createdAccountNow = false
                val resolvedAccount: BankAccount? = when {
                    createNewAccount || (targetAccountId.isNullOrBlank() && parsed.accountInfo != null) -> {
                        val info = parsed.accountInfo
                        val initialBal = if (applyDetectedBalance && info?.detectedBalance != null) {
                            info.detectedBalance
                        } else {
                            netImportedDelta
                        }
                        val newAcc = BankAccount(
                            bankName = info?.bankName?.ifBlank { "Banka" } ?: "Banka Ekstresi",
                            accountName = info?.accountName?.ifBlank { "Vadesiz TL" } ?: parsed.sourceLabel.take(24),
                            accountType = info?.accountType ?: AccountType.CHECKING,
                            ibanSuffix = info?.ibanSuffix ?: "0000",
                            balance = initialBal,
                            updatedAtMillis = System.currentTimeMillis()
                        )
                        val accRes = vaultRepo.saveAccount(userId, newAcc, vaultKey, isNew = true)
                        if (accRes.isFailure) {
                            _snackbarMessage.emit(
                                accRes.exceptionOrNull()?.localizedMessage ?: "Hedef banka hesabı oluşturulamadı."
                            )
                            return@launch
                        }
                        createdAccountNow = true
                        newAcc
                    }
                    !targetAccountId.isNullOrBlank() -> {
                        val existing = existingAccounts.firstOrNull { it.id == targetAccountId }
                        if (existing != null) {
                            val newBal = if (applyDetectedBalance && parsed.accountInfo?.detectedBalance != null) {
                                parsed.accountInfo.detectedBalance
                            } else {
                                existing.balance + netImportedDelta
                            }
                            val updatedAcc = existing.copy(
                                balance = newBal,
                                updatedAtMillis = System.currentTimeMillis()
                            )
                            val accRes = vaultRepo.saveAccount(userId, updatedAcc, vaultKey, isNew = false)
                            if (accRes.isFailure) {
                                _snackbarMessage.emit(
                                    accRes.exceptionOrNull()?.localizedMessage ?: "Hedef banka hesabı güncellenemedi."
                                )
                                return@launch
                            }
                            updatedAcc
                        } else {
                            null
                        }
                    }
                    else -> null
                }

                // 2. Save selected transactions
                var savedTxCount = 0
                val accountLabel = resolvedAccount?.let { "${it.bankName} • ${it.accountName}" } ?: "Ekstre"
                selectedTxs.forEach { item ->
                    val tx = FinancialTransaction(
                        title = item.title,
                        amount = item.amount,
                        type = item.type,
                        category = item.category,
                        accountId = resolvedAccount?.id ?: "",
                        accountName = accountLabel,
                        dateMillis = item.dateMillis,
                        note = item.note.ifBlank { "Ekstre içe aktarma: ${parsed.sourceLabel}" },
                        aiCategorized = true,
                        aiConfidence = item.confidence
                    )
                    if (vaultRepo.saveTransaction(userId, tx, vaultKey, isNew = true).isSuccess) {
                        savedTxCount++
                    }
                }

                // 3. Save detected recurring bills into Bill Calendar (avoiding exact duplicates)
                var savedBillCount = 0
                selectedBills.forEach { b ->
                    val alreadyExists = existingBills.any {
                        it.title.equals(b.title, ignoreCase = true) && it.dueDayOfMonth == b.dueDayOfMonth
                    }
                    if (!alreadyExists) {
                        val cal = Calendar.getInstance().apply {
                            val maxDay = getActualMaximum(Calendar.DAY_OF_MONTH)
                            set(Calendar.DAY_OF_MONTH, b.dueDayOfMonth.coerceIn(1, maxDay))
                        }
                        val bill = BillReminder(
                            title = b.title,
                            amount = b.amount,
                            category = b.category,
                            dueDayOfMonth = b.dueDayOfMonth,
                            dueDateMillis = cal.timeInMillis,
                            reminderDaysBefore = 3,
                            recurringMonthly = true,
                            accountId = resolvedAccount?.id ?: "",
                            note = "Ekstreden otomatik eklendi (${parsed.sourceLabel})"
                        )
                        if (vaultRepo.saveBill(userId, bill, vaultKey, isNew = true).isSuccess) {
                            savedBillCount++
                        }
                    }
                }

                if (savedTxCount == 0 && selectedTxs.isNotEmpty() && savedBillCount == 0 && !createdAccountNow) {
                    _snackbarMessage.emit("Seçili ekstre işlemleri kaydedilemedi. Bağlantınızı kontrol edip tekrar deneyin.")
                    return@launch
                }

                // 4. Activity alert & sync timestamp
                val summaryMsg = buildString {
                    append("$savedTxCount işlem")
                    if (savedBillCount > 0) append(", $savedBillCount fatura")
                    if (resolvedAccount != null) append(" • ${resolvedAccount.bankName} hesabına")
                    append(" şifrelenerek aktarıldı.")
                }
                vaultRepo.saveAlert(
                    userId,
                    ActivityAlert(
                        title = "Ekstre İçe Aktarıldı",
                        message = summaryMsg,
                        severity = AlertSeverity.INFO
                    ),
                    vaultKey,
                    isNew = true
                )
                updateLastSync("Ekstre aktarıldı ($savedTxCount işlem)")
                _statementImportState.value = UiState.Idle
                _snackbarMessage.emit("Ekstre aktarıldı: $summaryMsg")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _snackbarMessage.emit(e.localizedMessage ?: "Ekstre aktarılırken hata oluştu.")
            } finally {
                _isSyncing.value = false
            }
        }
    }

    private fun resolveDisplayName(uri: Uri): String? {
        return try {
            appContext.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun readBoundedBytes(uri: Uri, maxBytes: Int): ByteArray {
        return appContext.contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArrayOutputStream()
            val chunk = ByteArray(8192)
            var total = 0
            while (true) {
                val read = input.read(chunk)
                if (read <= 0) break
                total += read
                if (total > maxBytes) {
                    throw IllegalArgumentException("Dosya boyutu izin verilen sınırı aşıyor.")
                }
                buffer.write(chunk, 0, read)
            }
            buffer.toByteArray()
        } ?: throw IllegalStateException("Dosya açılamadı.")
    }

    private fun decodeScaledBitmap(uri: Uri, maxDim: Int): Bitmap? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(appContext.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val w = info.size.width
                val h = info.size.height
                val largest = maxOf(w, h)
                if (largest > maxDim) {
                    val ratio = maxDim.toFloat() / largest.toFloat()
                    decoder.setTargetSize(
                        (w * ratio).toInt().coerceAtLeast(1),
                        (h * ratio).toInt().coerceAtLeast(1)
                    )
                }
                decoder.isMutableRequired = true
            }
        } else {
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            appContext.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, boundsOpts)
            }
            var sampleSize = 1
            val largest = maxOf(boundsOpts.outWidth, boundsOpts.outHeight)
            while (largest / sampleSize > maxDim * 2) {
                sampleSize *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            appContext.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOpts)
            }
        }
    }

    // --- Cloud Sync, Backup & Notifications ---
    fun createEncryptedCloudBackup() {
        viewModelScope.launch {
            _isSyncing.value = true
            try {
                val payload = VaultSnapshotPayload(
                    accounts = (accountsState.value as? UiState.Success)?.data ?: emptyList(),
                    transactions = (transactionsState.value as? UiState.Success)?.data ?: emptyList(),
                    budgets = (budgetsState.value as? UiState.Success)?.data ?: emptyList(),
                    bills = (billsState.value as? UiState.Success)?.data ?: emptyList(),
                    customCategories = (categoriesState.value as? UiState.Success)?.data ?: emptyList()
                )
                vaultRepo.createEncryptedBackupSnapshot(userId, payload, vaultKey).fold(
                    onSuccess = { snap ->
                        updateLastSync("Şifreli yedek (${snap.recordCount} kayıt)")
                        _snackbarMessage.emit("Şifreli bulut yedeği oluşturuldu (${snap.recordCount} kayıt).")
                    },
                    onFailure = {
                        _snackbarMessage.emit(it.localizedMessage ?: "Bulut yedeği oluşturulamadı.")
                    }
                )
            } finally {
                _isSyncing.value = false
            }
        }
    }

    fun restoreBackup(backup: BackupSummary) {
        viewModelScope.launch {
            _isSyncing.value = true
            try {
                vaultRepo.restoreFromBackupSnapshot(userId, backup, vaultKey).fold(
                    onSuccess = { count ->
                        updateLastSync("Yedekten geri yüklendi ($count kayıt)")
                        _snackbarMessage.emit("$count şifreli kayıt bulut yedeğinden geri yüklendi.")
                    },
                    onFailure = {
                        _snackbarMessage.emit(it.localizedMessage ?: "Yedek geri yüklenemedi.")
                    }
                )
            } finally {
                _isSyncing.value = false
            }
        }
    }

    fun updateAlertSettings(enabled: Boolean, thresholdAmount: Double) {
        viewModelScope.launch {
            vaultRepo.updateProfilePreferences(
                userId = userId,
                instantAlertsEnabled = enabled,
                alertThresholdAmount = thresholdAmount
            ).fold(
                onSuccess = { _snackbarMessage.emit("Bildirim tercihleri güncellendi.") },
                onFailure = { _snackbarMessage.emit("Ayarlar kaydedilemedi.") }
            )
        }
    }

    fun markAllAlertsRead() {
        viewModelScope.launch {
            val alerts = (alertsState.value as? UiState.Success)?.data ?: return@launch
            alerts.filter { !it.isReadFlag }.forEach { alert ->
                vaultRepo.saveAlert(userId, alert.copy(isReadFlag = true), vaultKey, isNew = false)
            }
        }
    }

    // --- Internal Helpers ---
    private suspend fun triggerInstantTransactionAlerts(tx: FinancialTransaction, accountLabel: String) {
        val profile = (profileState.value as? UiState.Success)?.data
        val alertsEnabled = profile?.instantAlertsEnabled ?: true
        val threshold = profile?.alertThresholdAmount ?: 500.0
        val isHighSpend = tx.type == TransactionType.EXPENSE && tx.amount >= threshold

        val alert = ActivityAlert(
            title = if (tx.type == TransactionType.EXPENSE) {
                if (isHighSpend) "Yüksek Harcama Uyarısı" else "Yeni Harcama"
            } else {
                "Yeni Gelir"
            },
            message = "${tx.title}: ${formatTry(tx.amount)} • ${tx.displayCategoryLabel} ($accountLabel)",
            severity = if (isHighSpend) AlertSeverity.WARNING else AlertSeverity.INFO
        )
        vaultRepo.saveAlert(userId, alert, vaultKey, isNew = true)

        if (alertsEnabled) {
            FinanceNotificationHelper.notifyTransactionRecorded(
                context = appContext,
                title = tx.title,
                amount = tx.amount,
                isExpense = tx.type == TransactionType.EXPENSE,
                categoryLabel = tx.displayCategoryLabel,
                accountName = accountLabel,
                isHighSpend = isHighSpend
            )
        }

        // Check monthly category budget thresholds
        if (tx.type == TransactionType.EXPENSE) {
            val budgets = (budgetsState.value as? UiState.Success)?.data ?: emptyList()
            val matchingBudget = budgets.firstOrNull { it.category == tx.category }
            if (matchingBudget != null && matchingBudget.monthlyLimit > 0.0) {
                val currentMonthSpent = (dashboardMetrics.value.categorySpendingThisMonth[tx.category] ?: 0.0) + tx.amount
                val pct = ((currentMonthSpent / matchingBudget.monthlyLimit) * 100.0).toInt()
                if (pct >= 80 && alertsEnabled) {
                    FinanceNotificationHelper.notifyBudgetThreshold(
                        context = appContext,
                        categoryLabel = tx.category.labelTr,
                        ratioPercent = pct,
                        spentAmount = currentMonthSpent,
                        limitAmount = matchingBudget.monthlyLimit
                    )
                    vaultRepo.saveAlert(
                        userId,
                        ActivityAlert(
                            title = if (pct >= 100) "Bütçe Aşıldı: ${tx.category.labelTr}" else "Bütçe %$pct Doldu: ${tx.category.labelTr}",
                            message = "${formatTry(currentMonthSpent)} / ${formatTry(matchingBudget.monthlyLimit)}",
                            severity = if (pct >= 100) AlertSeverity.CRITICAL else AlertSeverity.WARNING
                        ),
                        vaultKey,
                        isNew = true
                    )
                }
            }
        }
    }

    private suspend fun updateLastSync(label: String) {
        vaultRepo.updateProfilePreferences(userId = userId, lastSyncLabel = label)
    }

    private fun cacheBillRemindersForWorker(bills: List<BillReminder>) {
        viewModelScope.launch {
            val arr = JSONArray()
            bills.forEach { b ->
                arr.put(
                    JSONObject().apply {
                        put("title", b.title)
                        put("amount", b.amount)
                        put("dueMillis", b.dueDateMillis)
                        put("reminderDays", b.reminderDaysBefore)
                        put("paid", b.paidForCurrentMonth)
                    }
                )
            }
            sessionStore.saveReminderSummaryCache(arr.toString())
        }
    }

    private fun buildFinancialContextString(): String {
        val accounts = (accountsState.value as? UiState.Success)?.data ?: emptyList()
        val transactions = (transactionsState.value as? UiState.Success)?.data ?: emptyList()
        val budgets = (budgetsState.value as? UiState.Success)?.data ?: emptyList()
        val bills = (billsState.value as? UiState.Success)?.data ?: emptyList()
        val customCategories = (categoriesState.value as? UiState.Success)?.data ?: emptyList()
        val metrics = dashboardMetrics.value
        val habits = spendingHabitProfile.value

        val accSummary = if (accounts.isEmpty()) "Kayıtlı hesap yok" else accounts.joinToString("; ") {
            "${it.bankName} (${it.accountType.labelTr}): ${formatTry(it.balance)}"
        }
        val catSummary = if (metrics.categoryBreakdown.isEmpty()) "Bu ay gider kaydı yok" else metrics.categoryBreakdown.joinToString("; ") {
            "${it.displayLabel}: ${formatTry(it.amount)} (%${(it.percentage * 100).toInt()})"
        }
        val customCatSummary = if (customCategories.isEmpty()) "Özel kategori yok" else customCategories.joinToString(", ") {
            "${it.name} (${if (it.forIncome) "Gelir" else "Gider"})"
        }
        val budgetSummary = if (budgets.isEmpty()) "Henüz bütçe hedefi belirlenmedi" else budgets.joinToString("; ") { b ->
            val spent = metrics.categorySpendingThisMonth[b.category] ?: 0.0
            val pct = if (b.monthlyLimit > 0.0) ((spent / b.monthlyLimit) * 100.0).toInt() else 0
            "${b.category.labelTr}: Hedef ${formatTry(b.monthlyLimit)}, Harcanan ${formatTry(spent)} (%$pct)"
        }
        val unpaidBills = bills.filter { !it.paidForCurrentMonth }
        val billSummary = if (unpaidBills.isEmpty()) "Ödenmemiş fatura yok" else unpaidBills.joinToString("; ") {
            "${it.title}: ${formatTry(it.amount)} (Ayın ${it.dueDayOfMonth}. günü)"
        }
        val totalMonthlyBills = bills.sumOf { it.amount }

        val sixtyDaysAgo = System.currentTimeMillis() - (60L * 24L * 60L * 60L * 1000L)
        val topMerchants = transactions
            .filter { it.type == TransactionType.EXPENSE && it.dateMillis >= sixtyDaysAgo && it.title.isNotBlank() }
            .groupBy { it.title.trim().lowercase(Locale.forLanguageTag("tr-TR")) }
            .values
            .filter { it.size >= 2 || it.sumOf { tx -> tx.amount } >= 500.0 }
            .sortedByDescending { group -> group.sumOf { it.amount } }
            .take(5)
            .joinToString("; ") { group ->
                "${group.first().title}: ${group.size} kez, toplam ${formatTry(group.sumOf { it.amount })}"
            }
            .ifBlank { "Belirgin tekrarlayan harcama noktası henüz yok" }

        val recentTx = transactions.take(15).joinToString("; ") {
            "${formatDateShort(it.dateMillis)} • ${it.title} (${it.type.labelTr} - ${it.displayCategoryLabel}): ${formatTry(it.amount)}"
        }

        val momStr = metrics.monthOverMonthSpendingDeltaPct?.let { delta ->
            if (delta >= 0) "+%$delta artış" else "%$delta azalış"
        } ?: "Geçmiş ay verisi yok"

        val savingsStr = habits.savingsRatePercent?.let { "%$it" } ?: "Hesaplanamadı"

        return """
            --- FIRESTORE FİNANSAL & HARCAMA ALIŞKANLIĞI ANALİZİ ---
            Toplam Banka Varlığı: ${formatTry(metrics.totalBankBalance)}
            Bu Ay Toplam Gelir: ${formatTry(metrics.monthlyIncome)}
            Bu Ay Toplam Gider: ${formatTry(metrics.monthlyExpense)} (Geçen Aya Göre: $momStr)
            Geçen Ay Toplam Gider: ${formatTry(metrics.lastMonthExpense)}
            Son 6 Ay Toplam Gider: ${formatTry(metrics.sixMonthExpense)}
            Aylık Net Nakit Akışı: ${formatTry(metrics.netMonthlyCashflow)} | Tasarruf Oranı: $savingsStr
            Hafta Sonu vs Hafta İçi Harcama (Son 60 Gün): Hafta Sonu %${habits.weekendSharePercent} (${formatTry(habits.weekendExpenseTotal)}) | Hafta İçi %${100 - habits.weekendSharePercent} (${formatTry(habits.weekdayExpenseTotal)})
            Ay İçi Harcama Döngüsü (Maaş Ritmi): 1-10. gün %${habits.paycheckCycleEarlyPct} | 11-20. gün %${habits.paycheckCycleMidPct} | 21-31. gün %${habits.paycheckCycleLatePct}
            En Sık / Yüksek Tekrarlayan Harcamalar: $topMerchants
            Bütçeyi Aşan Kategoriler: ${habits.overBudgetCategories.ifEmpty { listOf("Yok") }.joinToString(", ")}
            Bütçe Sınırına (%80+) Yaklaşan Kategoriler: ${habits.nearBudgetCategories.ifEmpty { listOf("Yok") }.joinToString(", ")}
            Banka Hesapları: $accSummary
            Bu Ay Kategori Harcamaları: $catSummary
            Kullanıcının Özel Kategorileri: $customCatSummary
            Mevcut Bütçe Hedefleri: $budgetSummary
            Toplam Aylık Fatura Yükü: ${formatTry(totalMonthlyBills)} | Ödenmemiş Faturalar: $billSummary
            Son 15 İşlem: $recentTx
        """.trimIndent()
    }

    private fun computeHabitProfile(
        transactions: List<FinancialTransaction>,
        budgets: List<BudgetGoal>,
        metrics: VaultDashboardMetrics
    ): SpendingHabitProfile {
        val sixtyDaysAgo = System.currentTimeMillis() - (60L * 24L * 60L * 60L * 1000L)
        val recentExpenses = transactions.filter { it.type == TransactionType.EXPENSE && it.dateMillis >= sixtyDaysAgo }
        val activeExpenses = recentExpenses.ifEmpty { transactions.filter { it.type == TransactionType.EXPENSE } }

        var weekendTotal = 0.0
        var weekdayTotal = 0.0
        var earlyTotal = 0.0
        var midTotal = 0.0
        var lateTotal = 0.0

        activeExpenses.forEach { tx ->
            val cal = Calendar.getInstance().apply { timeInMillis = tx.dateMillis }
            val dow = cal.get(Calendar.DAY_OF_WEEK)
            if (dow == Calendar.SATURDAY || dow == Calendar.SUNDAY) {
                weekendTotal += tx.amount
            } else {
                weekdayTotal += tx.amount
            }
            val dom = cal.get(Calendar.DAY_OF_MONTH)
            when {
                dom <= 10 -> earlyTotal += tx.amount
                dom <= 20 -> midTotal += tx.amount
                else -> lateTotal += tx.amount
            }
        }

        val totalHabitExp = weekendTotal + weekdayTotal
        val weekendPct = if (totalHabitExp > 0.0) ((weekendTotal / totalHabitExp) * 100.0).toInt().coerceIn(0, 100) else 0
        val earlyPct = if (totalHabitExp > 0.0) ((earlyTotal / totalHabitExp) * 100.0).toInt().coerceIn(0, 100) else 0
        val midPct = if (totalHabitExp > 0.0) ((midTotal / totalHabitExp) * 100.0).toInt().coerceIn(0, 100) else 0
        val latePct = if (totalHabitExp > 0.0) (100 - earlyPct - midPct).coerceIn(0, 100) else 0

        val repeatedGroup = activeExpenses
            .filter { it.title.isNotBlank() }
            .groupBy { it.title.trim().lowercase(Locale.forLanguageTag("tr-TR")) }
            .values
            .maxWithOrNull(compareBy<List<FinancialTransaction>> { it.size }.thenBy { group -> group.sumOf { it.amount } })

        val topCat = metrics.categoryBreakdown.firstOrNull()
        val savingsRate = if (metrics.monthlyIncome > 0.0) {
            (((metrics.monthlyIncome - metrics.monthlyExpense) / metrics.monthlyIncome) * 100.0).toInt()
        } else null

        val overBudget = budgets.filter { b ->
            val spent = metrics.categorySpendingThisMonth[b.category] ?: 0.0
            b.monthlyLimit > 0.0 && spent > b.monthlyLimit
        }.map { it.category.labelTr }

        val nearBudget = budgets.filter { b ->
            val spent = metrics.categorySpendingThisMonth[b.category] ?: 0.0
            b.monthlyLimit > 0.0 && spent >= b.monthlyLimit * 0.8 && spent <= b.monthlyLimit
        }.map { it.category.labelTr }

        return SpendingHabitProfile(
            analyzedTransactionsCount = transactions.size,
            thisMonthExpense = metrics.monthlyExpense,
            lastMonthExpense = metrics.lastMonthExpense,
            momDeltaPercent = metrics.monthOverMonthSpendingDeltaPct,
            savingsRatePercent = savingsRate,
            weekendSharePercent = weekendPct,
            weekendExpenseTotal = weekendTotal,
            weekdayExpenseTotal = weekdayTotal,
            topHabitMerchant = repeatedGroup?.firstOrNull()?.title.orEmpty(),
            topHabitMerchantCount = repeatedGroup?.size ?: 0,
            topHabitMerchantTotal = repeatedGroup?.sumOf { it.amount } ?: 0.0,
            topCategoryLabel = topCat?.displayLabel.orEmpty(),
            topCategorySharePercent = topCat?.let { (it.percentage * 100f).toInt() } ?: 0,
            overBudgetCategories = overBudget,
            nearBudgetCategories = nearBudget,
            paycheckCycleEarlyPct = earlyPct,
            paycheckCycleMidPct = midPct,
            paycheckCycleLatePct = latePct
        )
    }

    private fun computeMetrics(
        accounts: List<BankAccount>,
        transactions: List<FinancialTransaction>,
        bills: List<BillReminder>,
        alerts: List<ActivityAlert>,
        customCategories: List<CustomCategory>
    ): VaultDashboardMetrics {
        val customCategoryById = customCategories.associateBy { it.id }
        val totalBalance = accounts.sumOf { it.balance }
        val calNow = Calendar.getInstance()
        val currentYear = calNow.get(Calendar.YEAR)
        val currentMonth = calNow.get(Calendar.MONTH)

        val calPrev = Calendar.getInstance().apply { add(Calendar.MONTH, -1) }
        val prevYear = calPrev.get(Calendar.YEAR)
        val prevMonth = calPrev.get(Calendar.MONTH)

        val calSixMonthsAgo = Calendar.getInstance().apply {
            add(Calendar.MONTH, -5)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val thisMonthTxs = transactions.filter { tx ->
            val c = Calendar.getInstance().apply { timeInMillis = tx.dateMillis }
            c.get(Calendar.YEAR) == currentYear && c.get(Calendar.MONTH) == currentMonth
        }
        val lastMonthTxs = transactions.filter { tx ->
            val c = Calendar.getInstance().apply { timeInMillis = tx.dateMillis }
            c.get(Calendar.YEAR) == prevYear && c.get(Calendar.MONTH) == prevMonth
        }
        val sixMonthTxs = transactions.filter { tx ->
            tx.dateMillis >= calSixMonthsAgo.timeInMillis
        }

        val monthlyIncome = thisMonthTxs.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
        val monthlyExpense = thisMonthTxs.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
        val lastMonthExpense = lastMonthTxs.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
        val sixMonthExpense = sixMonthTxs.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }

        val momDeltaPct = if (lastMonthExpense > 0.0) {
            (((monthlyExpense - lastMonthExpense) / lastMonthExpense) * 100.0).toInt()
        } else {
            null
        }

        fun buildBreakdown(txList: List<FinancialTransaction>, totalExp: Double): Pair<Map<ExpenseCategory, Double>, List<CategoryBreakdownItem>> {
            val expenseTxs = txList.filter { it.type == TransactionType.EXPENSE }
            val builtInMap = expenseTxs
                .groupBy { it.category }
                .mapValues { (_, list) -> list.sumOf { it.amount } }
            val items = if (totalExp > 0.0) {
                expenseTxs
                    .groupBy { tx ->
                        if (tx.customCategoryId.isNotBlank()) "custom:${tx.customCategoryId}"
                        else "builtin:${tx.category.name}"
                    }
                    .values
                    .map { group ->
                        val sample = group.first()
                        val sum = group.sumOf { it.amount }
                        val liveCustom = if (sample.customCategoryId.isNotBlank()) {
                            customCategoryById[sample.customCategoryId]
                        } else null
                        CategoryBreakdownItem(
                            category = sample.category,
                            amount = sum,
                            percentage = (sum / totalExp).toFloat().coerceIn(0f, 1f),
                            customCategoryId = sample.customCategoryId,
                            customLabel = liveCustom?.name ?: sample.customCategoryName,
                            customColorHex = liveCustom?.colorHex ?: sample.customCategoryColorHex,
                            customIconKey = liveCustom?.iconKey ?: sample.customCategoryIconKey
                        )
                    }
                    .sortedByDescending { it.amount }
            } else {
                emptyList()
            }
            return builtInMap to items
        }

        val (catMap, breakdown) = buildBreakdown(thisMonthTxs, monthlyExpense)
        val (_, lastMonthBreakdown) = buildBreakdown(lastMonthTxs, lastMonthExpense)
        val (_, sixMonthBreakdown) = buildBreakdown(sixMonthTxs, sixMonthExpense)

        // Last 12 months trend (with 6 months slice for quick previews)
        val monthFormat = SimpleDateFormat("MMM", Locale.forLanguageTag("tr-TR"))
        val trend12 = (11 downTo 0).map { offset ->
            val targetCal = Calendar.getInstance().apply {
                add(Calendar.MONTH, -offset)
            }
            val y = targetCal.get(Calendar.YEAR)
            val m = targetCal.get(Calendar.MONTH)
            val monthTxs = transactions.filter { tx ->
                val c = Calendar.getInstance().apply { timeInMillis = tx.dateMillis }
                c.get(Calendar.YEAR) == y && c.get(Calendar.MONTH) == m
            }
            MonthlyChartPoint(
                monthLabel = monthFormat.format(targetCal.time).replaceFirstChar { it.uppercase(Locale.forLanguageTag("tr-TR")) },
                income = monthTxs.filter { it.type == TransactionType.INCOME }.sumOf { it.amount },
                expense = monthTxs.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
            )
        }

        return VaultDashboardMetrics(
            totalBankBalance = totalBalance,
            monthlyIncome = monthlyIncome,
            monthlyExpense = monthlyExpense,
            lastMonthExpense = lastMonthExpense,
            sixMonthExpense = sixMonthExpense,
            monthOverMonthSpendingDeltaPct = momDeltaPct,
            netMonthlyCashflow = monthlyIncome - monthlyExpense,
            monthlyTrend = trend12.takeLast(6),
            monthlyTrend12Months = trend12,
            categoryBreakdown = breakdown,
            lastMonthCategoryBreakdown = lastMonthBreakdown,
            sixMonthCategoryBreakdown = sixMonthBreakdown,
            categorySpendingThisMonth = catMap,
            upcomingBillsCount = bills.count { !it.paidForCurrentMonth },
            unreadAlertsCount = alerts.count { !it.isReadFlag }
        )
    }

    private fun <T> kotlinx.coroutines.flow.Flow<UiState<T>>.unwrapFirestoreErrors(
        fallbackMessage: String
    ): kotlinx.coroutines.flow.Flow<UiState<T>> = catch { error ->
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        emit(UiState.Error(rootError.localizedMessage ?: fallbackMessage))
    }
}
