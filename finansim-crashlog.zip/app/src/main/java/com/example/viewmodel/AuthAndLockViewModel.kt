package com.example.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.FinanceVaultRepository
import com.example.model.UserVaultProfile
import com.example.security.BiometricAuthHelper
import com.example.security.BiometricAvailability
import com.example.security.EncryptedBlob
import com.example.security.VaultCryptoManager
import com.example.security.VaultSessionStore
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.crypto.SecretKey

sealed interface VaultLockState {
    data object Loading : VaultLockState
    data object SetupPinRequired : VaultLockState
    data class Locked(
        val profile: UserVaultProfile,
        val biometricCanUnlock: Boolean,
        val errorMessage: String? = null
    ) : VaultLockState
    data class Unlocked(
        val userId: String,
        val vaultKey: SecretKey,
        val profile: UserVaultProfile
    ) : VaultLockState
    data class Error(val message: String) : VaultLockState
}

class AuthAndLockViewModel(
    private val repository: FinanceVaultRepository,
    private val sessionStore: VaultSessionStore,
    private val userId: String,
    private val biometricHardwareAvailable: Boolean
) : ViewModel() {

    private val _lockState = MutableStateFlow<VaultLockState>(VaultLockState.Loading)
    val lockState: StateFlow<VaultLockState> = _lockState.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    init {
        loadVaultState()
    }

    fun loadVaultState() {
        viewModelScope.launch {
            _lockState.value = VaultLockState.Loading
            val result = repository.getUserVaultProfile(userId)
            result.fold(
                onSuccess = { profile ->
                    if (profile == null || profile.pinHash.isBlank()) {
                        _lockState.value = VaultLockState.SetupPinRequired
                    } else {
                        val deviceKey = sessionStore.loadDeviceWrappedVaultKey(userId)
                        val biometricLocal = sessionStore.isBiometricLocalEnabled(userId)
                        val canUseBiometric = profile.biometricEnabled &&
                            biometricLocal &&
                            biometricHardwareAvailable &&
                            deviceKey != null &&
                            VaultCryptoManager.verifyVaultKey(
                                deviceKey,
                                EncryptedBlob(profile.vaultKeyCheckCipher, profile.vaultKeyCheckIv)
                            )
                        _lockState.value = VaultLockState.Locked(
                            profile = profile,
                            biometricCanUnlock = canUseBiometric
                        )
                    }
                },
                onFailure = { error ->
                    _lockState.value = VaultLockState.Error(
                        error.localizedMessage ?: "Kasa profili yüklenemedi."
                    )
                }
            )
        }
    }

    fun createVaultPin(pin: String, enableBiometric: Boolean) {
        if (pin.length < 4) return
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val salt = VaultCryptoManager.generateRandomSaltBase64()
                val pinHash = VaultCryptoManager.hashPin(pin, salt)
                val vaultKey = VaultCryptoManager.generateVaultDataKey()
                val wrapped = VaultCryptoManager.wrapVaultKeyWithPin(vaultKey, pin, userId, salt)
                val check = VaultCryptoManager.createVerificationCheck(vaultKey)
                val displayName = Firebase.auth.currentUser?.displayName?.takeIf { it.isNotBlank() } ?: "Finansım Kullanıcısı"

                val createRes = repository.createUserVaultProfile(
                    userId = userId,
                    displayName = displayName,
                    pinSalt = salt,
                    pinHash = pinHash,
                    wrappedVaultKey = wrapped.ciphertextBase64,
                    wrappedVaultKeyIv = wrapped.ivBase64,
                    vaultKeyCheckCipher = check.ciphertextBase64,
                    vaultKeyCheckIv = check.ivBase64,
                    biometricEnabled = enableBiometric && biometricHardwareAvailable
                )
                createRes.fold(
                    onSuccess = {
                        val deviceWrappedOk = sessionStore.saveDeviceWrappedVaultKey(userId, vaultKey)
                        val bioFlag = enableBiometric && biometricHardwareAvailable && deviceWrappedOk
                        runCatching { sessionStore.setBiometricLocalEnabled(userId, bioFlag) }
                        val profile = repository.getUserVaultProfile(userId).getOrNull()
                            ?: UserVaultProfile(
                                userId = userId,
                                displayName = displayName,
                                pinSalt = salt,
                                pinHash = pinHash,
                                wrappedVaultKey = wrapped.ciphertextBase64,
                                wrappedVaultKeyIv = wrapped.ivBase64,
                                vaultKeyCheckCipher = check.ciphertextBase64,
                                vaultKeyCheckIv = check.ivBase64,
                                biometricEnabled = enableBiometric && biometricHardwareAvailable
                            )
                        _lockState.value = VaultLockState.Unlocked(userId, vaultKey, profile)
                    },
                    onFailure = { err ->
                        _lockState.value = VaultLockState.Error(
                            err.localizedMessage ?: "Şifreli kasa oluşturulamadı."
                        )
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _lockState.value = VaultLockState.Error(
                    e.localizedMessage ?: "Şifreli kasa oluşturulurken beklenmeyen bir hata oluştu."
                )
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun unlockWithPin(pin: String) {
        val current = _lockState.value as? VaultLockState.Locked ?: return
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val profile = current.profile
                val valid = VaultCryptoManager.verifyPin(pin, profile.pinSalt, profile.pinHash)
                if (!valid) {
                    _lockState.value = current.copy(errorMessage = "Hatalı PIN kodu. Lütfen tekrar deneyin.")
                    return@launch
                }
                val vaultKey = VaultCryptoManager.unwrapVaultKeyWithPin(
                    wrappedBlob = EncryptedBlob(profile.wrappedVaultKey, profile.wrappedVaultKeyIv),
                    pin = pin,
                    userId = userId,
                    saltBase64 = profile.pinSalt
                )
                val checkOk = VaultCryptoManager.verifyVaultKey(
                    vaultKey,
                    EncryptedBlob(profile.vaultKeyCheckCipher, profile.vaultKeyCheckIv)
                )
                if (!checkOk) {
                    _lockState.value = current.copy(errorMessage = "Kasa anahtarı doğrulanamadı.")
                    return@launch
                }
                val deviceWrappedOk = sessionStore.saveDeviceWrappedVaultKey(userId, vaultKey)
                runCatching {
                    sessionStore.setBiometricLocalEnabled(
                        userId,
                        profile.biometricEnabled && biometricHardwareAvailable && deviceWrappedOk
                    )
                }
                _lockState.value = VaultLockState.Unlocked(userId, vaultKey, profile)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                _lockState.value = current.copy(errorMessage = "PIN çözümlenemedi. Lütfen tekrar deneyin.")
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun unlockWithBiometricSuccess() {
        val current = _lockState.value as? VaultLockState.Locked ?: return
        viewModelScope.launch {
            val deviceKey = sessionStore.loadDeviceWrappedVaultKey(userId)
            if (deviceKey != null && VaultCryptoManager.verifyVaultKey(
                    deviceKey,
                    EncryptedBlob(current.profile.vaultKeyCheckCipher, current.profile.vaultKeyCheckIv)
                )
            ) {
                _lockState.value = VaultLockState.Unlocked(userId, deviceKey, current.profile)
            } else {
                _lockState.value = current.copy(
                    biometricCanUnlock = false,
                    errorMessage = "Biyometrik oturum yenilenemedi. Lütfen PIN kodunuzu girin."
                )
            }
        }
    }

    fun lockNow() {
        val current = _lockState.value as? VaultLockState.Unlocked ?: return
        viewModelScope.launch {
            val deviceKey = sessionStore.loadDeviceWrappedVaultKey(userId)
            val biometricLocal = runCatching { sessionStore.isBiometricLocalEnabled(userId) }.getOrDefault(false)
            val canBiometric = current.profile.biometricEnabled &&
                biometricLocal &&
                biometricHardwareAvailable &&
                deviceKey != null
            _lockState.value = VaultLockState.Locked(
                profile = current.profile,
                biometricCanUnlock = canBiometric
            )
        }
    }

    fun changePin(currentPin: String, newPin: String, onResult: (Result<Unit>) -> Unit) {
        val current = _lockState.value as? VaultLockState.Unlocked ?: return
        viewModelScope.launch {
            try {
                if (newPin.length < 4) {
                    onResult(Result.failure(IllegalArgumentException("PIN en az 4 haneli olmalıdır.")))
                    return@launch
                }
                val valid = VaultCryptoManager.verifyPin(
                    currentPin,
                    current.profile.pinSalt,
                    current.profile.pinHash
                )
                if (!valid) {
                    onResult(Result.failure(IllegalArgumentException("Mevcut PIN hatalı.")))
                    return@launch
                }
                val newSalt = VaultCryptoManager.generateRandomSaltBase64()
                val newHash = VaultCryptoManager.hashPin(newPin, newSalt)
                val wrapped = VaultCryptoManager.wrapVaultKeyWithPin(
                    current.vaultKey,
                    newPin,
                    userId,
                    newSalt
                )
                val res = repository.updateProfilePreferences(
                    userId = userId,
                    pinSalt = newSalt,
                    pinHash = newHash,
                    wrappedVaultKey = wrapped.ciphertextBase64,
                    wrappedVaultKeyIv = wrapped.ivBase64
                )
                if (res.isSuccess) {
                    _lockState.value = current.copy(
                        profile = current.profile.copy(
                            pinSalt = newSalt,
                            pinHash = newHash,
                            wrappedVaultKey = wrapped.ciphertextBase64,
                            wrappedVaultKeyIv = wrapped.ivBase64
                        )
                    )
                }
                onResult(res)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onResult(Result.failure(e))
            }
        }
    }

    fun setBiometricEnabled(enabled: Boolean, onResult: (Result<Unit>) -> Unit) {
        val current = _lockState.value as? VaultLockState.Unlocked ?: return
        viewModelScope.launch {
            try {
                val res = repository.updateProfilePreferences(
                    userId = userId,
                    biometricEnabled = enabled
                )
                if (res.isSuccess) {
                    val deviceWrappedOk = if (enabled) {
                        sessionStore.saveDeviceWrappedVaultKey(userId, current.vaultKey)
                    } else {
                        true
                    }
                    runCatching { sessionStore.setBiometricLocalEnabled(userId, enabled && deviceWrappedOk) }
                    _lockState.value = current.copy(
                        profile = current.profile.copy(biometricEnabled = enabled)
                    )
                }
                onResult(res)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onResult(Result.failure(e))
            }
        }
    }

    companion object {
        fun isBiometricReady(context: Context): Boolean =
            BiometricAuthHelper.checkAvailability(context) == BiometricAvailability.AVAILABLE
    }
}
