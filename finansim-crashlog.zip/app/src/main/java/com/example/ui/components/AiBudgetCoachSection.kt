package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Savings
import androidx.compose.material.icons.rounded.TrendingDown
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.AiBudgetAdviceResponse
import com.example.model.AiHabitInsight
import com.example.model.ExpenseCategory
import com.example.model.HabitImpactLevel
import com.example.model.SpendingHabitProfile
import com.example.model.UiState
import com.example.model.formatTry
import com.example.ui.theme.ExpenseCoral
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.ChatMessage

@OptIn(ExperimentalLayoutApi::class)
fun LazyListScope.aiBudgetCoachItems(
    habitProfile: SpendingHabitProfile,
    aiAdviceState: UiState<AiBudgetAdviceResponse>,
    coachMessages: List<ChatMessage>,
    isCoachStreaming: Boolean,
    questionText: String,
    onQuestionTextChange: (String) -> Unit,
    onGenerateAiAdvice: () -> Unit,
    onApplyAiBudgetTarget: (ExpenseCategory, Double) -> Unit,
    onAskCoach: (String) -> Unit,
    onClearCoachChat: () -> Unit
) {
    // 1. Live Firestore Spending Habit Snapshot + Analyze CTA
    item(key = "coach_hero_snapshot") {
        FirestoreHabitSnapshotCard(
            habitProfile = habitProfile,
            isLoading = aiAdviceState is UiState.Loading,
            hasExistingAdvice = aiAdviceState is UiState.Success,
            onGenerateAiAdvice = onGenerateAiAdvice
        )
    }

    // 2. AI Advice Result / Error
    when (aiAdviceState) {
        is UiState.Error -> {
            item(key = "coach_advice_error") {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = aiAdviceState.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(onClick = onGenerateAiAdvice) {
                            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Tekrar Dene")
                        }
                    }
                }
            }
        }

        is UiState.Success -> {
            val advice = aiAdviceState.data
            item(key = "coach_health_summary") {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Finansal Sağlık Puanı",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                if (advice.spendingPersona.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Surface(
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                        shape = RoundedCornerShape(50)
                                    ) {
                                        Text(
                                            text = "Profil: ${advice.spendingPersona}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                            }
                            val scoreColor = when {
                                advice.healthScore >= 75 -> IncomeGreen
                                advice.healthScore >= 50 -> WarningAmber
                                else -> ExpenseCoral
                            }
                            Surface(
                                color = scoreColor.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = "${advice.healthScore} / 100",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = scoreColor,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = advice.executiveSummary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            if (advice.habitInsights.isNotEmpty()) {
                item(key = "coach_habits_header") {
                    Text(
                        text = "Harcama Alışkanlığı Tespitleri",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                items(advice.habitInsights) { insight ->
                    HabitInsightCard(
                        insight = insight,
                        onAskAboutHabit = {
                            onAskCoach("\"${insight.habitTitle}\" alışkanlığımı iyileştirmek için adım adım ne yapmalıyım?")
                        }
                    )
                }
            }

            if (advice.budgetRecommendations.isNotEmpty()) {
                item(key = "coach_budgets_header") {
                    Text(
                        text = "Önerilen Kategori Bütçe Hedefleri",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                items(advice.budgetRecommendations) { rec ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${rec.category.labelTr}: ${formatTry(rec.suggestedLimit)}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = rec.rationale,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            OutlinedButton(
                                onClick = { onApplyAiBudgetTarget(rec.category, rec.suggestedLimit) }
                            ) {
                                Text("Uygula")
                            }
                        }
                    }
                }
            }

            if (advice.savingTips.isNotEmpty()) {
                item(key = "coach_tips_header") {
                    Text(
                        text = "Kişiselleştirilmiş Tasarruf Önerileri",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                items(advice.savingTips) { tip ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                Icons.Rounded.Savings,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = tip.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (tip.estimatedMonthlySavings > 0) {
                                        Text(
                                            text = "+${formatTry(tip.estimatedMonthlySavings)}/ay",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = IncomeGreen,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = tip.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        else -> Unit
    }

    // 3. Multi-turn Streaming AI Budget Coach Chat
    item(key = "coach_chat_card") {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = Icons.Rounded.Psychology,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AI Bütçe Koçu ile Sohbet Et",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (coachMessages.isNotEmpty() && !isCoachStreaming) {
                        TextButton(onClick = onClearCoachChat) {
                            Text("Temizle")
                        }
                    }
                }
                Text(
                    text = "Firestore işlemlerinize göre kişiselleştirilmiş sorular sorun; koç konuşma bağlamını hatırlar.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "Hafta sonu harcamalarımı nasıl azaltırım?",
                        "Tekrarlayan harcamalarımda nereden kısabilirim?",
                        "Maaş döngüme göre haftalık bütçe planı yap",
                        "Acil durum fonum için aylık ne kadar ayırmalıyım?"
                    ).forEach { quick ->
                        AssistChip(
                            onClick = { onAskCoach(quick) },
                            enabled = !isCoachStreaming,
                            label = { Text(quick) }
                        )
                    }
                }

                if (coachMessages.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    coachMessages.forEach { msg ->
                        Surface(
                            color = if (msg.isFromUser) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = (if (msg.isFromUser) "Siz: " else "AI Bütçe Koçu: ") + msg.text,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = questionText,
                        onValueChange = onQuestionTextChange,
                        placeholder = { Text("Harcamalarınız hakkında soru sorun...") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_coach_question_input")
                    )
                    IconButton(
                        onClick = {
                            val q = questionText.trim()
                            if (q.isNotBlank()) {
                                onQuestionTextChange("")
                                onAskCoach(q)
                            }
                        },
                        enabled = questionText.isNotBlank() && !isCoachStreaming,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("ai_coach_send_button")
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "Sor")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FirestoreHabitSnapshotCard(
    habitProfile: SpendingHabitProfile,
    isLoading: Boolean,
    hasExistingAdvice: Boolean,
    onGenerateAiAdvice: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AI Bütçe Koçu",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                ) {
                    Text(
                        text = "Firestore Canlı Analiz",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Şifreli Firestore hesaplarınız, harcama günleriniz, tekrarlayan işlemleriniz ve bütçe limitleriniz analiz edilerek kişiselleştirilmiş tavsiyeler üretilir.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                HabitKpiChip(
                    label = "İncelenen İşlem",
                    value = "${habitProfile.analyzedTransactionsCount} kayıt",
                    modifier = Modifier.weight(1f, fill = false)
                )
                HabitKpiChip(
                    label = "Hafta Sonu Payı",
                    value = "%${habitProfile.weekendSharePercent}",
                    modifier = Modifier.weight(1f, fill = false)
                )
                HabitKpiChip(
                    label = "Tasarruf Oranı",
                    value = habitProfile.savingsRatePercent?.let { "%$it" } ?: "—",
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (habitProfile.topCategoryLabel.isNotBlank()) {
                    HabitKpiChip(
                        label = "Baskın Kategori",
                        value = "${habitProfile.topCategoryLabel} (%${habitProfile.topCategorySharePercent})",
                        modifier = Modifier.weight(1f, fill = false)
                    )
                }
            }

            if (habitProfile.topHabitMerchantCount >= 2) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.TrendingDown,
                            contentDescription = null,
                            tint = InfoBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "En sık harcama noktası: ${habitProfile.topHabitMerchant} (${habitProfile.topHabitMerchantCount} kez • ${formatTry(habitProfile.topHabitMerchantTotal)})",
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (habitProfile.overBudgetCategories.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = ExpenseCoral.copy(alpha = 0.14f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.WarningAmber,
                            contentDescription = null,
                            tint = ExpenseCoral,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Bütçe sınırı aşıldı: ${habitProfile.overBudgetCategories.joinToString(", ")}",
                            style = MaterialTheme.typography.labelMedium,
                            color = ExpenseCoral
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onGenerateAiAdvice,
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ai_budget_advice_button")
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Harcama Alışkanlıkları Analiz Ediliyor...")
                } else {
                    Text(
                        if (hasExistingAdvice) "Alışkanlık Analizini Yenile"
                        else "Harcama Alışkanlıklarımı Analiz Et"
                    )
                }
            }
        }
    }
}

@Composable
private fun HabitKpiChip(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun HabitInsightCard(
    insight: AiHabitInsight,
    onAskAboutHabit: () -> Unit
) {
    val badgeColor: Color = when (insight.impactLevel) {
        HabitImpactLevel.HIGH -> ExpenseCoral
        HabitImpactLevel.MEDIUM -> WarningAmber
        HabitImpactLevel.POSITIVE -> IncomeGreen
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Rounded.Lightbulb,
                        contentDescription = null,
                        tint = badgeColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = insight.habitTitle,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    shape = RoundedCornerShape(50),
                    color = badgeColor.copy(alpha = 0.14f)
                ) {
                    Text(
                        text = insight.impactLevel.labelTr,
                        style = MaterialTheme.typography.labelSmall,
                        color = badgeColor,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            if (insight.observation.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = insight.observation,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (insight.personalizedAdvice.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.38f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Koç Tavsiyesi: ${insight.personalizedAdvice}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onAskAboutHabit) {
                    Text("Koçtan Detaylı Plan İste")
                }
            }
        }
    }
}
