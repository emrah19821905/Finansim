package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.model.BillReminder
import com.example.model.UiState
import com.example.model.formatTry
import com.example.notifications.CalendarIntegrationHelper
import com.example.ui.theme.ExpenseCoral
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun BillsCalendarScreen(
    billsState: UiState<List<BillReminder>>,
    onOpenAddBill: () -> Unit,
    onEditBill: (BillReminder) -> Unit,
    onTogglePaid: (BillReminder) -> Unit,
    onMarkAddedToCalendar: (BillReminder) -> Unit,
    onSendTestReminder: (BillReminder) -> Unit,
    onDeleteBill: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val bills = (billsState as? UiState.Success)?.data.orEmpty()

    val nowCal = remember { Calendar.getInstance() }
    val todayDay = nowCal.get(Calendar.DAY_OF_MONTH)
    val daysInMonth = nowCal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstDayOfWeek = remember {
        Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }.get(Calendar.DAY_OF_WEEK)
    }
    // Convert Sunday=1..Saturday=7 to Monday=0..Sunday=6
    val leadingEmptyCells = (firstDayOfWeek + 5) % 7
    val monthTitle = remember {
        SimpleDateFormat("MMMM yyyy", Locale.forLanguageTag("tr-TR"))
            .format(nowCal.time)
            .replaceFirstChar { it.uppercase(Locale.forLanguageTag("tr-TR")) }
    }

    var selectedDay by remember { mutableIntStateOf(0) } // 0 = show all

    val billsByDay = remember(bills) { bills.groupBy { it.dueDayOfMonth } }
    val displayedBills = remember(bills, selectedDay) {
        if (selectedDay == 0) bills else bills.filter { it.dueDayOfMonth == selectedDay }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Fatura Takvimi",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = monthTitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Button(
                    onClick = onOpenAddBill,
                    modifier = Modifier.testTag("add_bill_button")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Fatura Ekle")
                }
            }
        }

        // Interactive Monthly Calendar Grid
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (selectedDay == 0) "Tüm Günler" else "Ayın $selectedDay. Günü",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        if (selectedDay != 0) {
                            OutlinedButton(onClick = { selectedDay = 0 }) {
                                Text("Tümünü Göster")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        listOf("Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz").forEach { d ->
                            Text(
                                text = d,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    val totalCells = leadingEmptyCells + daysInMonth
                    val rowsCount = (totalCells + 6) / 7
                    for (r in 0 until rowsCount) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            for (c in 0 until 7) {
                                val cellIndex = r * 7 + c
                                val dayNum = cellIndex - leadingEmptyCells + 1
                                if (dayNum !in 1..daysInMonth) {
                                    Spacer(modifier = Modifier.weight(1f).aspectRatio(1f))
                                } else {
                                    val dayBills = billsByDay[dayNum].orEmpty()
                                    val hasUnpaid = dayBills.any { !it.paidForCurrentMonth }
                                    val isOverdue = hasUnpaid && dayNum < todayDay
                                    val isSelected = selectedDay == dayNum
                                    val isToday = dayNum == todayDay

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .aspectRatio(1f)
                                            .padding(2.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(
                                                when {
                                                    isSelected -> MaterialTheme.colorScheme.primary
                                                    isToday -> MaterialTheme.colorScheme.primaryContainer
                                                    else -> Color.Transparent
                                                }
                                            )
                                            .clickable {
                                                selectedDay = if (selectedDay == dayNum) 0 else dayNum
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                text = dayNum.toString(),
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = if (isToday || dayBills.isNotEmpty()) FontWeight.Bold else FontWeight.Normal,
                                                color = when {
                                                    isSelected -> MaterialTheme.colorScheme.onPrimary
                                                    isToday -> MaterialTheme.colorScheme.onPrimaryContainer
                                                    else -> MaterialTheme.colorScheme.onSurface
                                                }
                                            )
                                            if (dayBills.isNotEmpty()) {
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Box(
                                                    modifier = Modifier
                                                        .size(6.dp)
                                                        .clip(CircleShape)
                                                        .background(
                                                            when {
                                                                isOverdue -> ExpenseCoral
                                                                hasUnpaid -> WarningAmber
                                                                else -> IncomeGreen
                                                            }
                                                        )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (displayedBills.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (selectedDay == 0) {
                            "Henüz fatura tanımlanmadı. Elektrik, su, internet veya kira faturalarınızı ekleyip takvime işleyebilirsiniz."
                        } else {
                            "Ayın $selectedDay. günü için kayıtlı fatura bulunmuyor."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(18.dp)
                    )
                }
            }
        } else {
            items(displayedBills, key = { it.id }) { bill ->
                val daysDiff = bill.dueDayOfMonth - todayDay
                val statusLabel = when {
                    bill.paidForCurrentMonth -> "Bu Ay Ödendi"
                    daysDiff < 0 -> "${-daysDiff} gün gecikti"
                    daysDiff == 0 -> "Son Ödeme BUGÜN"
                    else -> "$daysDiff gün kaldı"
                }
                val statusColor = when {
                    bill.paidForCurrentMonth -> IncomeGreen
                    daysDiff <= 0 -> ExpenseCoral
                    daysDiff <= bill.reminderDaysBefore -> WarningAmber
                    else -> MaterialTheme.colorScheme.primary
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onEditBill(bill) }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { onTogglePaid(bill) }) {
                                Icon(
                                    imageVector = if (bill.paidForCurrentMonth) {
                                        Icons.Rounded.CheckCircle
                                    } else {
                                        Icons.Rounded.RadioButtonUnchecked
                                    },
                                    contentDescription = "Ödeme Durumu",
                                    tint = if (bill.paidForCurrentMonth) IncomeGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = bill.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Her ayın ${bill.dueDayOfMonth}. günü • $statusLabel",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = statusColor
                                )
                            }
                            Text(
                                text = formatTry(bill.amount),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = { onDeleteBill(bill.id) }) {
                                Icon(
                                    Icons.Rounded.DeleteOutline,
                                    contentDescription = "Faturayı Sil",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    if (CalendarIntegrationHelper.openInsertBillCalendarEvent(context, bill)) {
                                        onMarkAddedToCalendar(bill)
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("bill_calendar_button_${bill.id}")
                            ) {
                                Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (bill.addedToCalendar) "Takvimde İşli" else "Takvime İşle")
                            }

                            OutlinedButton(
                                onClick = { onSendTestReminder(bill) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Rounded.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Hatırlat")
                            }
                        }
                    }
                }
            }
        }
    }
}
