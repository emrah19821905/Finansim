package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.example.security.BiometricAuthHelper
import com.example.viewmodel.VaultLockState

@Composable
fun VaultLockScreen(
    lockState: VaultLockState,
    isBusy: Boolean,
    biometricHardwareAvailable: Boolean,
    onCreatePin: (pin: String, enableBiometric: Boolean) -> Unit,
    onUnlockWithPin: (pin: String) -> Unit,
    onBiometricSuccess: () -> Unit,
    onRetryLoad: () -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity

    var pinBuffer by remember(lockState::class) { mutableStateOf("") }
    var firstSetupPin by remember(lockState::class) { mutableStateOf<String?>(null) }
    var setupMismatchError by remember(lockState::class) { mutableStateOf<String?>(null) }
    var enableBiometric by remember { mutableStateOf(biometricHardwareAvailable) }
    var biometricPromptError by remember(lockState::class) { mutableStateOf<String?>(null) }
    var biometricPromptedForCurrentLock by remember { mutableStateOf(false) }

    val targetPinLength = 6

    fun launchBiometric() {
        if (activity == null) return
        biometricPromptError = null
        BiometricAuthHelper.authenticate(
            activity = activity,
            onSuccess = onBiometricSuccess,
            onError = { msg -> biometricPromptError = msg },
            onUsePinFallback = {}
        )
    }

    LaunchedEffect(lockState) {
        if (lockState !is VaultLockState.Locked) {
            biometricPromptedForCurrentLock = false
        } else if (
            lockState.biometricCanUnlock &&
            lockState.errorMessage == null &&
            activity != null &&
            !biometricPromptedForCurrentLock
        ) {
            biometricPromptedForCurrentLock = true
            launchBiometric()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding(),
        contentAlignment = Alignment.Center
    ) {
        when (lockState) {
            VaultLockState.Loading -> {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Şifreli kasa doğrulanıyor...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            is VaultLockState.Error -> {
                Column(
                    modifier = Modifier
                        .widthIn(max = 420.dp)
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Shield,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = lockState.message,
                        style = MaterialTheme.typography.bodyLarge,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = onRetryLoad, modifier = Modifier.testTag("retry_vault_button")) {
                        Text("Tekrar Dene")
                    }
                    TextButton(onClick = onSignOut) {
                        Text("Farklı Google Hesabıyla Giriş")
                    }
                }
            }

            VaultLockState.SetupPinRequired, is VaultLockState.Locked -> {
                val isSetup = lockState is VaultLockState.SetupPinRequired
                val lockedState = lockState as? VaultLockState.Locked
                val errorText = setupMismatchError ?: biometricPromptError ?: lockedState?.errorMessage

                Column(
                    modifier = Modifier
                        .widthIn(max = 420.dp)
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 24.dp, vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterVertically)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Lock,
                                contentDescription = "Kasa kilidi",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = when {
                                isSetup && firstSetupPin == null -> "Kasa PIN Şifresi Belirleyin"
                                isSetup -> "PIN Şifresini Onaylayın"
                                else -> "Finansım Kasa Kilidi"
                            },
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = when {
                                isSetup && firstSetupPin == null ->
                                    "Tüm banka ve harcama verilerinizi AES-256 ile şifreleyecek 6 haneli PIN oluşturun."
                                isSetup ->
                                    "Doğrulamak için aynı 6 haneli PIN kodunu tekrar girin."
                                else ->
                                    "Şifreli verilerinizi açmak için 6 haneli PIN kodunuzu girin."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(22.dp))

                        // PIN dots
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            repeat(targetPinLength) { idx ->
                                val filled = idx < pinBuffer.length
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (filled) MaterialTheme.colorScheme.primary
                                            else MaterialTheme.colorScheme.surfaceVariant
                                        )
                                        .border(
                                            width = 1.5.dp,
                                            color = if (filled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                            shape = CircleShape
                                        )
                                )
                            }
                        }

                        if (errorText != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = errorText,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                                textAlign = TextAlign.Center
                            )
                        }

                        if (isSetup && biometricHardwareAvailable && firstSetupPin == null) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Rounded.Fingerprint,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "Biyometrik Giriş (Parmak İzi / Yüz)",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                    Switch(
                                        checked = enableBiometric,
                                        onCheckedChange = { enableBiometric = it }
                                    )
                                }
                            }
                        }
                    }

                    if (isBusy) {
                        CircularProgressIndicator(modifier = Modifier.padding(24.dp))
                    } else {
                        PinKeypad(
                            showBiometric = !isSetup && lockedState?.biometricCanUnlock == true && activity != null,
                            onDigitClick = { digit ->
                                setupMismatchError = null
                                biometricPromptError = null
                                if (pinBuffer.length < targetPinLength) {
                                    val next = pinBuffer + digit
                                    pinBuffer = next
                                    if (next.length == targetPinLength) {
                                        if (isSetup) {
                                            val first = firstSetupPin
                                            if (first == null) {
                                                firstSetupPin = next
                                                pinBuffer = ""
                                            } else if (first == next) {
                                                onCreatePin(next, enableBiometric)
                                            } else {
                                                setupMismatchError = "PIN kodları eşleşmedi. Baştan deneyin."
                                                firstSetupPin = null
                                                pinBuffer = ""
                                            }
                                        } else {
                                            onUnlockWithPin(next)
                                            pinBuffer = ""
                                        }
                                    }
                                }
                            },
                            onBackspace = {
                                if (pinBuffer.isNotEmpty()) {
                                    pinBuffer = pinBuffer.dropLast(1)
                                }
                            },
                            onBiometricClick = { launchBiometric() }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isSetup && firstSetupPin != null) {
                            TextButton(onClick = {
                                firstSetupPin = null
                                pinBuffer = ""
                                setupMismatchError = null
                            }) {
                                Text("PIN Sıfırla")
                            }
                        } else {
                            Spacer(modifier = Modifier.width(1.dp))
                        }

                        TextButton(onClick = onSignOut) {
                            Text("Çıkış Yap")
                        }
                    }
                }
            }

            is VaultLockState.Unlocked -> Unit
        }
    }
}

@Composable
private fun PinKeypad(
    showBiometric: Boolean,
    onDigitClick: (String) -> Unit,
    onBackspace: () -> Unit,
    onBiometricClick: () -> Unit
) {
    val rows = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9")
    )
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                row.forEach { digit ->
                    KeypadButton(
                        label = digit,
                        onClick = { onDigitClick(digit) },
                        modifier = Modifier.testTag("pin_key_$digit")
                    )
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            if (showBiometric) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier
                        .size(72.dp)
                        .minimumInteractiveComponentSize()
                        .clip(CircleShape)
                        .clickable(onClick = onBiometricClick)
                        .testTag("biometric_unlock_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Rounded.Fingerprint,
                            contentDescription = "Biyometrik giriş",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }
            } else {
                Spacer(modifier = Modifier.size(72.dp))
            }

            KeypadButton(
                label = "0",
                onClick = { onDigitClick("0") },
                modifier = Modifier.testTag("pin_key_0")
            )

            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier
                    .size(72.dp)
                    .minimumInteractiveComponentSize()
                    .clip(CircleShape)
                    .clickable(onClick = onBackspace)
                    .testTag("pin_key_backspace")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Backspace,
                        contentDescription = "Sil",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
private fun KeypadButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        modifier = modifier
            .size(72.dp)
            .minimumInteractiveComponentSize()
            .clip(CircleShape)
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
