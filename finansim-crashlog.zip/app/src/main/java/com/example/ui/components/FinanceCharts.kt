package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Label
import androidx.compose.material.icons.automirrored.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.Checkroom
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.Flight
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalCafe
import androidx.compose.material.icons.rounded.LocalHospital
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Pets
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.Savings
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.CategoryBreakdownItem
import com.example.model.ExpenseCategory
import com.example.model.MonthlyChartPoint
import com.example.model.formatCompactTry
import com.example.model.formatTry
import com.example.ui.theme.ExpenseCoral
import com.example.ui.theme.IncomeGreen

data class CustomIconChoice(val key: String, val labelTr: String, val icon: ImageVector)

val CUSTOM_CATEGORY_ICONS = listOf(
    CustomIconChoice("LABEL", "Etiket", Icons.AutoMirrored.Rounded.Label),
    CustomIconChoice("COFFEE", "Kahve", Icons.Rounded.LocalCafe),
    CustomIconChoice("PET", "Evcil", Icons.Rounded.Pets),
    CustomIconChoice("GAMING", "Oyun", Icons.Rounded.SportsEsports),
    CustomIconChoice("GIFT", "Hediye", Icons.Rounded.CardGiftcard),
    CustomIconChoice("TECH", "Teknoloji", Icons.Rounded.Devices),
    CustomIconChoice("FITNESS", "Spor", Icons.Rounded.FitnessCenter),
    CustomIconChoice("TRAVEL", "Seyahat", Icons.Rounded.Flight),
    CustomIconChoice("BEAUTY", "Bakım", Icons.Rounded.Spa),
    CustomIconChoice("HOME", "Ev", Icons.Rounded.Home),
    CustomIconChoice("CAR", "Araç", Icons.Rounded.DirectionsCar),
    CustomIconChoice("SAVINGS", "Birikim", Icons.Rounded.Savings)
)

fun customCategoryIcon(key: String): ImageVector =
    CUSTOM_CATEGORY_ICONS.firstOrNull { it.key == key }?.icon ?: Icons.AutoMirrored.Rounded.Label

fun categoryIcon(category: ExpenseCategory, customIconKey: String = ""): ImageVector {
    if (customIconKey.isNotBlank()) {
        return customCategoryIcon(customIconKey)
    }
    return when (category) {
        ExpenseCategory.MARKET -> Icons.Rounded.ShoppingCart
        ExpenseCategory.FATURA -> Icons.AutoMirrored.Rounded.ReceiptLong
        ExpenseCategory.ULASIM -> Icons.Rounded.DirectionsCar
        ExpenseCategory.YEME_ICME -> Icons.Rounded.Restaurant
        ExpenseCategory.KIRA -> Icons.Rounded.Home
        ExpenseCategory.SAGLIK -> Icons.Rounded.LocalHospital
        ExpenseCategory.EGLENCE -> Icons.Rounded.Movie
        ExpenseCategory.GIYIM -> Icons.Rounded.Checkroom
        ExpenseCategory.EGITIM -> Icons.Rounded.School
        ExpenseCategory.MAAS -> Icons.Rounded.AccountBalanceWallet
        ExpenseCategory.YATIRIM -> Icons.Rounded.TrendingUp
        ExpenseCategory.DIGER -> Icons.Rounded.Category
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CategoryDonutChart(
    items: List<CategoryBreakdownItem>,
    totalExpense: Double,
    modifier: Modifier = Modifier
) {
    var selectedIndex by remember { mutableIntStateOf(-1) }
    var animateTrigger by remember { mutableStateOf(false) }
    LaunchedEffect(items) { animateTrigger = true }
    val sweepScale by animateFloatAsState(
        targetValue = if (animateTrigger) 1f else 0f,
        animationSpec = tween(durationMillis = 700),
        label = "donut_sweep"
    )

    if (items.isEmpty() || totalExpense <= 0.0) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(170.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Bu ay henüz gider kaydı bulunmuyor.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    val selected = items.getOrNull(selectedIndex)

    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(184.dp)) {
                val strokeWidth = 28.dp.toPx()
                val diameter = size.minDimension - strokeWidth
                val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
                val arcSize = Size(diameter, diameter)

                var startAngle = -90f
                items.forEachIndexed { index, item ->
                    val sweep = item.percentage * 360f * sweepScale
                    val isSelected = index == selectedIndex
                    val actualStroke = if (isSelected) strokeWidth + 6.dp.toPx() else strokeWidth
                    drawArc(
                        color = item.displayColor,
                        startAngle = startAngle,
                        sweepAngle = (sweep - 2.5f).coerceAtLeast(1f),
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = actualStroke, cap = StrokeCap.Butt)
                    )
                    startAngle += sweep
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = selected?.displayLabel ?: "Toplam Gider",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = formatCompactTry(selected?.amount ?: totalExpense),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (selected != null) {
                    Text(
                        text = "%${(selected.percentage * 100).toInt()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = selected.displayColor
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items.forEachIndexed { index, item ->
                val isSelected = index == selectedIndex
                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (isSelected) {
                        item.displayColor.copy(alpha = 0.18f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                    },
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickable {
                            selectedIndex = if (selectedIndex == index) -1 else index
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(item.displayColor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${item.displayLabel} %${(item.percentage * 100).toInt()}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MonthlyCashflowBarChart(
    points: List<MonthlyChartPoint>,
    modifier: Modifier = Modifier
) {
    var selectedIdx by remember { mutableIntStateOf(points.lastIndex.coerceAtLeast(0)) }
    var animateTrigger by remember { mutableStateOf(false) }
    LaunchedEffect(points) { animateTrigger = true }
    val heightScale by animateFloatAsState(
        targetValue = if (animateTrigger) 1f else 0f,
        animationSpec = tween(durationMillis = 650),
        label = "bar_anim"
    )

    if (points.isEmpty()) return
    val maxVal = points.maxOf { maxOf(it.income, it.expense) }.coerceAtLeast(1000.0)
    val selectedPoint = points.getOrNull(selectedIdx)

    Column(modifier = modifier.fillMaxWidth()) {
        if (selectedPoint != null) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${selectedPoint.monthLabel} Özeti",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "+${formatTry(selectedPoint.income)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = IncomeGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "-${formatTry(selectedPoint.expense)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = ExpenseCoral,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(170.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val barChartHeight = size.height - 12.dp.toPx()
                val slotWidth = size.width / points.size.coerceAtLeast(1)
                val barWidth = (slotWidth * 0.28f).coerceIn(8.dp.toPx(), 18.dp.toPx())
                val gap = 4.dp.toPx()

                // Horizontal dashed guide lines
                listOf(0.25f, 0.5f, 0.75f, 1f).forEach { ratio ->
                    val y = barChartHeight * (1f - ratio) + 6.dp.toPx()
                    drawLine(
                        color = gridColor,
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
                    )
                }

                points.forEachIndexed { idx, pt ->
                    val centerX = slotWidth * idx + slotWidth / 2f
                    val incH = ((pt.income / maxVal).toFloat() * barChartHeight * heightScale).coerceAtLeast(3.dp.toPx())
                    val expH = ((pt.expense / maxVal).toFloat() * barChartHeight * heightScale).coerceAtLeast(3.dp.toPx())

                    val alpha = if (idx == selectedIdx) 1f else 0.72f
                    drawRoundRect(
                        color = IncomeGreen.copy(alpha = alpha),
                        topLeft = Offset(centerX - barWidth - gap / 2f, barChartHeight - incH + 6.dp.toPx()),
                        size = Size(barWidth, incH),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                    )
                    drawRoundRect(
                        color = ExpenseCoral.copy(alpha = alpha),
                        topLeft = Offset(centerX + gap / 2f, barChartHeight - expH + 6.dp.toPx()),
                        size = Size(barWidth, expH),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            points.forEachIndexed { idx, pt ->
                val isSelected = idx == selectedIdx
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { selectedIdx = idx }
                ) {
                    Text(
                        text = pt.monthLabel,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LegendDot(color = IncomeGreen, label = "Gelir")
            Spacer(modifier = Modifier.width(18.dp))
            LegendDot(color = ExpenseCoral, label = "Gider")
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
