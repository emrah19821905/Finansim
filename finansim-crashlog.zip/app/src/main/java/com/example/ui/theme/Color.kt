package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Emerald Vault palette
val EmeraldDeep = Color(0xFF0A3025)
val EmeraldPrimary = Color(0xFF0F6B4E)
val EmeraldBright = Color(0xFF16A37A)
val EmeraldContainerLight = Color(0xFFCFF5E7)
val OnEmeraldContainerLight = Color(0xFF04261B)

// Secondary Warm Gold accent palette
val GoldPrimary = Color(0xFFB5891C)
val GoldBright = Color(0xFFE0B84C)
val GoldContainerLight = Color(0xFFFFF0C7)
val OnGoldContainerLight = Color(0xFF2B1F00)

// Tertiary Slate Teal palette
val TealSlate = Color(0xFF2F6673)
val TealContainerLight = Color(0xFFD0EDF4)

// Surfaces & Backgrounds - Light
val SurfaceBgLight = Color(0xFFF6F9F7)
val SurfaceCardLight = Color(0xFFFFFFFF)
val SurfaceElevatedLight = Color(0xFFECF3EF)
val TextPrimaryLight = Color(0xFF101F1A)
val TextSecondaryLight = Color(0xFF4F635B)
val OutlineLight = Color(0xFFD2DFD9)

// Surfaces & Backgrounds - Dark
val SurfaceBgDark = Color(0xFF081410)
val SurfaceCardDark = Color(0xFF10211B)
val SurfaceElevatedDark = Color(0xFF172D25)
val TextPrimaryDark = Color(0xFFE9F3EE)
val TextSecondaryDark = Color(0xFF9EB5AC)
val OutlineDark = Color(0xFF284238)

// Semantic financial colors
val IncomeGreen = Color(0xFF12945B)
val IncomeGreenBg = Color(0xFFE3F7EC)
val ExpenseCoral = Color(0xFFD6453A)
val ExpenseCoralBg = Color(0xFFFDECEB)
val WarningAmber = Color(0xFFD98218)
val WarningAmberBg = Color(0xFFFFF4E2)
val InfoBlue = Color(0xFF2563EB)
val InfoBlueBg = Color(0xFFEAF1FF)
