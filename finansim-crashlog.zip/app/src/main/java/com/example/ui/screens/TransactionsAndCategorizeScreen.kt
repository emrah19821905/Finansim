package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.AiCategoryPrediction
import com.example.model.ExpenseCategory
import com.example.model.FinancialTransaction
import com.example.model.TransactionType
import com.example.model.UiState

private enum class TxFilter(val label: String) {
    ALL("Tümü"),
    EXPENSE("Giderler"),
    INCOME("Gelirler"),
    UNCATEGORIZED("Diğer / Sınıflandırılmamış")
}

@Composable
fun TransactionsAndCategorizeScreen(
    transactionsState: UiState<List<FinancialTransaction>>,
    aiCategorizationState: UiState<List<AiCategoryPrediction>>,
    onRunAutoCategorize: (List<FinancialTransaction>) -> Unit,
    onApplyPrediction: (AiCategoryPrediction) -> Unit,
    onApplyAllPredictions: () -> Unit,
    onOpenStatementImport: () -> Unit,
    onOpenCategoryManagement: () -> Unit,
    onAddTransaction: () -> Unit,
    onEditTransaction: (FinancialTransaction) -> Unit,
    onDeleteTransaction: (FinancialTransaction) -> Unit,
    modifier: Modifier = Modifier
) {
    val transactions = (transactionsState as? UiState.Success)?.data.orEmpty()
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(TxFilter.ALL) }

    val filtered = remember(transactions, query, filter) {
        transactions.filter { tx ->
            val matchesQuery = query.isBlank() ||
                tx.title.contains(query, ignoreCase = true) ||
                tx.displayCategoryLabel.contains(query, ignoreCase = true) ||
                tx.accountName.contains(query, ignoreCase = true)
            val matchesFilter = when (filter) {
                TxFilter.ALL -> true
                TxFilter.EXPENSE -> tx.type == TransactionType.EXPENSE
                TxFilter.INCOME -> tx.type == TransactionType.INCOME
                TxFilter.UNCATEGORIZED -> tx.category == ExpenseCategory.DIGER || !tx.aiCategorized
            }
            matchesQuery && matchesFilter
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Gelir & Gider İşlemleri",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onOpenStatementImport,
                        modifier = Modifier.testTag("tx_import_statement_button")
                    ) {
                        Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PDF Yükle")
                    }
                    Button(
                        onClick = onAddTransaction,
                        modifier = Modifier.testTag("tx_screen_add_button")
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Ekle")
                    }
                }
            }
        }

        // Dedicated AI Auto-Categorization Panel
        item {
            AutoCategorizationPanel(
                transactions = transactions,
                aiState = aiCategorizationState,
                onRun = {
                    val candidates = transactions.filter { it.category == ExpenseCategory.DIGER || !it.aiCategorized }
                        .ifEmpty { transactions }
                    onRunAutoCategorize(candidates)
                },
                onApplyOne = onApplyPrediction,
                onApplyAll = onApplyAllPredictions,
                onOpenCategoryManagement = onOpenCategoryManagement
            )
        }

        // Search & Filters
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("İşlem, kategori veya banka ara...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TxFilter.entries.forEach { option ->
                    FilterChip(
                        selected = filter == option,
                        onClick = { filter = option },
                        label = { Text(option.label) }
                    )
                }
            }
        }

        if (transactionsState is UiState.Loading) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator()
                }
            }
        } else if (filtered.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Gösterilecek işlem bulunamadı.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(20.dp)
                    )
                }
            }
        } else {
            items(filtered, key = { it.id }) { tx ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TransactionRowCard(
                        tx = tx,
                        onClick = { onEditTransaction(tx) },
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { onDeleteTransaction(tx) }) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteOutline,
                            contentDescription = "İşlemi Sil",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AutoCategorizationPanel(
    transactions: List<FinancialTransaction>,
    aiState: UiState<List<AiCategoryPrediction>>,
    onRun: () -> Unit,
    onApplyOne: (AiCategoryPrediction) -> Unit,
    onApplyAll: () -> Unit,
    onOpenCategoryManagement: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Otomatik Kategori Sınıflandırma Paneli",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Yapay zeka ile sınıflandırın veya kendi özel kategorilerinizi yönetin.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onRun,
                    enabled = transactions.isNotEmpty() && aiState !is UiState.Loading,
                    modifier = Modifier.testTag("ai_categorize_button")
                ) {
                    if (aiState is UiState.Loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Sınıflandırılıyor...")
                    } else {
                        Text("AI ile Sınıflandır")
                    }
                }

                OutlinedButton(
                    onClick = onOpenCategoryManagement,
                    modifier = Modifier.testTag("open_category_management_button")
                ) {
                    Icon(Icons.Rounded.Category, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Kategorileri Yönet")
                }

                val predictions = (aiState as? UiState.Success)?.data.orEmpty()
                if (predictions.isNotEmpty()) {
                    OutlinedButton(onClick = onApplyAll) {
                        Text("Tümünü Uygula (${predictions.size})")
                    }
                }
            }

            when (aiState) {
                is UiState.Error -> {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = aiState.message,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                is UiState.Success -> {
                    val preds = aiState.data
                    if (preds.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        preds.take(6).forEach { pred ->
                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${pred.title} → ${pred.suggestedCategory.labelTr} (%${pred.confidence})",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = pred.rationale,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    OutlinedButton(onClick = { onApplyOne(pred) }) {
                                        Text("Uygula")
                                    }
                                }
                            }
                        }
                    }
                }

                else -> Unit
            }
        }
    }
}
