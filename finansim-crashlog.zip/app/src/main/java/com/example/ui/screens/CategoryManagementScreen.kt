package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.CustomCategory
import com.example.model.ExpenseCategory
import com.example.model.FinancialTransaction
import com.example.model.UiState
import com.example.model.formatTry
import com.example.ui.components.categoryIcon
import com.example.ui.components.customCategoryIcon
import com.example.ui.dialogs.CategoryEditorDialog
import com.example.ui.theme.ExpenseCoral
import com.example.ui.theme.IncomeGreen

@Composable
fun CategoryManagementScreen(
    categoriesState: UiState<List<CustomCategory>>,
    transactionsState: UiState<List<FinancialTransaction>>,
    onAddCategory: (name: String, iconKey: String, colorHex: Long, forIncome: Boolean) -> Unit,
    onUpdateCategory: (CustomCategory) -> Unit,
    onDeleteCategory: (CustomCategory) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val customCategories = (categoriesState as? UiState.Success)?.data.orEmpty()
    val transactions = (transactionsState as? UiState.Success)?.data.orEmpty()

    var showEditorDialog by remember { mutableStateOf(false) }
    var editingCategory by remember { mutableStateOf<CustomCategory?>(null) }
    var deletingCategory by remember { mutableStateOf<CustomCategory?>(null) }

    val customUsageStats = remember(transactions) {
        transactions
            .filter { it.customCategoryId.isNotBlank() }
            .groupBy { it.customCategoryId }
            .mapValues { (_, list) -> list.size to list.sumOf { it.amount } }
    }

    val builtInUsageStats = remember(transactions) {
        transactions
            .filter { it.customCategoryId.isBlank() }
            .groupBy { it.category }
            .mapValues { (_, list) -> list.size to list.sumOf { it.amount } }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("categories_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Geri Dön"
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Kategori Yönetimi",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Button(
                    onClick = {
                        editingCategory = null
                        showEditorDialog = true
                    },
                    modifier = Modifier.testTag("add_category_button")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Yeni")
                }
            }
        }

        // Summary Header Card
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.CloudDone,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Şifreli Bulut Kategori Sistemi",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${customCategories.size} özel kategori • ${ExpenseCategory.entries.size} sistem kategorisi aktif. Değişiklikler Firestore'a şifrelenerek kaydedilir.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Custom Categories Header
        item {
            Text(
                text = "Özel Kategorilerim",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        when (categoriesState) {
            is UiState.Loading -> {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
            }

            is UiState.Error -> {
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = categoriesState.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }

            else -> {
                if (customCategories.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Category,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(34.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Henüz özel kategori oluşturmadınız",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Kahve, Evcil Hayvan veya Yan Gelir gibi kendi kategorilerinizi ekleyerek harcamalarınızı detaylandırın.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = {
                                        editingCategory = null
                                        showEditorDialog = true
                                    },
                                    modifier = Modifier.testTag("empty_add_category_button")
                                ) {
                                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("İlk Özel Kategoriyi Ekle")
                                }
                            }
                        }
                    }
                } else {
                    items(customCategories, key = { it.id }) { cat ->
                        val stats = customUsageStats[cat.id]
                        CustomCategoryCard(
                            category = cat,
                            txCount = stats?.first ?: 0,
                            totalAmount = stats?.second ?: 0.0,
                            onEdit = {
                                editingCategory = cat
                                showEditorDialog = true
                            },
                            onDelete = { deletingCategory = cat }
                        )
                    }
                }
            }
        }

        // Built-in System Categories Header
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Varsayılan Sistem Kategorileri",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(ExpenseCategory.entries, key = { it.name }) { builtIn ->
            val stats = builtInUsageStats[builtIn]
            BuiltInCategoryRow(
                category = builtIn,
                txCount = stats?.first ?: 0,
                totalAmount = stats?.second ?: 0.0
            )
        }
    }

    if (showEditorDialog) {
        CategoryEditorDialog(
            existing = editingCategory,
            onDismiss = { showEditorDialog = false },
            onSave = { name, iconKey, colorHex, forIncome ->
                val target = editingCategory
                if (target == null) {
                    onAddCategory(name, iconKey, colorHex, forIncome)
                } else {
                    onUpdateCategory(
                        target.copy(
                            name = name,
                            iconKey = iconKey,
                            colorHex = colorHex,
                            forIncome = forIncome
                        )
                    )
                }
                showEditorDialog = false
            }
        )
    }

    val pendingDelete = deletingCategory
    if (pendingDelete != null) {
        AlertDialog(
            onDismissRequest = { deletingCategory = null },
            title = { Text("Kategoriyi Sil") },
            text = {
                Text(
                    "\"${pendingDelete.name}\" özel kategorisini silmek istediğinize emin misiniz? " +
                        "Bu kategoriye bağlı işlemler otomatik olarak varsayılan kategoriye döndürülür."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteCategory(pendingDelete)
                        deletingCategory = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    ),
                    modifier = Modifier.testTag("confirm_delete_category_button")
                ) {
                    Text("Sil")
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingCategory = null }) {
                    Text("İptal")
                }
            }
        )
    }
}

@Composable
private fun CustomCategoryCard(
    category: CustomCategory,
    txCount: Int,
    totalAmount: Double,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val accent = category.color
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("custom_category_card_${category.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = customCategoryIcon(category.iconKey),
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = category.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = (if (category.forIncome) IncomeGreen else ExpenseCoral).copy(alpha = 0.12f)
                    ) {
                        Text(
                            text = if (category.forIncome) "Gelir" else "Gider",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (category.forIncome) IncomeGreen else ExpenseCoral,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (txCount == 0) {
                        "Henüz işlem yok"
                    } else {
                        "$txCount işlem • ${formatTry(totalAmount)}"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(
                onClick = onEdit,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("edit_category_${category.id}")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Edit,
                    contentDescription = "${category.name} kategorisini düzenle",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("delete_category_${category.id}")
            ) {
                Icon(
                    imageVector = Icons.Rounded.DeleteOutline,
                    contentDescription = "${category.name} kategorisini sil",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@Composable
private fun BuiltInCategoryRow(
    category: ExpenseCategory,
    txCount: Int,
    totalAmount: Double
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(category.color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = categoryIcon(category),
                    contentDescription = null,
                    tint = category.color,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = category.labelTr,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = if (txCount == 0) "Kullanılmadı" else "$txCount işlem • ${formatTry(totalAmount)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = if (category.defaultForIncome) "Gelir" else "Gider",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
