package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Savings
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.AiBudgetAdviceResponse
import com.example.model.BudgetGoal
import com.example.model.ExpenseCategory
import com.example.model.SpendingHabitProfile
import com.example.model.UiState
import com.example.model.formatTry
import com.example.ui.components.TrendChartMode
import com.example.ui.components.aiBudgetCoachItems
import com.example.ui.theme.ExpenseCoral
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.ChatMessage
import com.example.viewmodel.VaultDashboardMetrics

@Composable
fun AnalyticsAndAiScreen(
    metrics: VaultDashboardMetrics,
    habitProfile: SpendingHabitProfile,
    budgetsState: UiState<List<BudgetGoal>>,
    aiAdviceState: UiState<AiBudgetAdviceResponse>,
    coachMessages: List<ChatMessage>,
    isCoachStreaming: Boolean,
    modifier: Modifier = Modifier,
    requestedTab: Int? = null,
    onTabHandled: () -> Unit = {},
    onOpenAddBudget: () -> Unit,
    onDeleteBudget: (String) -> Unit,
    onApplyAiBudgetTarget: (ExpenseCategory, Double) -> Unit,
    onGenerateAiAdvice: () -> Unit,
    onAskCoach: (String) -> Unit,
    onClearCoachChat: () -> Unit
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var trendRange by rememberSaveable { mutableStateOf(TrendRangeOption.SIX_MONTHS) }
    var trendMode by rememberSaveable { mutableStateOf(TrendChartMode.AREA_LINE) }
    var categoryPeriod by rememberSaveable { mutableStateOf(CategoryPeriodOption.THIS_MONTH) }
    var categoryChartStyle by rememberSaveable { mutableStateOf(CategoryChartStyle.DONUT) }
    val budgets = (budgetsState as? UiState.Success)?.data.orEmpty()
    var questionText by remember { mutableStateOf("") }

    LaunchedEffect(requestedTab) {
        if (requestedTab != null) {
            selectedTab = requestedTab.coerceIn(0, 1)
            onTabHandled()
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Raporlar & AI Bütçe Koçu",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                listOf("Grafik Panosu", "AI Bütçe Koçu").forEachIndexed { idx, label ->
                    SegmentedButton(
                        selected = selectedTab == idx,
                        onClick = { selectedTab = idx },
                        shape = SegmentedButtonDefaults.itemShape(idx, 2),
                        modifier = Modifier.testTag(if (idx == 0) "tab_charts" else "tab_ai_coach")
                    ) {
                        Text(label)
                    }
                }
            }
        }

        if (selectedTab == 0) {
            visualizationDashboardItems(
                metrics = metrics,
                trendRange = trendRange,
                onTrendRangeChange = { trendRange = it },
                trendMode = trendMode,
                onTrendModeChange = { trendMode = it },
                categoryPeriod = categoryPeriod,
                onCategoryPeriodChange = { categoryPeriod = it },
                categoryChartStyle = categoryChartStyle,
                onCategoryChartStyleChange = { categoryChartStyle = it }
            )

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Bütçe Hedeflerim",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Button(onClick = onOpenAddBudget, modifier = Modifier.testTag("add_budget_button")) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Hedef Ekle")
                    }
                }
            }

            if (budgets.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Henüz kategori bütçe hedefi belirlemediniz. Manuel hedef ekleyebilir veya AI Koç sekmesinden otomatik hedef önerisi alabilirsiniz.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(budgets, key = { it.id }) { goal ->
                    val spent = metrics.categorySpendingThisMonth[goal.category] ?: 0.0
                    val ratio = if (goal.monthlyLimit > 0) (spent / goal.monthlyLimit).toFloat().coerceIn(0f, 1f) else 0f
                    val pct = if (goal.monthlyLimit > 0) ((spent / goal.monthlyLimit) * 100).toInt() else 0
                    val barColor = when {
                        pct >= 100 -> ExpenseCoral
                        pct >= 80 -> WarningAmber
                        else -> IncomeGreen
                    }
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = goal.category.labelTr + if (goal.aiRecommended) " (AI)" else "",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${formatTry(spent)} / ${formatTry(goal.monthlyLimit)} (%$pct)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { onDeleteBudget(goal.id) }) {
                                    Icon(
                                        Icons.Rounded.DeleteOutline,
                                        contentDescription = "Hedefi Sil",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { ratio },
                                color = barColor,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                            )
                        }
                    }
                }
            }
        } else {
            aiBudgetCoachItems(
                habitProfile = habitProfile,
                aiAdviceState = aiAdviceState,
                coachMessages = coachMessages,
                isCoachStreaming = isCoachStreaming,
                questionText = questionText,
                onQuestionTextChange = { questionText = it },
                onGenerateAiAdvice = onGenerateAiAdvice,
                onApplyAiBudgetTarget = onApplyAiBudgetTarget,
                onAskCoach = onAskCoach,
                onClearCoachChat = onClearCoachChat
            )
        }
    }
}
