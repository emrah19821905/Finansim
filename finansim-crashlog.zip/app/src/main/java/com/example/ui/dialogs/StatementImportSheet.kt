package com.example.ui.dialogs

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.BankAccount
import com.example.model.ExpenseCategory
import com.example.model.ExtractedStatementTx
import com.example.model.StatementParseResult
import com.example.model.TransactionType
import com.example.model.UiState
import com.example.model.formatTry
import com.example.ui.components.categoryIcon
import com.example.ui.theme.ExpenseCoral
import com.example.ui.theme.IncomeGreen

private enum class StatementTxFilter(val labelTr: String) {
    ALL("Tümü"),
    INCOME("Gelirler"),
    EXPENSE("Giderler")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatementImportSheet(
    statementState: UiState<StatementParseResult>,
    accounts: List<BankAccount>,
    isSyncing: Boolean,
    onPickUri: (Uri, String) -> Unit,
    onAnalyzeText: (String) -> Unit,
    onToggleTx: (String) -> Unit,
    onSetAllTxSelection: (Boolean, TransactionType?) -> Unit,
    onToggleTxType: (String) -> Unit,
    onUpdateTxCategory: (String, ExpenseCategory) -> Unit,
    onToggleBill: (String) -> Unit,
    onCommitImport: (createNewAccount: Boolean, targetAccountId: String?, applyDetectedBalance: Boolean) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showTextInput by remember { mutableStateOf(false) }
    var rawText by remember { mutableStateOf("") }

    val pdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onPickUri(uri, "Banka Ekstresi.pdf")
        }
    }

    val documentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onPickUri(uri, "Ekstre Dosyası")
        }
    }

    val photoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onPickUri(uri, "Ekstre Görseli")
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.UploadFile,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "PDF Banka Ekstresi Yükle",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Banka PDF ekstrenizdeki gelir ve giderleri otomatik okuyup hesaplara, işlemlere ve fatura takvimine ekleyin.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            when (statementState) {
                is UiState.Loading -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator()
                            Text(
                                text = "Yapay zeka ekstreyi analiz ediyor...",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Banka hesabı, gelir-gider hareketleri ve tekrarlayan faturalar ayrıştırılıyor.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                is UiState.Success -> {
                    StatementReviewContent(
                        result = statementState.data,
                        accounts = accounts,
                        isSyncing = isSyncing,
                        onToggleTx = onToggleTx,
                        onSetAllTxSelection = onSetAllTxSelection,
                        onToggleTxType = onToggleTxType,
                        onUpdateTxCategory = onUpdateTxCategory,
                        onToggleBill = onToggleBill,
                        onCommitImport = onCommitImport,
                        onReset = onReset
                    )
                }

                else -> {
                    if (statementState is UiState.Error) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = statementState.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }

                    Button(
                        onClick = {
                            pdfLauncher.launch(arrayOf("application/pdf"))
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("import_pdf_button")
                    ) {
                        Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("PDF Ekstre Seç (Gelir & Gider)")
                    }

                    FilledTonalButton(
                        onClick = {
                            documentLauncher.launch(
                                arrayOf(
                                    "text/csv",
                                    "text/comma-separated-values",
                                    "text/plain",
                                    "text/*"
                                )
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("import_doc_button")
                    ) {
                        Icon(Icons.Rounded.Description, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("CSV / TXT Ekstre Seç")
                    }

                    FilledTonalButton(
                        onClick = {
                            photoLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("import_image_button")
                    ) {
                        Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Ekstre Görseli / Ekran Görüntüsü Seç")
                    }

                    OutlinedButton(
                        onClick = { showTextInput = !showTextInput },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("import_text_toggle_button")
                    ) {
                        Icon(Icons.Rounded.ContentPaste, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (showTextInput) "Metin Alanını Gizle" else "Ekstre Metni / SMS Yapıştır")
                    }

                    if (showTextInput) {
                        OutlinedTextField(
                            value = rawText,
                            onValueChange = { rawText = it },
                            label = { Text("Ekstre satırlarını veya banka özet metnini yapıştırın") },
                            placeholder = { Text("Örn: 15.11.2026 MIGROS -1.240,50 TL\n18.11.2026 MAAŞ +48.500,00 TL\n20.11.2026 İGDAŞ FATURA -820,00 TL") },
                            minLines = 4,
                            maxLines = 8,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("statement_raw_text_input")
                        )
                        Button(
                            onClick = { onAnalyzeText(rawText) },
                            enabled = rawText.isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("analyze_raw_text_button")
                        ) {
                            Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Yapay Zeka ile Analiz Et")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatementReviewContent(
    result: StatementParseResult,
    accounts: List<BankAccount>,
    isSyncing: Boolean,
    onToggleTx: (String) -> Unit,
    onSetAllTxSelection: (Boolean, TransactionType?) -> Unit,
    onToggleTxType: (String) -> Unit,
    onUpdateTxCategory: (String, ExpenseCategory) -> Unit,
    onToggleBill: (String) -> Unit,
    onCommitImport: (createNewAccount: Boolean, targetAccountId: String?, applyDetectedBalance: Boolean) -> Unit,
    onReset: () -> Unit
) {
    val matchedExisting = remember(result, accounts) {
        val info = result.accountInfo
        if (info == null) {
            accounts.firstOrNull()
        } else {
            accounts.firstOrNull {
                info.ibanSuffix != "0000" && it.ibanSuffix == info.ibanSuffix
            } ?: accounts.firstOrNull {
                it.bankName.contains(info.bankName, ignoreCase = true) ||
                    info.bankName.contains(it.bankName, ignoreCase = true)
            }
        }
    }

    var createNewAccount by remember(result) {
        mutableStateOf(matchedExisting == null && (result.accountInfo != null || accounts.isEmpty()))
    }
    var selectedAccountId by remember(result) {
        mutableStateOf(matchedExisting?.id ?: accounts.firstOrNull()?.id)
    }
    var applyDetectedBalance by remember(result) {
        mutableStateOf(result.accountInfo?.detectedBalance != null)
    }
    var txFilter by remember(result) { mutableStateOf(StatementTxFilter.ALL) }

    LaunchedEffect(accounts) {
        if (selectedAccountId == null && accounts.isNotEmpty() && !createNewAccount) {
            selectedAccountId = accounts.first().id
        }
    }

    val selectedTxs = result.transactions.filter { it.selected }
    val selectedTxCount = selectedTxs.size
    val selectedBillCount = result.detectedBills.count { it.selected }
    val selectedIncomeTotal = selectedTxs.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
    val selectedExpenseTotal = selectedTxs.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
    val netTotal = selectedIncomeTotal - selectedExpenseTotal
    val duplicateCount = result.transactions.count { it.isDuplicate }

    val filteredTransactions = remember(result.transactions, txFilter) {
        when (txFilter) {
            StatementTxFilter.ALL -> result.transactions
            StatementTxFilter.INCOME -> result.transactions.filter { it.type == TransactionType.INCOME }
            StatementTxFilter.EXPENSE -> result.transactions.filter { it.type == TransactionType.EXPENSE }
        }
    }

    // Summary Card
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (result.pdfMetadata != null) Icons.Rounded.PictureAsPdf else Icons.Rounded.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = result.sourceLabel,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                result.pdfMetadata?.let { meta ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                    ) {
                        Text(
                            text = "${meta.pageCount} sayfa • ${formatFileSize(meta.fileSizeBytes)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }
            Text(
                text = result.summary,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Income / Expense / Net Breakdown Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatementTotalMiniChip(
                    label = "Seçili Gelir",
                    amount = "+${formatTry(selectedIncomeTotal)}",
                    color = IncomeGreen,
                    modifier = Modifier.weight(1f)
                )
                StatementTotalMiniChip(
                    label = "Seçili Gider",
                    amount = "-${formatTry(selectedExpenseTotal)}",
                    color = ExpenseCoral,
                    modifier = Modifier.weight(1f)
                )
                StatementTotalMiniChip(
                    label = "Net Etki",
                    amount = (if (netTotal >= 0) "+" else "") + formatTry(netTotal),
                    color = if (netTotal >= 0) IncomeGreen else ExpenseCoral,
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = buildString {
                    append("$selectedTxCount/${result.transactions.size} işlem • $selectedBillCount/${result.detectedBills.size} fatura seçili")
                    if (duplicateCount > 0) append(" • $duplicateCount mükerrer hariç tutuldu")
                },
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold
            )
        }
    }

    // Account Routing Section
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Rounded.AccountBalance,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Hedef Banka Hesabı",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
        }

        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val newAccLabel = result.accountInfo?.let {
                "Yeni: ${it.bankName} (••${it.ibanSuffix})"
            } ?: "Yeni Hesap Oluştur"
            FilterChip(
                selected = createNewAccount,
                onClick = { createNewAccount = true },
                label = { Text(newAccLabel) }
            )
            accounts.forEach { acc ->
                FilterChip(
                    selected = !createNewAccount && selectedAccountId == acc.id,
                    onClick = {
                        createNewAccount = false
                        selectedAccountId = acc.id
                    },
                    label = { Text("${acc.bankName} • ${acc.accountName}") }
                )
            }
        }

        val detectedBalance = result.accountInfo?.detectedBalance
        if (detectedBalance != null) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clickable { applyDetectedBalance = !applyDetectedBalance }
            ) {
                Checkbox(
                    checked = applyDetectedBalance,
                    onCheckedChange = { applyDetectedBalance = it }
                )
                Text(
                    text = "Ekstredeki bakiyeyi uygula (${formatTry(detectedBalance)})",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }

    // Extracted Transactions Section
    if (result.transactions.isNotEmpty()) {
        val incomeCount = result.transactions.count { it.type == TransactionType.INCOME }
        val expenseCount = result.transactions.count { it.type == TransactionType.EXPENSE }
        val activeFilterType = when (txFilter) {
            StatementTxFilter.ALL -> null
            StatementTxFilter.INCOME -> TransactionType.INCOME
            StatementTxFilter.EXPENSE -> TransactionType.EXPENSE
        }
        val allVisibleSelected = filteredTransactions.isNotEmpty() && filteredTransactions.all { it.selected }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Gelir & Gider İşlemleri ($selectedTxCount)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            if (filteredTransactions.isNotEmpty()) {
                TextButton(
                    onClick = { onSetAllTxSelection(!allVisibleSelected, activeFilterType) },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Text(if (allVisibleSelected) "Seçimi Kaldır" else "Tümünü Seç")
                }
            }
        }

        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = txFilter == StatementTxFilter.ALL,
                onClick = { txFilter = StatementTxFilter.ALL },
                label = { Text("${StatementTxFilter.ALL.labelTr} (${result.transactions.size})") }
            )
            FilterChip(
                selected = txFilter == StatementTxFilter.INCOME,
                onClick = { txFilter = StatementTxFilter.INCOME },
                label = { Text("${StatementTxFilter.INCOME.labelTr} ($incomeCount)") }
            )
            FilterChip(
                selected = txFilter == StatementTxFilter.EXPENSE,
                onClick = { txFilter = StatementTxFilter.EXPENSE },
                label = { Text("${StatementTxFilter.EXPENSE.labelTr} ($expenseCount)") }
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            filteredTransactions.forEach { tx ->
                StatementTxPreviewRow(
                    tx = tx,
                    onToggle = { onToggleTx(tx.tempId) },
                    onToggleType = { onToggleTxType(tx.tempId) },
                    onCategoryChange = { cat -> onUpdateTxCategory(tx.tempId, cat) }
                )
            }
        }
    }

    // Detected Bills Section
    if (result.detectedBills.isNotEmpty()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Rounded.CalendarMonth,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Fatura Takvimine Eklenecekler ($selectedBillCount)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            result.detectedBills.forEach { bill ->
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = if (bill.selected) 0.75f else 0.35f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onToggleBill(bill.tempId) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = bill.selected,
                            onCheckedChange = { onToggleBill(bill.tempId) }
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = bill.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Her ayın ${bill.dueDayOfMonth}. günü • ${bill.category.labelTr}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = formatTry(bill.amount),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = ExpenseCoral
                        )
                    }
                }
            }
        }
    }

    // Action Footer
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(
            onClick = onReset,
            enabled = !isSyncing,
            modifier = Modifier.minimumInteractiveComponentSize()
        ) {
            Text("Başka Ekstre")
        }
        Button(
            onClick = {
                onCommitImport(
                    createNewAccount,
                    if (createNewAccount) null else selectedAccountId,
                    applyDetectedBalance
                )
            },
            enabled = !isSyncing && (selectedTxCount > 0 || selectedBillCount > 0 || createNewAccount),
            modifier = Modifier
                .weight(1f)
                .height(50.dp)
                .testTag("confirm_statement_import_button")
        ) {
            if (isSyncing) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Yükleniyor...")
            } else {
                Text("Uygun Yerlere Yükle")
            }
        }
    }
}

@Composable
private fun StatementTotalMiniChip(
    label: String,
    amount: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = amount,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = color,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

private fun formatFileSize(bytes: Long): String {
    return when {
        bytes >= 1024L * 1024L -> String.format(java.util.Locale.forLanguageTag("tr-TR"), "%.1f MB", bytes / (1024.0 * 1024.0))
        bytes >= 1024L -> "${(bytes / 1024L).coerceAtLeast(1)} KB"
        else -> "$bytes B"
    }
}

@Composable
private fun StatementTxPreviewRow(
    tx: ExtractedStatementTx,
    onToggle: () -> Unit,
    onToggleType: () -> Unit,
    onCategoryChange: (ExpenseCategory) -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val isExpense = tx.type == TransactionType.EXPENSE
    val typeColor = if (isExpense) ExpenseCoral else IncomeGreen

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = if (tx.selected) 0.72f else 0.32f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = tx.selected,
                onCheckedChange = { onToggle() }
            )
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(tx.category.color.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = categoryIcon(tx.category),
                    contentDescription = tx.category.labelTr,
                    tint = tx.category.color,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = tx.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (tx.isDuplicate) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Text(
                                text = "Zaten kayıtlı",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = tx.dateLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = typeColor.copy(alpha = 0.15f),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable(onClick = onToggleType)
                    ) {
                        Text(
                            text = if (isExpense) "Gider" else "Gelir",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = typeColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Box {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = tx.category.color.copy(alpha = 0.15f),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { menuExpanded = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = tx.category.labelTr,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = tx.category.color,
                                    maxLines = 1
                                )
                                Icon(
                                    imageVector = Icons.Rounded.ExpandMore,
                                    contentDescription = "Kategori değiştir",
                                    tint = tx.category.color,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false }
                        ) {
                            ExpenseCategory.entries.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat.labelTr) },
                                    onClick = {
                                        onCategoryChange(cat)
                                        menuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = (if (isExpense) "-" else "+") + formatTry(tx.amount),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = typeColor
            )
        }
    }
}
