package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ShowChart
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.DonutLarge
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.TrendingDown
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.CategoryBreakdownItem
import com.example.model.formatCompactTry
import com.example.model.formatTry
import com.example.ui.components.CategoryDonutChart
import com.example.ui.components.TrendChartMode
import com.example.ui.components.VicoCategoryDistributionChart
import com.example.ui.components.VicoMonthlyTrendChart
import com.example.ui.components.categoryIcon
import com.example.ui.theme.ExpenseCoral
import com.example.ui.theme.IncomeGreen
import com.example.viewmodel.VaultDashboardMetrics

enum class TrendRangeOption(val labelTr: String, val monthsCount: Int) {
    THREE_MONTHS("3 Ay", 3),
    SIX_MONTHS("6 Ay", 6),
    TWELVE_MONTHS("12 Ay", 12)
}

enum class CategoryPeriodOption(val labelTr: String) {
    THIS_MONTH("Bu Ay"),
    LAST_MONTH("Geçen Ay"),
    SIX_MONTHS("Son 6 Ay")
}

enum class CategoryChartStyle(val labelTr: String) {
    DONUT("Halka"),
    BAR("Sütun")
}

@Composable
fun VisualizationDashboardScreen(
    metrics: VaultDashboardMetrics,
    modifier: Modifier = Modifier
) {
    var trendRange by rememberSaveable { mutableStateOf(TrendRangeOption.SIX_MONTHS) }
    var trendMode by rememberSaveable { mutableStateOf(TrendChartMode.AREA_LINE) }
    var categoryPeriod by rememberSaveable { mutableStateOf(CategoryPeriodOption.THIS_MONTH) }
    var categoryChartStyle by rememberSaveable { mutableStateOf(CategoryChartStyle.DONUT) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.Insights,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Görselleştirme Panosu",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        visualizationDashboardItems(
            metrics = metrics,
            trendRange = trendRange,
            onTrendRangeChange = { trendRange = it },
            trendMode = trendMode,
            onTrendModeChange = { trendMode = it },
            categoryPeriod = categoryPeriod,
            onCategoryPeriodChange = { categoryPeriod = it },
            categoryChartStyle = categoryChartStyle,
            onCategoryChartStyleChange = { categoryChartStyle = it }
        )
    }
}

fun LazyListScope.visualizationDashboardItems(
    metrics: VaultDashboardMetrics,
    trendRange: TrendRangeOption,
    onTrendRangeChange: (TrendRangeOption) -> Unit,
    trendMode: TrendChartMode,
    onTrendModeChange: (TrendChartMode) -> Unit,
    categoryPeriod: CategoryPeriodOption,
    onCategoryPeriodChange: (CategoryPeriodOption) -> Unit,
    categoryChartStyle: CategoryChartStyle,
    onCategoryChartStyleChange: (CategoryChartStyle) -> Unit
) {
    // 1. KPI Summary Strip
    item {
        val trendPoints = remember(metrics.monthlyTrend12Months, trendRange) {
            val source = metrics.monthlyTrend12Months.ifEmpty { metrics.monthlyTrend }
            source.takeLast(trendRange.monthsCount)
        }
        val activeMonthsCount = trendPoints.count { it.expense > 0.0 }.coerceAtLeast(1)
        val avgMonthlyExpense = trendPoints.sumOf { it.expense } / activeMonthsCount
        val savingsRatePct = if (metrics.monthlyIncome > 0.0) {
            (((metrics.monthlyIncome - metrics.monthlyExpense) / metrics.monthlyIncome) * 100.0)
                .toInt()
                .coerceIn(-99, 100)
        } else {
            null
        }
        val topCategory = metrics.categoryBreakdown.firstOrNull()

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiMetricCard(
                    title = "Bu Ay Harcama",
                    value = formatCompactTry(metrics.monthlyExpense),
                    badgeText = metrics.monthOverMonthSpendingDeltaPct?.let { delta ->
                        val sign = if (delta >= 0) "+" else ""
                        "$sign%$delta geçen aya göre"
                    },
                    badgeColor = if ((metrics.monthOverMonthSpendingDeltaPct ?: 0) <= 0) IncomeGreen else ExpenseCoral,
                    isPositiveTrend = (metrics.monthOverMonthSpendingDeltaPct ?: 0) <= 0,
                    modifier = Modifier.weight(1f)
                )
                KpiMetricCard(
                    title = "Aylık Ort. Gider",
                    value = formatCompactTry(avgMonthlyExpense),
                    badgeText = "${trendRange.labelTr} ortalaması",
                    badgeColor = MaterialTheme.colorScheme.primary,
                    isPositiveTrend = null,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiMetricCard(
                    title = "Tasarruf Oranı",
                    value = savingsRatePct?.let { "%$it" } ?: "—",
                    badgeText = if (savingsRatePct != null && savingsRatePct >= 20) "Sağlıklı nakit akışı" else "Gelire göre oran",
                    badgeColor = if ((savingsRatePct ?: 0) >= 0) IncomeGreen else ExpenseCoral,
                    isPositiveTrend = null,
                    modifier = Modifier.weight(1f)
                )
                KpiMetricCard(
                    title = "En Yüksek Kategori",
                    value = topCategory?.displayLabel?.substringBefore(" ") ?: "Yok",
                    badgeText = topCategory?.let {
                        "${formatCompactTry(it.amount)} (%${(it.percentage * 100).toInt()})"
                    } ?: "Harcama bekleniyor",
                    badgeColor = topCategory?.displayColor ?: MaterialTheme.colorScheme.onSurfaceVariant,
                    isPositiveTrend = null,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }

    // 2. Monthly Spending Trends Card (Vico)
    item {
        val trendPoints = remember(metrics.monthlyTrend12Months, metrics.monthlyTrend, trendRange) {
            val source = metrics.monthlyTrend12Months.ifEmpty { metrics.monthlyTrend }
            source.takeLast(trendRange.monthsCount)
        }
        val periodTotalExpense = trendPoints.sumOf { it.expense }
        val peakMonth = trendPoints.maxByOrNull { it.expense }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("monthly_spending_trends_card")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Aylık Harcama Trendi",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Gelir ve gider eğiliminizi dönemlere göre inceleyin",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TrendRangeOption.entries.forEach { range ->
                        FilterChip(
                            selected = trendRange == range,
                            onClick = { onTrendRangeChange(range) },
                            label = { Text(range.labelTr) },
                            modifier = Modifier.testTag("trend_range_${range.monthsCount}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    TrendChartMode.entries.forEachIndexed { idx, mode ->
                        SegmentedButton(
                            selected = trendMode == mode,
                            onClick = { onTrendModeChange(mode) },
                            shape = SegmentedButtonDefaults.itemShape(idx, TrendChartMode.entries.size),
                            icon = {
                                Icon(
                                    imageVector = if (mode == TrendChartMode.AREA_LINE) Icons.AutoMirrored.Rounded.ShowChart else Icons.Rounded.BarChart,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            modifier = Modifier.testTag("trend_mode_${mode.name.lowercase()}")
                        ) {
                            Text(mode.labelTr, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                VicoMonthlyTrendChart(
                    points = trendPoints,
                    mode = trendMode
                )

                if (periodTotalExpense > 0.0) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${trendRange.labelTr} Toplam Harcama",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = formatTry(periodTotalExpense),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (peakMonth != null && peakMonth.expense > 0.0) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "Zirve Ay (${peakMonth.monthLabel})",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = formatTry(peakMonth.expense),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = ExpenseCoral
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 3. Category Distribution Card (Donut + Vico Column + Ranked Breakdown Bars)
    item {
        val activeBreakdown = when (categoryPeriod) {
            CategoryPeriodOption.THIS_MONTH -> metrics.categoryBreakdown
            CategoryPeriodOption.LAST_MONTH -> metrics.lastMonthCategoryBreakdown
            CategoryPeriodOption.SIX_MONTHS -> metrics.sixMonthCategoryBreakdown
        }
        val activeTotal = when (categoryPeriod) {
            CategoryPeriodOption.THIS_MONTH -> metrics.monthlyExpense
            CategoryPeriodOption.LAST_MONTH -> metrics.lastMonthExpense
            CategoryPeriodOption.SIX_MONTHS -> metrics.sixMonthExpense
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("category_distribution_card")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Kategori Dağılımı",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Harcamalarınızın kategorilere göre payı ve tutarı",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CategoryPeriodOption.entries.forEach { period ->
                        FilterChip(
                            selected = categoryPeriod == period,
                            onClick = { onCategoryPeriodChange(period) },
                            label = { Text(period.labelTr) },
                            modifier = Modifier.testTag("cat_period_${period.name.lowercase()}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    CategoryChartStyle.entries.forEachIndexed { idx, style ->
                        SegmentedButton(
                            selected = categoryChartStyle == style,
                            onClick = { onCategoryChartStyleChange(style) },
                            shape = SegmentedButtonDefaults.itemShape(idx, CategoryChartStyle.entries.size),
                            icon = {
                                Icon(
                                    imageVector = if (style == CategoryChartStyle.DONUT) Icons.Rounded.DonutLarge else Icons.Rounded.BarChart,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            modifier = Modifier.testTag("cat_style_${style.name.lowercase()}")
                        ) {
                            Text(style.labelTr)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (categoryChartStyle == CategoryChartStyle.DONUT) {
                    CategoryDonutChart(
                        items = activeBreakdown,
                        totalExpense = activeTotal
                    )
                } else {
                    VicoCategoryDistributionChart(items = activeBreakdown)
                }

                if (activeBreakdown.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Kategori Sıralaması",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        activeBreakdown.forEach { item ->
                            CategoryRankedDistributionRow(item = item)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KpiMetricCard(
    title: String,
    value: String,
    badgeText: String?,
    badgeColor: Color,
    isPositiveTrend: Boolean?,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(18.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!badgeText.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isPositiveTrend != null) {
                        Icon(
                            imageVector = if (isPositiveTrend) Icons.Rounded.TrendingDown else Icons.Rounded.TrendingUp,
                            contentDescription = null,
                            tint = badgeColor,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    Text(
                        text = badgeText,
                        style = MaterialTheme.typography.labelSmall,
                        color = badgeColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoryRankedDistributionRow(item: CategoryBreakdownItem) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(item.displayColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = categoryIcon(item.category, item.customIconKey),
                    contentDescription = item.displayLabel,
                    tint = item.displayColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = item.displayLabel,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "${formatTry(item.amount)} (%${(item.percentage * 100).toInt()})",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { item.percentage.coerceIn(0f, 1f) },
            color = item.displayColor,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
        )
    }
}
