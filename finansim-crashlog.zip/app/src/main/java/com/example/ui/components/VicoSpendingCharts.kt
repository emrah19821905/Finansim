package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.CategoryBreakdownItem
import com.example.model.MonthlyChartPoint
import com.example.model.formatCompactTry
import com.example.ui.theme.ExpenseCoral
import com.example.ui.theme.IncomeGreen
import com.patrykandpatrick.vico.compose.cartesian.CartesianChartHost
import com.patrykandpatrick.vico.compose.cartesian.axis.rememberBottom
import com.patrykandpatrick.vico.compose.cartesian.axis.rememberStart
import com.patrykandpatrick.vico.compose.cartesian.layer.rememberColumnCartesianLayer
import com.patrykandpatrick.vico.compose.cartesian.layer.rememberLine
import com.patrykandpatrick.vico.compose.cartesian.layer.rememberLineCartesianLayer
import com.patrykandpatrick.vico.compose.cartesian.marker.rememberDefaultCartesianMarker
import com.patrykandpatrick.vico.compose.cartesian.rememberCartesianChart
import com.patrykandpatrick.vico.compose.common.ProvideVicoTheme
import com.patrykandpatrick.vico.compose.common.component.rememberLineComponent
import com.patrykandpatrick.vico.compose.common.component.rememberTextComponent
import com.patrykandpatrick.vico.compose.common.fill
import com.patrykandpatrick.vico.compose.common.shader.verticalGradient
import com.patrykandpatrick.vico.compose.m3.common.rememberM3VicoTheme
import com.patrykandpatrick.vico.core.cartesian.axis.HorizontalAxis
import com.patrykandpatrick.vico.core.cartesian.axis.VerticalAxis
import com.patrykandpatrick.vico.core.cartesian.data.CartesianChartModelProducer
import com.patrykandpatrick.vico.core.cartesian.data.CartesianValueFormatter
import com.patrykandpatrick.vico.core.cartesian.data.columnSeries
import com.patrykandpatrick.vico.core.cartesian.data.lineSeries
import com.patrykandpatrick.vico.core.cartesian.layer.ColumnCartesianLayer
import com.patrykandpatrick.vico.core.cartesian.layer.LineCartesianLayer
import com.patrykandpatrick.vico.core.common.data.ExtraStore
import com.patrykandpatrick.vico.core.common.shader.ShaderProvider
import com.patrykandpatrick.vico.core.common.shape.CorneredShape
import kotlin.math.roundToInt

enum class TrendChartMode(val labelTr: String) {
    AREA_LINE("Trend Çizgisi"),
    GROUPED_COLUMNS("Sütun Karşılaştırma")
}

private val MonthLabelsExtraKey = ExtraStore.Key<List<String>>()
private val CategoryLabelsExtraKey = ExtraStore.Key<List<String>>()

@Composable
fun VicoMonthlyTrendChart(
    points: List<MonthlyChartPoint>,
    mode: TrendChartMode,
    modifier: Modifier = Modifier
) {
    val safePoints = remember(points) {
        points.map { pt ->
            pt.copy(
                monthLabel = pt.monthLabel.ifBlank { "-" },
                income = if (pt.income.isFinite() && pt.income >= 0.0) pt.income else 0.0,
                expense = if (pt.expense.isFinite() && pt.expense >= 0.0) pt.expense else 0.0
            )
        }
    }
    val hasValues = safePoints.any { it.income > 0.0 || it.expense > 0.0 }
    if (safePoints.isEmpty() || !hasValues) {
        EmptyChartPlaceholder(
            message = "Aylık harcama trendi için henüz yeterli veri yok. İşlem eklediğinizde veya ekstre yüklediğinizde grafik otomatik oluşur.",
            modifier = modifier
        )
        return
    }

    val modelProducer = remember(mode) { CartesianChartModelProducer() }
    LaunchedEffect(safePoints, mode) {
        modelProducer.runTransaction {
            val expenseValues = safePoints.map { it.expense }
            val incomeValues = safePoints.map { it.income }
            if (mode == TrendChartMode.AREA_LINE) {
                lineSeries {
                    series(expenseValues)
                    series(incomeValues)
                }
            } else {
                columnSeries {
                    series(expenseValues)
                    series(incomeValues)
                }
            }
            extras { store ->
                store[MonthLabelsExtraKey] = safePoints.map { it.monthLabel }
            }
        }
    }

    val bottomFormatter = remember {
        CartesianValueFormatter { context, x, _ ->
            val labels = context.model.extraStore.getOrNull(MonthLabelsExtraKey).orEmpty()
            labels.getOrElse(x.roundToInt()) { " " }.ifEmpty { " " }
        }
    }
    val startFormatter = remember {
        CartesianValueFormatter { _, y, _ ->
            formatCompactTry(y).ifEmpty { " " }
        }
    }
    val markerLabel = rememberTextComponent(
        color = MaterialTheme.colorScheme.onSurface
    )

    Column(modifier = modifier.fillMaxWidth()) {
        ProvideVicoTheme(rememberM3VicoTheme()) {
            key(mode) {
                if (mode == TrendChartMode.AREA_LINE) {
                    CartesianChartHost(
                        chart = rememberCartesianChart(
                            rememberLineCartesianLayer(
                                lineProvider = LineCartesianLayer.LineProvider.series(
                                    LineCartesianLayer.rememberLine(
                                        fill = LineCartesianLayer.LineFill.single(fill(ExpenseCoral)),
                                        areaFill = LineCartesianLayer.AreaFill.single(
                                            fill(
                                                ShaderProvider.verticalGradient(
                                                    arrayOf(ExpenseCoral.copy(alpha = 0.34f), Color.Transparent)
                                                )
                                            )
                                        )
                                    ),
                                    LineCartesianLayer.rememberLine(
                                        fill = LineCartesianLayer.LineFill.single(fill(IncomeGreen)),
                                        areaFill = LineCartesianLayer.AreaFill.single(
                                            fill(
                                                ShaderProvider.verticalGradient(
                                                    arrayOf(IncomeGreen.copy(alpha = 0.22f), Color.Transparent)
                                                )
                                            )
                                        )
                                    )
                                )
                            ),
                            startAxis = VerticalAxis.rememberStart(valueFormatter = startFormatter),
                            bottomAxis = HorizontalAxis.rememberBottom(valueFormatter = bottomFormatter),
                            marker = rememberDefaultCartesianMarker(label = markerLabel)
                        ),
                        modelProducer = modelProducer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(230.dp)
                    )
                } else {
                    CartesianChartHost(
                        chart = rememberCartesianChart(
                            rememberColumnCartesianLayer(
                                columnProvider = ColumnCartesianLayer.ColumnProvider.series(
                                    rememberLineComponent(
                                        fill = fill(ExpenseCoral),
                                        thickness = 12.dp,
                                        shape = CorneredShape.rounded(topLeftPercent = 35, topRightPercent = 35)
                                    ),
                                    rememberLineComponent(
                                        fill = fill(IncomeGreen),
                                        thickness = 12.dp,
                                        shape = CorneredShape.rounded(topLeftPercent = 35, topRightPercent = 35)
                                    )
                                )
                            ),
                            startAxis = VerticalAxis.rememberStart(valueFormatter = startFormatter),
                            bottomAxis = HorizontalAxis.rememberBottom(valueFormatter = bottomFormatter),
                            marker = rememberDefaultCartesianMarker(label = markerLabel)
                        ),
                        modelProducer = modelProducer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(230.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ChartSeriesLegendDot(color = ExpenseCoral, label = "Harcama")
            Spacer(modifier = Modifier.width(20.dp))
            ChartSeriesLegendDot(color = IncomeGreen, label = "Gelir")
        }
    }
}

@Composable
fun VicoCategoryDistributionChart(
    items: List<CategoryBreakdownItem>,
    modifier: Modifier = Modifier
) {
    val topItems = remember(items) {
        items.filter { it.amount.isFinite() && it.amount > 0.0 }.take(7)
    }
    if (topItems.isEmpty()) {
        EmptyChartPlaceholder(
            message = "Seçilen dönem için kategori harcaması bulunmuyor.",
            modifier = modifier
        )
        return
    }

    val modelProducer = remember { CartesianChartModelProducer() }
    LaunchedEffect(topItems) {
        modelProducer.runTransaction {
            columnSeries {
                series(topItems.map { it.amount })
            }
            extras { store ->
                store[CategoryLabelsExtraKey] = topItems.map { item ->
                    item.displayLabel.trim().substringBefore(" ").take(8).ifBlank { "Diğer" }
                }
            }
        }
    }

    val bottomFormatter = remember {
        CartesianValueFormatter { context, x, _ ->
            val labels = context.model.extraStore.getOrNull(CategoryLabelsExtraKey).orEmpty()
            labels.getOrElse(x.roundToInt()) { " " }.ifEmpty { " " }
        }
    }
    val startFormatter = remember {
        CartesianValueFormatter { _, y, _ ->
            formatCompactTry(y).ifEmpty { " " }
        }
    }
    val markerLabel = rememberTextComponent(
        color = MaterialTheme.colorScheme.onSurface
    )

    ProvideVicoTheme(rememberM3VicoTheme()) {
        CartesianChartHost(
            chart = rememberCartesianChart(
                rememberColumnCartesianLayer(
                    columnProvider = ColumnCartesianLayer.ColumnProvider.series(
                        rememberLineComponent(
                            fill = fill(MaterialTheme.colorScheme.primary),
                            thickness = 18.dp,
                            shape = CorneredShape.rounded(topLeftPercent = 35, topRightPercent = 35)
                        )
                    )
                ),
                startAxis = VerticalAxis.rememberStart(valueFormatter = startFormatter),
                bottomAxis = HorizontalAxis.rememberBottom(valueFormatter = bottomFormatter),
                marker = rememberDefaultCartesianMarker(label = markerLabel)
            ),
            modelProducer = modelProducer,
            modifier = modifier
                .fillMaxWidth()
                .height(220.dp)
        )
    }
}

@Composable
private fun EmptyChartPlaceholder(
    message: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.ShowChart,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ChartSeriesLegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
