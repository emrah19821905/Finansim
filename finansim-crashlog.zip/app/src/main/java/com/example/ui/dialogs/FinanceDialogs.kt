package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.model.AccountType
import com.example.model.ActivityAlert
import com.example.model.AlertSeverity
import com.example.model.BankAccount
import com.example.model.BillReminder
import com.example.model.CustomCategory
import com.example.model.ExpenseCategory
import com.example.model.FinancialTransaction
import com.example.model.TransactionType
import com.example.model.formatDateTimeShort
import com.example.model.formatTry
import com.example.ui.components.customCategoryIcon
import com.example.ui.theme.ExpenseCoral
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.WarningAmber
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TransactionEditorSheet(
    existing: FinancialTransaction?,
    accounts: List<BankAccount>,
    customCategories: List<CustomCategory> = emptyList(),
    onSuggestCategory: (title: String, type: TransactionType, amount: Double, onResult: (ExpenseCategory, Int) -> Unit, onError: () -> Unit) -> Unit,
    onDismiss: () -> Unit,
    onSave: (FinancialTransaction) -> Unit
) {
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var amountText by remember { mutableStateOf(existing?.amount?.let { if (it > 0) it.toString() else "" } ?: "") }
    var txType by remember { mutableStateOf(existing?.type ?: TransactionType.EXPENSE) }
    var category by remember { mutableStateOf(existing?.category ?: ExpenseCategory.MARKET) }
    var selectedCustomCategory by remember {
        mutableStateOf(customCategories.firstOrNull { it.id == existing?.customCategoryId })
    }
    var selectedAccountId by remember { mutableStateOf(existing?.accountId ?: accounts.firstOrNull()?.id ?: "") }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var aiSuggested by remember { mutableStateOf(existing?.aiCategorized ?: false) }
    var aiConf by remember { mutableIntStateOf(existing?.aiConfidence ?: 0) }
    var isAiSuggesting by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Text(
                text = if (existing == null) "Yeni Gelir / Gider Ekle" else "İşlemi Düzenle",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(14.dp))

            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                TransactionType.entries.forEachIndexed { idx, typeOption ->
                    SegmentedButton(
                        selected = txType == typeOption,
                        onClick = {
                            txType = typeOption
                            if (selectedCustomCategory != null &&
                                selectedCustomCategory!!.forIncome != (typeOption == TransactionType.INCOME)
                            ) {
                                selectedCustomCategory = null
                            }
                            if (typeOption == TransactionType.INCOME && category !in ExpenseCategory.incomeCategories()) {
                                category = ExpenseCategory.MAAS
                            } else if (typeOption == TransactionType.EXPENSE && category == ExpenseCategory.MAAS) {
                                category = ExpenseCategory.MARKET
                            }
                        },
                        shape = SegmentedButtonDefaults.itemShape(idx, TransactionType.entries.size)
                    ) {
                        Text(typeOption.labelTr)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Açıklama / Mağaza (ör. Migros, Maaş)") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tx_title_input")
            )

            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it.replace(",", ".") },
                label = { Text("Tutar (₺)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tx_amount_input")
            )

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Kategori" + if (aiSuggested) " (AI %$aiConf)" else "",
                    style = MaterialTheme.typography.titleSmall
                )
                OutlinedButton(
                    onClick = {
                        if (title.isNotBlank() && !isAiSuggesting) {
                            isAiSuggesting = true
                            val parsed = amountText.toDoubleOrNull() ?: 0.0
                            onSuggestCategory(
                                title,
                                txType,
                                parsed,
                                { cat, conf ->
                                    category = cat
                                    selectedCustomCategory = null
                                    aiSuggested = true
                                    aiConf = conf
                                    isAiSuggesting = false
                                },
                                {
                                    isAiSuggesting = false
                                }
                            )
                        }
                    },
                    enabled = title.isNotBlank() && !isAiSuggesting
                ) {
                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isAiSuggesting) "Sınıflandırılıyor..." else "AI ile Sınıflandır")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            val matchingCustomCats = customCategories.filter { it.forIncome == (txType == TransactionType.INCOME) }
            val availableCats = if (txType == TransactionType.INCOME) {
                ExpenseCategory.incomeCategories()
            } else {
                ExpenseCategory.expenseCategories()
            }
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                matchingCustomCats.forEach { customCat ->
                    FilterChip(
                        selected = selectedCustomCategory?.id == customCat.id,
                        onClick = {
                            selectedCustomCategory = customCat
                            category = if (txType == TransactionType.INCOME) ExpenseCategory.MAAS else ExpenseCategory.DIGER
                            aiSuggested = false
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = customCategoryIcon(customCat.iconKey),
                                contentDescription = null,
                                tint = Color(customCat.colorHex),
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        label = { Text(customCat.name) }
                    )
                }
                availableCats.forEach { cat ->
                    FilterChip(
                        selected = selectedCustomCategory == null && category == cat,
                        onClick = {
                            selectedCustomCategory = null
                            category = cat
                            aiSuggested = false
                        },
                        label = { Text(cat.labelTr) }
                    )
                }
            }

            if (accounts.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text("Bağlı Banka Hesabı", style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    accounts.forEach { acc ->
                        FilterChip(
                            selected = selectedAccountId == acc.id,
                            onClick = { selectedAccountId = acc.id },
                            label = { Text("${acc.bankName} • ${acc.accountName}") }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Not (isteğe bağlı)") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(18.dp))
            val parsedAmount = amountText.toDoubleOrNull() ?: 0.0
            val matchedAccount = accounts.firstOrNull { it.id == selectedAccountId }
            Button(
                onClick = {
                    val tx = (existing ?: FinancialTransaction()).copy(
                        title = title.trim(),
                        amount = parsedAmount,
                        type = txType,
                        category = category,
                        customCategoryId = selectedCustomCategory?.id ?: "",
                        customCategoryName = selectedCustomCategory?.name ?: "",
                        customCategoryColorHex = selectedCustomCategory?.colorHex ?: 0L,
                        customCategoryIconKey = selectedCustomCategory?.iconKey ?: "",
                        accountId = matchedAccount?.id ?: "",
                        accountName = matchedAccount?.let { "${it.bankName} • ${it.accountName}" } ?: "Genel",
                        note = note.trim(),
                        aiCategorized = aiSuggested,
                        aiConfidence = aiConf
                    )
                    onSave(tx)
                },
                enabled = title.isNotBlank() && parsedAmount > 0.0,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_tx_button")
            ) {
                Text(if (existing == null) "Şifrele ve Kaydet" else "Güncelle")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountEditorDialog(
    existing: BankAccount?,
    onDismiss: () -> Unit,
    onSave: (BankAccount) -> Unit,
    onDelete: (() -> Unit)? = null
) {
    var bankName by remember { mutableStateOf(existing?.bankName ?: "") }
    var accountName by remember { mutableStateOf(existing?.accountName ?: "Vadesiz TL") }
    var accountType by remember { mutableStateOf(existing?.accountType ?: AccountType.CHECKING) }
    var ibanSuffix by remember { mutableStateOf(existing?.ibanSuffix ?: "") }
    var balanceText by remember { mutableStateOf(existing?.balance?.toString() ?: "0") }
    var colorHex by remember { mutableLongStateOf(existing?.colorHex ?: 0xFF0F6B4E) }
    var typeExpanded by remember { mutableStateOf(false) }

    val palette = listOf(0xFF0F6B4E, 0xFF1D4ED8, 0xFF7C3AED, 0xFFB5891C, 0xFFBE123C, 0xFF0F766E)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Banka Hesabı Ekle" else "Hesabı Düzenle") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = bankName,
                    onValueChange = { bankName = it },
                    label = { Text("Banka Adı (ör. Garanti BBVA, Ziraat)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("account_bank_input")
                )
                OutlinedTextField(
                    value = accountName,
                    onValueChange = { accountName = it },
                    label = { Text("Hesap Takma Adı") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                ExposedDropdownMenuBox(
                    expanded = typeExpanded,
                    onExpandedChange = { typeExpanded = it }
                ) {
                    OutlinedTextField(
                        value = accountType.labelTr,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Hesap Türü") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeExpanded) },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable, enabled = true)
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = typeExpanded,
                        onDismissRequest = { typeExpanded = false }
                    ) {
                        AccountType.entries.forEach { t ->
                            DropdownMenuItem(
                                text = { Text(t.labelTr) },
                                onClick = {
                                    accountType = t
                                    typeExpanded = false
                                }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = ibanSuffix,
                    onValueChange = { if (it.length <= 4) ibanSuffix = it.filter { ch -> ch.isDigit() } },
                    label = { Text("IBAN / Kart Son 4 Hane") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = balanceText,
                    onValueChange = { balanceText = it.replace(",", ".") },
                    label = { Text("Güncel Bakiye (₺)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("account_balance_input")
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    palette.forEach { hex ->
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(Color(hex))
                                .clickable { colorHex = hex },
                            contentAlignment = Alignment.Center
                        ) {
                            if (colorHex == hex) {
                                Icon(
                                    Icons.Rounded.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            val bal = balanceText.toDoubleOrNull()
            Button(
                onClick = {
                    val acc = (existing ?: BankAccount()).copy(
                        bankName = bankName.trim(),
                        accountName = accountName.trim().ifBlank { "Ana Hesap" },
                        accountType = accountType,
                        ibanSuffix = ibanSuffix.padStart(4, '0'),
                        balance = bal ?: 0.0,
                        colorHex = colorHex,
                        updatedAtMillis = System.currentTimeMillis()
                    )
                    onSave(acc)
                },
                enabled = bankName.isNotBlank() && bal != null,
                modifier = Modifier.testTag("save_account_button")
            ) {
                Text("Kaydet")
            }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text("Sil", color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = onDismiss) { Text("İptal") }
            }
        }
    )
}

@Composable
fun AccountTransferDialog(
    accounts: List<BankAccount>,
    onDismiss: () -> Unit,
    onTransfer: (from: BankAccount, to: BankAccount, amount: Double, note: String) -> Unit
) {
    if (accounts.size < 2) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Hesap Transferi") },
            text = { Text("Hesaplar arası transfer için en az 2 banka hesabı eklemelisiniz.") },
            confirmButton = { TextButton(onClick = onDismiss) { Text("Tamam") } }
        )
        return
    }
    var fromAcc by remember { mutableStateOf(accounts[0]) }
    var toAcc by remember { mutableStateOf(accounts[1]) }
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Hesaplar Arası Transfer") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Gönderen Hesap", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    accounts.forEach { acc ->
                        FilterChip(
                            selected = fromAcc.id == acc.id,
                            onClick = { fromAcc = acc },
                            label = { Text("${acc.bankName} (${formatTry(acc.balance)})") }
                        )
                    }
                }
                Text("Alıcı Hesap", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    accounts.forEach { acc ->
                        FilterChip(
                            selected = toAcc.id == acc.id,
                            onClick = { toAcc = acc },
                            label = { Text("${acc.bankName} (${formatTry(acc.balance)})") }
                        )
                    }
                }
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.replace(",", ".") },
                    label = { Text("Transfer Tutarı (₺)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Açıklama (isteğe bağlı)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            val amt = amountText.toDoubleOrNull() ?: 0.0
            Button(
                onClick = { onTransfer(fromAcc, toAcc, amt, note.trim()) },
                enabled = amt > 0.0 && fromAcc.id != toAcc.id
            ) {
                Text("Transfer Et")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BudgetGoalDialog(
    initialCategory: ExpenseCategory = ExpenseCategory.MARKET,
    initialLimit: Double = 5000.0,
    onDismiss: () -> Unit,
    onSave: (ExpenseCategory, Double) -> Unit
) {
    var category by remember { mutableStateOf(initialCategory) }
    var limitText by remember { mutableStateOf(initialLimit.toInt().toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Aylık Bütçe Hedefi") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    ExpenseCategory.expenseCategories().forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat.labelTr) }
                        )
                    }
                }
                OutlinedTextField(
                    value = limitText,
                    onValueChange = { limitText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Aylık Harcama Limiti (₺)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            val limit = limitText.toDoubleOrNull() ?: 0.0
            Button(
                onClick = { onSave(category, limit) },
                enabled = limit > 0.0
            ) {
                Text("Hedefi Kaydet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        }
    )
}

@Composable
fun BillEditorDialog(
    existing: BillReminder?,
    accounts: List<BankAccount>,
    onDismiss: () -> Unit,
    onSave: (BillReminder) -> Unit
) {
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var amountText by remember { mutableStateOf(existing?.amount?.let { if (it > 0) it.toString() else "" } ?: "") }
    var dayText by remember { mutableStateOf((existing?.dueDayOfMonth ?: Calendar.getInstance().get(Calendar.DAY_OF_MONTH)).toString()) }
    var reminderDaysText by remember { mutableStateOf((existing?.reminderDaysBefore ?: 3).toString()) }
    var recurring by remember { mutableStateOf(existing?.recurringMonthly ?: true) }
    var selectedAccountId by remember { mutableStateOf(existing?.accountId ?: accounts.firstOrNull()?.id ?: "") }
    var note by remember { mutableStateOf(existing?.note ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Fatura Ekle" else "Faturayı Düzenle") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Fatura / Ödeme Adı (ör. Elektrik, Kira)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("bill_title_input")
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.replace(",", ".") },
                    label = { Text("Tahmini / Sabit Tutar (₺)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("bill_amount_input")
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = dayText,
                        onValueChange = { dayText = it.filter { c -> c.isDigit() }.take(2) },
                        label = { Text("Ayın Günü (1-31)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = reminderDaysText,
                        onValueChange = { reminderDaysText = it.filter { c -> c.isDigit() }.take(2) },
                        label = { Text("Kaç Gün Önce Uyar") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { recurring = !recurring }
                ) {
                    Checkbox(checked = recurring, onCheckedChange = { recurring = it })
                    Text("Her ay tekrarlayan fatura", style = MaterialTheme.typography.bodyMedium)
                }
                if (accounts.isNotEmpty()) {
                    Text("Ödeme Hesabı", style = MaterialTheme.typography.labelMedium)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        accounts.forEach { acc ->
                            FilterChip(
                                selected = selectedAccountId == acc.id,
                                onClick = { selectedAccountId = acc.id },
                                label = { Text(acc.bankName) }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Not") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            val amt = amountText.toDoubleOrNull() ?: 0.0
            val day = (dayText.toIntOrNull() ?: 15).coerceIn(1, 31)
            val remDays = (reminderDaysText.toIntOrNull() ?: 3).coerceIn(0, 14)
            Button(
                onClick = {
                    val cal = Calendar.getInstance().apply {
                        val maxDay = getActualMaximum(Calendar.DAY_OF_MONTH)
                        set(Calendar.DAY_OF_MONTH, day.coerceAtMost(maxDay))
                    }
                    val bill = (existing ?: BillReminder()).copy(
                        title = title.trim(),
                        amount = amt,
                        dueDayOfMonth = day,
                        dueDateMillis = cal.timeInMillis,
                        reminderDaysBefore = remDays,
                        recurringMonthly = recurring,
                        accountId = selectedAccountId,
                        note = note.trim()
                    )
                    onSave(bill)
                },
                enabled = title.isNotBlank() && amt > 0.0,
                modifier = Modifier.testTag("save_bill_button")
            ) {
                Text("Kaydet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        }
    )
}

@Composable
fun ChangePinDialog(
    onDismiss: () -> Unit,
    onChangePin: (currentPin: String, newPin: String, onDone: (Result<Unit>) -> Unit) -> Unit
) {
    var currentPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Kasa PIN Kodunu Değiştir") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = currentPin,
                    onValueChange = { if (it.length <= 6) currentPin = it.filter { c -> c.isDigit() } },
                    label = { Text("Mevcut 6 Haneli PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = newPin,
                    onValueChange = { if (it.length <= 6) newPin = it.filter { c -> c.isDigit() } },
                    label = { Text("Yeni 6 Haneli PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorMsg != null) {
                    Text(errorMsg!!, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onChangePin(currentPin, newPin) { res ->
                        res.fold(
                            onSuccess = { onDismiss() },
                            onFailure = { errorMsg = it.localizedMessage ?: "PIN değiştirilemedi." }
                        )
                    }
                },
                enabled = currentPin.length == 6 && newPin.length == 6
            ) {
                Text("Güncelle")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlertsBottomSheet(
    alerts: List<ActivityAlert>,
    onMarkAllRead: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Anlık Harcama ve Uyarı Bildirimleri",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                if (alerts.any { !it.isReadFlag }) {
                    TextButton(onClick = onMarkAllRead) {
                        Text("Tümünü Okundu Yap")
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            if (alerts.isEmpty()) {
                Text(
                    text = "Henüz anlık hareket bildirimi yok. Yeni bir harcama veya fatura işlemi yaptığınızda burada görünür.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 24.dp)
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    alerts.take(25).forEach { alert ->
                        val badgeColor = when (alert.severity) {
                            AlertSeverity.CRITICAL -> ExpenseCoral
                            AlertSeverity.WARNING -> WarningAmber
                            AlertSeverity.INFO -> InfoBlue
                        }
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(
                                alpha = if (alert.isReadFlag) 0.45f else 0.9f
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = alert.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = badgeColor
                                    )
                                    Text(
                                        text = formatDateTimeShort(alert.timestampMillis),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = alert.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
