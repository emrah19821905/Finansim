package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.CustomCategory
import com.example.ui.components.CUSTOM_CATEGORY_ICONS

private val CATEGORY_COLOR_PALETTE = listOf(
    0xFF0F6B4E,
    0xFF1D4ED8,
    0xFF7C3AED,
    0xFFBE123C,
    0xFFD97706,
    0xFF0EA5E9,
    0xFFEC4899,
    0xFF0F766E,
    0xFF4F46E5,
    0xFF65A30D
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CategoryEditorDialog(
    existing: CustomCategory?,
    onDismiss: () -> Unit,
    onSave: (name: String, iconKey: String, colorHex: Long, forIncome: Boolean) -> Unit
) {
    var name by remember(existing) { mutableStateOf(existing?.name ?: "") }
    var forIncome by remember(existing) { mutableStateOf(existing?.forIncome ?: false) }
    var colorHex by remember(existing) { mutableLongStateOf(existing?.colorHex ?: CATEGORY_COLOR_PALETTE.first()) }
    var iconKey by remember(existing) { mutableStateOf(existing?.iconKey ?: CUSTOM_CATEGORY_ICONS.first().key) }

    val selectedColor = Color(colorHex)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (existing == null) "Yeni Özel Kategori" else "Kategoriyi Düzenle",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 40) name = it },
                    label = { Text("Kategori Adı (ör. Kahve, Evcil Hayvan)") },
                    singleLine = true,
                    supportingText = { Text("${name.trim().length}/40 karakter") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("category_name_input")
                )

                Text("Kategori Türü", style = MaterialTheme.typography.labelLarge)
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = !forIncome,
                        onClick = { forIncome = false },
                        shape = SegmentedButtonDefaults.itemShape(0, 2)
                    ) {
                        Text("Gider")
                    }
                    SegmentedButton(
                        selected = forIncome,
                        onClick = { forIncome = true },
                        shape = SegmentedButtonDefaults.itemShape(1, 2)
                    ) {
                        Text("Gelir")
                    }
                }

                Text("Renk Seçimi", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CATEGORY_COLOR_PALETTE.forEach { hex ->
                        val isSelected = colorHex == hex
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color(hex))
                                .then(
                                    if (isSelected) {
                                        Modifier.border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                    } else {
                                        Modifier
                                    }
                                )
                                .clickable { colorHex = hex },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = "Seçili renk",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                Text("Simge Seçimi", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CUSTOM_CATEGORY_ICONS.forEach { choice ->
                        val isSelected = iconKey == choice.key
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) {
                                selectedColor.copy(alpha = 0.16f)
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            },
                            border = if (isSelected) {
                                androidx.compose.foundation.BorderStroke(1.5.dp, selectedColor)
                            } else {
                                null
                            },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { iconKey = choice.key }
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Icon(
                                    imageVector = choice.icon,
                                    contentDescription = choice.labelTr,
                                    tint = if (isSelected) selectedColor else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = choice.labelTr,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSelected) selectedColor else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(name.trim(), iconKey, colorHex, forIncome) },
                enabled = name.trim().isNotEmpty(),
                modifier = Modifier.testTag("save_category_button")
            ) {
                Text(if (existing == null) "Ekle" else "Güncelle")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("İptal")
            }
        }
    )
}
