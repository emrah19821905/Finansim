package com.example

import android.Manifest
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import java.io.File
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong
import androidx.compose.material.icons.automirrored.rounded.ReceiptLong
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.activity.compose.setContent
import androidx.core.content.IntentCompat
import androidx.credentials.CredentialManager
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.AiFinanceRepository
import com.example.data.FinanceVaultRepository
import com.example.data.attemptAutoSignIn
import com.example.data.signOutUser
import com.example.model.BankAccount
import com.example.model.BillReminder
import com.example.model.FinancialTransaction
import com.example.model.UiState
import com.example.notifications.FinanceNotificationHelper
import com.example.security.VaultCryptoManager
import com.example.security.VaultSessionStore
import com.example.security.configureAppCheck
import com.example.ui.dialogs.AccountEditorDialog
import com.example.ui.dialogs.AccountTransferDialog
import com.example.ui.dialogs.AlertsBottomSheet
import com.example.ui.dialogs.BillEditorDialog
import com.example.ui.dialogs.BudgetGoalDialog
import com.example.ui.dialogs.ChangePinDialog
import com.example.ui.dialogs.StatementImportSheet
import com.example.ui.dialogs.TransactionEditorSheet
import com.example.ui.screens.AnalyticsAndAiScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.BillsCalendarScreen
import com.example.ui.screens.CategoryManagementScreen
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.SecurityAndSyncScreen
import com.example.ui.screens.TransactionsAndCategorizeScreen
import com.example.ui.screens.VaultLockScreen
import com.example.ui.theme.FinansimTheme
import com.example.viewmodel.AuthAndLockViewModel
import com.example.viewmodel.FinanceViewModel
import com.example.viewmodel.VaultLockState
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import javax.crypto.SecretKey

private const val ROUTE_OVERVIEW = "overview"
private const val ROUTE_TRANSACTIONS = "transactions"
private const val ROUTE_CATEGORIES = "categories"
private const val ROUTE_ANALYTICS = "analytics"
private const val ROUTE_BILLS = "bills"
private const val ROUTE_SECURITY = "security"

private data class NavTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val APP_TABS = listOf(
    NavTab(ROUTE_OVERVIEW, "Özet", Icons.Rounded.Home, Icons.Outlined.Home),
    NavTab(ROUTE_TRANSACTIONS, "İşlemler", Icons.AutoMirrored.Rounded.ReceiptLong, Icons.AutoMirrored.Outlined.ReceiptLong),
    NavTab(ROUTE_ANALYTICS, "Analiz & AI", Icons.Rounded.Analytics, Icons.Outlined.Analytics),
    NavTab(ROUTE_BILLS, "Faturalar", Icons.Rounded.CalendarMonth, Icons.Outlined.CalendarMonth),
    NavTab(ROUTE_SECURITY, "Güvenlik", Icons.Rounded.Security, Icons.Outlined.Security)
)

class MainActivity : FragmentActivity() {
    private var incomingPdfUri by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure Firebase App Check before UI or ViewModels
        configureAppCheck(this, intent)
        FinanceNotificationHelper.ensureChannels(this)
        incomingPdfUri = extractPdfUriFromIntent(intent)

        val crashFile = File(filesDir, FinansimApp.CRASH_FILE)
        val previousCrash: String? =
            if (crashFile.exists()) runCatching { crashFile.readText() }.getOrNull() else null

        enableEdgeToEdge()
        setContent {
            FinansimTheme {
                var crashText by remember { mutableStateOf(previousCrash) }
                AppContent(
                    incomingPdfUri = incomingPdfUri,
                    onConsumeIncomingPdf = { incomingPdfUri = null }
                )
                crashText?.let { text ->
                    AlertDialog(
                        onDismissRequest = {},
                        title = { Text("Önceki çökme raporu") },
                        text = {
                            SelectionContainer {
                                Text(
                                    text,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.verticalScroll(rememberScrollState())
                                )
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                runCatching { crashFile.delete() }
                                crashText = null
                            }) { Text("Kapat") }
                        },
                        dismissButton = {
                            TextButton(onClick = {
                                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("crash", text))
                            }) { Text("Kopyala") }
                        }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        extractPdfUriFromIntent(intent)?.let { uri ->
            incomingPdfUri = uri
        }
    }

    private fun extractPdfUriFromIntent(intent: Intent?): Uri? {
        if (intent == null) return null
        return when (intent.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
            else -> null
        }
    }
}

@Composable
fun AppContent(
    incomingPdfUri: Uri? = null,
    onConsumeIncomingPdf: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }

    LaunchedEffect(Unit) {
        if (currentUser == null) {
            attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = { currentUser = Firebase.auth.currentUser },
                onUnauthenticated = {},
                scope = scope
            )
        }
    }

    val user = currentUser
    if (user == null) {
        AuthScreen(onAuthSuccess = { currentUser = Firebase.auth.currentUser })
    } else {
        val uid = user.uid
        key(uid) {
            AuthenticatedVaultGate(
                uid = uid,
                userEmail = user.email.orEmpty(),
                userDisplayName = user.displayName?.takeIf { it.isNotBlank() } ?: "Kullanıcı",
                incomingPdfUri = incomingPdfUri,
                onConsumeIncomingPdf = onConsumeIncomingPdf,
                onSignOut = {
                    signOutUser(credentialManager, scope) {
                        currentUser = null
                    }
                }
            )
        }
    }
}

@Composable
private fun AuthenticatedVaultGate(
    uid: String,
    userEmail: String,
    userDisplayName: String,
    incomingPdfUri: Uri?,
    onConsumeIncomingPdf: () -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val biometricReady = remember(context) { AuthAndLockViewModel.isBiometricReady(context) }

    val lockViewModel: AuthAndLockViewModel = viewModel(
        key = "lock_$uid",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                AuthAndLockViewModel(
                    repository = FinanceVaultRepository(db),
                    sessionStore = VaultSessionStore(app),
                    userId = uid,
                    biometricHardwareAvailable = AuthAndLockViewModel.isBiometricReady(app)
                )
            }
        }
    )

    val lockState by lockViewModel.lockState.collectAsStateWithLifecycle()
    val isBusy by lockViewModel.isBusy.collectAsStateWithLifecycle()

    when (val state = lockState) {
        is VaultLockState.Unlocked -> {
            key("${uid}_${VaultCryptoManager.keyFingerprint(state.vaultKey)}") {
                MainFinanceShell(
                    uid = uid,
                    userEmail = userEmail,
                    userDisplayName = userDisplayName,
                    vaultKey = state.vaultKey,
                    biometricHardwareAvailable = biometricReady,
                    incomingPdfUri = incomingPdfUri,
                    onConsumeIncomingPdf = onConsumeIncomingPdf,
                    onLockVault = { lockViewModel.lockNow() },
                    onChangePin = { cur, next, cb -> lockViewModel.changePin(cur, next, cb) },
                    onToggleBiometric = { enabled -> lockViewModel.setBiometricEnabled(enabled) {} },
                    onSignOut = onSignOut
                )
            }
        }

        else -> {
            VaultLockScreen(
                lockState = state,
                isBusy = isBusy,
                biometricHardwareAvailable = biometricReady,
                onCreatePin = { pin, bio -> lockViewModel.createVaultPin(pin, bio) },
                onUnlockWithPin = { pin -> lockViewModel.unlockWithPin(pin) },
                onBiometricSuccess = { lockViewModel.unlockWithBiometricSuccess() },
                onRetryLoad = { lockViewModel.loadVaultState() },
                onSignOut = onSignOut
            )
        }
    }
}

@Composable
private fun MainFinanceShell(
    uid: String,
    userEmail: String,
    userDisplayName: String,
    vaultKey: SecretKey,
    biometricHardwareAvailable: Boolean,
    incomingPdfUri: Uri?,
    onConsumeIncomingPdf: () -> Unit,
    onLockVault: () -> Unit,
    onChangePin: (String, String, (Result<Unit>) -> Unit) -> Unit,
    onToggleBiometric: (Boolean) -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val financeViewModel: FinanceViewModel = viewModel(
        key = "finance_$uid",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                FinanceViewModel(
                    appContext = app,
                    vaultRepo = FinanceVaultRepository(db),
                    aiRepo = AiFinanceRepository(),
                    sessionStore = VaultSessionStore(app),
                    userId = uid,
                    vaultKey = vaultKey
                )
            }
        }
    )

    // Request POST_NOTIFICATIONS once on Android 13+ if not yet granted
    val notifPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !FinanceNotificationHelper.hasNotificationPermission(context)
        ) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(financeViewModel) {
        financeViewModel.snackbarMessage.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val profileState by financeViewModel.profileState.collectAsStateWithLifecycle()
    val accountsState by financeViewModel.accountsState.collectAsStateWithLifecycle()
    val transactionsState by financeViewModel.transactionsState.collectAsStateWithLifecycle()
    val budgetsState by financeViewModel.budgetsState.collectAsStateWithLifecycle()
    val billsState by financeViewModel.billsState.collectAsStateWithLifecycle()
    val alertsState by financeViewModel.alertsState.collectAsStateWithLifecycle()
    val categoriesState by financeViewModel.categoriesState.collectAsStateWithLifecycle()
    val backupsState by financeViewModel.backupsState.collectAsStateWithLifecycle()
    val metrics by financeViewModel.dashboardMetrics.collectAsStateWithLifecycle()
    val habitProfile by financeViewModel.spendingHabitProfile.collectAsStateWithLifecycle()
    val aiAdviceState by financeViewModel.aiAdviceState.collectAsStateWithLifecycle()
    val aiCatState by financeViewModel.aiCategorizationState.collectAsStateWithLifecycle()
    val coachMessages by financeViewModel.coachMessages.collectAsStateWithLifecycle()
    val isCoachStreaming by financeViewModel.isCoachStreaming.collectAsStateWithLifecycle()
    val isSyncing by financeViewModel.isSyncing.collectAsStateWithLifecycle()
    val statementImportState by financeViewModel.statementImportState.collectAsStateWithLifecycle()

    // Dialog / Sheet states
    var showTxSheet by remember { mutableStateOf(false) }
    var editingTx by remember { mutableStateOf<FinancialTransaction?>(null) }
    var showAccountDialog by remember { mutableStateOf(false) }
    var editingAccount by remember { mutableStateOf<BankAccount?>(null) }
    var showTransferDialog by remember { mutableStateOf(false) }
    var showBudgetDialog by remember { mutableStateOf(false) }
    var showBillDialog by remember { mutableStateOf(false) }
    var editingBill by remember { mutableStateOf<BillReminder?>(null) }
    var showChangePinDialog by remember { mutableStateOf(false) }
    var showAlertsSheet by remember { mutableStateOf(false) }
    var showStatementImportSheet by remember { mutableStateOf(false) }
    var pendingStatementClose by remember { mutableStateOf(false) }
    var analyticsRequestedTab by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(incomingPdfUri) {
        if (incomingPdfUri != null) {
            financeViewModel.resetStatementImport()
            showStatementImportSheet = true
            financeViewModel.parseStatementFromUri(incomingPdfUri, "Paylaşılan Banka Ekstresi.pdf")
            onConsumeIncomingPdf()
        }
    }

    LaunchedEffect(statementImportState, pendingStatementClose, isSyncing) {
        if (pendingStatementClose && statementImportState is UiState.Idle) {
            pendingStatementClose = false
            showStatementImportSheet = false
        } else if (pendingStatementClose && !isSyncing && statementImportState !is UiState.Idle) {
            pendingStatementClose = false
        }
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    fun navigateToTab(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            contentWindowInsets = WindowInsets.safeDrawing,
            floatingActionButton = {
                val activeRoute = currentDestination?.route
                if (activeRoute == ROUTE_OVERVIEW || activeRoute == ROUTE_TRANSACTIONS) {
                    FloatingActionButton(
                        onClick = {
                            editingTx = null
                            showTxSheet = true
                        },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("fab_add_transaction")
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = "Yeni Gelir veya Gider Ekle")
                    }
                }
            },
            bottomBar = {
                if (!useNavRail) {
                    NavigationBar(windowInsets = WindowInsets.navigationBars) {
                        APP_TABS.forEach { tab ->
                            val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToTab(tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label, maxLines = 1) }
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavRail) {
                    NavigationRail {
                        APP_TABS.forEach { tab ->
                            val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTab(tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) }
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_OVERVIEW,
                        modifier = Modifier
                            .widthIn(max = 840.dp)
                            .fillMaxSize()
                    ) {
                        composable(ROUTE_OVERVIEW) {
                            OverviewScreen(
                                displayName = userDisplayName,
                                metrics = metrics,
                                habitProfile = habitProfile,
                                accountsState = accountsState,
                                transactionsState = transactionsState,
                                billsState = billsState,
                                onOpenAddTransaction = {
                                    editingTx = null
                                    showTxSheet = true
                                },
                                onOpenAddAccount = {
                                    editingAccount = null
                                    showAccountDialog = true
                                },
                                onEditAccount = { acc ->
                                    editingAccount = acc
                                    showAccountDialog = true
                                },
                                onOpenTransfer = { showTransferDialog = true },
                                onOpenStatementImport = {
                                    financeViewModel.resetStatementImport()
                                    pendingStatementClose = false
                                    showStatementImportSheet = true
                                },
                                onTriggerBackup = { financeViewModel.createEncryptedCloudBackup() },
                                onOpenAlertsSheet = { showAlertsSheet = true },
                                onLockVault = onLockVault,
                                onNavigateToTransactions = { navigateToTab(ROUTE_TRANSACTIONS) },
                                onNavigateToAnalytics = {
                                    analyticsRequestedTab = 0
                                    navigateToTab(ROUTE_ANALYTICS)
                                },
                                onNavigateToAiCoach = {
                                    analyticsRequestedTab = 1
                                    navigateToTab(ROUTE_ANALYTICS)
                                },
                                onNavigateToBills = { navigateToTab(ROUTE_BILLS) }
                            )
                        }

                        composable(ROUTE_TRANSACTIONS) {
                            TransactionsAndCategorizeScreen(
                                transactionsState = transactionsState,
                                aiCategorizationState = aiCatState,
                                onRunAutoCategorize = { list -> financeViewModel.runAiAutoCategorization(list) },
                                onApplyPrediction = { pred -> financeViewModel.applyCategoryPrediction(pred) },
                                onApplyAllPredictions = { financeViewModel.applyAllPredictions() },
                                onOpenStatementImport = {
                                    financeViewModel.resetStatementImport()
                                    pendingStatementClose = false
                                    showStatementImportSheet = true
                                },
                                onOpenCategoryManagement = { navController.navigate(ROUTE_CATEGORIES) },
                                onAddTransaction = {
                                    editingTx = null
                                    showTxSheet = true
                                },
                                onEditTransaction = { tx ->
                                    editingTx = tx
                                    showTxSheet = true
                                },
                                onDeleteTransaction = { tx -> financeViewModel.deleteTransaction(tx) }
                            )
                        }

                        composable(ROUTE_CATEGORIES) {
                            CategoryManagementScreen(
                                categoriesState = categoriesState,
                                transactionsState = transactionsState,
                                onAddCategory = { name, iconKey, colorHex, forIncome ->
                                    financeViewModel.addCustomCategory(name, iconKey, colorHex, forIncome)
                                },
                                onUpdateCategory = { updated ->
                                    financeViewModel.updateCustomCategory(updated)
                                },
                                onDeleteCategory = { target ->
                                    financeViewModel.deleteCustomCategory(target)
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ROUTE_ANALYTICS) {
                            AnalyticsAndAiScreen(
                                metrics = metrics,
                                habitProfile = habitProfile,
                                budgetsState = budgetsState,
                                aiAdviceState = aiAdviceState,
                                coachMessages = coachMessages,
                                isCoachStreaming = isCoachStreaming,
                                requestedTab = analyticsRequestedTab,
                                onTabHandled = { analyticsRequestedTab = null },
                                onOpenAddBudget = { showBudgetDialog = true },
                                onDeleteBudget = { id -> financeViewModel.deleteBudgetGoal(id) },
                                onApplyAiBudgetTarget = { cat, limit ->
                                    financeViewModel.saveBudgetGoal(cat, limit, aiRecommended = true)
                                },
                                onGenerateAiAdvice = { financeViewModel.generateAiBudgetAdvice() },
                                onAskCoach = { q -> financeViewModel.askAiCoach(q) },
                                onClearCoachChat = { financeViewModel.clearCoachChat() }
                            )
                        }

                        composable(ROUTE_BILLS) {
                            BillsCalendarScreen(
                                billsState = billsState,
                                onOpenAddBill = {
                                    editingBill = null
                                    showBillDialog = true
                                },
                                onEditBill = { bill ->
                                    editingBill = bill
                                    showBillDialog = true
                                },
                                onTogglePaid = { bill -> financeViewModel.markBillAsPaid(bill) },
                                onMarkAddedToCalendar = { bill -> financeViewModel.markBillCalendarAdded(bill) },
                                onSendTestReminder = { bill -> financeViewModel.sendBillTestReminder(bill) },
                                onDeleteBill = { id -> financeViewModel.deleteBill(id) }
                            )
                        }

                        composable(ROUTE_SECURITY) {
                            SecurityAndSyncScreen(
                                userEmail = userEmail,
                                keyFingerprint = financeViewModel.keyFingerprint,
                                profileState = profileState,
                                backupsState = backupsState,
                                biometricHardwareAvailable = biometricHardwareAvailable,
                                isSyncing = isSyncing,
                                onToggleBiometric = onToggleBiometric,
                                onOpenChangePin = { showChangePinDialog = true },
                                onLockVaultNow = onLockVault,
                                onUpdateAlertSettings = { enabled, thr ->
                                    financeViewModel.updateAlertSettings(enabled, thr)
                                },
                                onCreateCloudBackup = { financeViewModel.createEncryptedCloudBackup() },
                                onRestoreBackup = { snap -> financeViewModel.restoreBackup(snap) },
                                onSignOut = onSignOut
                            )
                        }
                    }
                }
            }
        }
    }

    val accounts = (accountsState as? UiState.Success)?.data.orEmpty()
    val alerts = (alertsState as? UiState.Success)?.data.orEmpty()
    val customCategories = (categoriesState as? UiState.Success)?.data.orEmpty()

    if (showTxSheet) {
        TransactionEditorSheet(
            existing = editingTx,
            accounts = accounts,
            customCategories = customCategories,
            onSuggestCategory = { title, type, amt, onRes, onErr ->
                financeViewModel.suggestSingleTransactionCategory(title, type, amt, onRes, onErr)
            },
            onDismiss = { showTxSheet = false },
            onSave = { tx ->
                if (editingTx == null) {
                    financeViewModel.addTransaction(tx)
                } else {
                    financeViewModel.updateTransaction(tx)
                }
                showTxSheet = false
            }
        )
    }

    if (showAccountDialog) {
        AccountEditorDialog(
            existing = editingAccount,
            onDismiss = { showAccountDialog = false },
            onSave = { acc ->
                financeViewModel.addOrUpdateAccount(acc, isNew = editingAccount == null)
                showAccountDialog = false
            },
            onDelete = editingAccount?.let { target ->
                {
                    financeViewModel.deleteAccount(target.id)
                    showAccountDialog = false
                }
            }
        )
    }

    if (showTransferDialog) {
        AccountTransferDialog(
            accounts = accounts,
            onDismiss = { showTransferDialog = false },
            onTransfer = { from, to, amt, note ->
                financeViewModel.transferBetweenAccounts(from, to, amt, note)
                showTransferDialog = false
            }
        )
    }

    if (showBudgetDialog) {
        BudgetGoalDialog(
            onDismiss = { showBudgetDialog = false },
            onSave = { cat, limit ->
                financeViewModel.saveBudgetGoal(cat, limit, aiRecommended = false)
                showBudgetDialog = false
            }
        )
    }

    if (showBillDialog) {
        BillEditorDialog(
            existing = editingBill,
            accounts = accounts,
            onDismiss = { showBillDialog = false },
            onSave = { bill ->
                financeViewModel.saveBill(bill, isNew = editingBill == null)
                showBillDialog = false
            }
        )
    }

    if (showChangePinDialog) {
        ChangePinDialog(
            onDismiss = { showChangePinDialog = false },
            onChangePin = onChangePin
        )
    }

    if (showAlertsSheet) {
        AlertsBottomSheet(
            alerts = alerts,
            onMarkAllRead = { financeViewModel.markAllAlertsRead() },
            onDismiss = { showAlertsSheet = false }
        )
    }

    if (showStatementImportSheet) {
        StatementImportSheet(
            statementState = statementImportState,
            accounts = accounts,
            isSyncing = isSyncing,
            onPickUri = { uri, label -> financeViewModel.parseStatementFromUri(uri, label) },
            onAnalyzeText = { text -> financeViewModel.parseStatementFromRawText(text) },
            onToggleTx = { id -> financeViewModel.toggleStatementTxSelection(id) },
            onSetAllTxSelection = { selected, filterType -> financeViewModel.setAllStatementTxSelection(selected, filterType) },
            onToggleTxType = { id -> financeViewModel.toggleStatementTxType(id) },
            onUpdateTxCategory = { id, cat -> financeViewModel.updateStatementTxCategory(id, cat) },
            onToggleBill = { id -> financeViewModel.toggleStatementBillSelection(id) },
            onCommitImport = { createNew, targetId, applyBal ->
                pendingStatementClose = true
                financeViewModel.commitStatementImport(createNew, targetId, applyBal)
            },
            onReset = {
                pendingStatementClose = false
                financeViewModel.resetStatementImport()
            },
            onDismiss = {
                pendingStatementClose = false
                showStatementImportSheet = false
            }
        )
    }
}
