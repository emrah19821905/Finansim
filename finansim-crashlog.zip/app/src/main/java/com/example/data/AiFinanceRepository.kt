package com.example.data

import android.graphics.Bitmap
import android.util.Log
import com.example.model.AccountType
import com.example.model.AiBudgetAdviceResponse
import com.example.model.AiBudgetRecommendationItem
import com.example.model.AiCategoryPrediction
import com.example.model.AiHabitInsight
import com.example.model.AiSavingTip
import com.example.model.ExpenseCategory
import com.example.model.ExtractedStatementBill
import com.example.model.ExtractedStatementTx
import com.example.model.FinancialTransaction
import com.example.model.HabitImpactLevel
import com.example.model.PdfStatementMetadata
import com.example.model.StatementAccountInfo
import com.example.model.StatementParseResult
import com.example.model.TransactionType
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.mapNotNull
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale

class AiFinanceRepository {
    companion object {
        private const val TAG = "AiFinanceRepository"
        private const val MODEL_NAME = "gemini-3.8-flash"
        private const val AI_TIMEOUT_MS = 60_000L
    }

    private val categoryEnumNames = ExpenseCategory.entries.map { it.name }

    private val categorizationModel by lazy {
        val itemSchema = Schema.obj(
            properties = mapOf(
                "transactionId" to Schema.string(description = "Girdi listesindeki işlem ID değeri"),
                "category" to Schema.enumeration(
                    values = categoryEnumNames,
                    description = "En uygun ExpenseCategory enum adı"
                ),
                "confidence" to Schema.integer(description = "0 ile 100 arasında güven yüzdesi"),
                "rationale" to Schema.string(description = "Kısa Türkçe sınıflandırma gerekçesi")
            )
        )
        val rootSchema = Schema.obj(
            properties = mapOf(
                "predictions" to Schema.array(
                    items = itemSchema,
                    description = "Sınıflandırılan işlemlerin listesi"
                )
            )
        )
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = rootSchema
            }
        )
    }

    private val budgetAdviceModel by lazy {
        val habitInsightSchema = Schema.obj(
            properties = mapOf(
                "habitTitle" to Schema.string(description = "Tespit edilen harcama alışkanlığının kısa başlığı (Türkçe)"),
                "observation" to Schema.string(description = "Firestore verilerine dayalı somut gözlem (rakam ve yüzde içerir)"),
                "personalizedAdvice" to Schema.string(description = "Bu alışkanlığa özel uygulanabilir kişiselleştirilmiş koçluk tavsiyesi"),
                "impactLevel" to Schema.enumeration(
                    values = HabitImpactLevel.entries.map { it.name },
                    description = "HIGH (yüksek risk/harcama), MEDIUM (iyileştirme fırsatı) veya POSITIVE (olumlu davranış)"
                )
            )
        )
        val budgetRecSchema = Schema.obj(
            properties = mapOf(
                "category" to Schema.enumeration(
                    values = ExpenseCategory.expenseCategories().map { it.name },
                    description = "Gider kategorisi enum adı"
                ),
                "suggestedLimit" to Schema.double(description = "Önerilen aylık limit (TL)"),
                "rationale" to Schema.string(description = "Kısa Türkçe gerekçe")
            )
        )
        val savingTipSchema = Schema.obj(
            properties = mapOf(
                "title" to Schema.string(description = "Tasarruf önerisi başlığı"),
                "description" to Schema.string(description = "Uygulanabilir somut Türkçe tavsiye"),
                "estimatedMonthlySavings" to Schema.double(description = "Tahmini aylık tasarruf tutarı (TL)")
            )
        )
        val adviceSchema = Schema.obj(
            properties = mapOf(
                "healthScore" to Schema.integer(description = "0-100 arası finansal sağlık puanı"),
                "spendingPersona" to Schema.string(description = "Kullanıcının harcama profilini özetleyen 2-4 kelimelik Türkçe unvan (ör. Hafta Sonu Odaklı)"),
                "executiveSummary" to Schema.string(description = "Harcama alışkanlıkları ve nakit akışını özetleyen kişiselleştirilmiş koç değerlendirmesi (Türkçe)"),
                "habitInsights" to Schema.array(
                    items = habitInsightSchema,
                    description = "Firestore işlemlerinden tespit edilen 3-4 somut harcama alışkanlığı ve tavsiyesi"
                ),
                "budgetRecommendations" to Schema.array(
                    items = budgetRecSchema,
                    description = "Kategori bazlı aylık bütçe hedefi önerileri"
                ),
                "savingTips" to Schema.array(
                    items = savingTipSchema,
                    description = "Kişiselleştirilmiş tasarruf önerileri"
                )
            )
        )
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = adviceSchema
            }
        )
    }

    private val statementParserModel by lazy {
        val accountSchema = Schema.obj(
            properties = mapOf(
                "bankName" to Schema.string(description = "Banka adı (ör. Garanti BBVA, Ziraat Bankası, İş Bankası)"),
                "accountName" to Schema.string(description = "Hesap veya kart adı"),
                "accountType" to Schema.enumeration(
                    values = AccountType.entries.map { it.name },
                    description = "AccountType enum değeri"
                ),
                "ibanSuffix" to Schema.string(description = "IBAN veya kartın son 4 hanesi (yoksa 0000)"),
                "detectedBalance" to Schema.double(
                    description = "Ekstredeki güncel/kapanış bakiyesi (yoksa -1)",
                    nullable = true
                )
            ),
            optionalProperties = listOf("detectedBalance")
        )
        val txSchema = Schema.obj(
            properties = mapOf(
                "title" to Schema.string(description = "Kısa ve net işlem/mağaza adı"),
                "amount" to Schema.double(description = "Pozitif tutar (TL)"),
                "type" to Schema.enumeration(
                    values = TransactionType.entries.map { it.name },
                    description = "INCOME (gelen para/maaş/iade) veya EXPENSE (harcama/giden)"
                ),
                "category" to Schema.enumeration(
                    values = categoryEnumNames,
                    description = "En uygun ExpenseCategory enum adı"
                ),
                "dateIso" to Schema.string(description = "İşlem tarihi yyyy-MM-dd formatında"),
                "note" to Schema.string(description = "Varsa ek açıklama"),
                "confidence" to Schema.integer(description = "0-100 arası güven skoru")
            )
        )
        val billSchema = Schema.obj(
            properties = mapOf(
                "title" to Schema.string(description = "Tekrarlayan fatura veya abonelik adı"),
                "amount" to Schema.double(description = "Aylık tutar (TL)"),
                "category" to Schema.enumeration(
                    values = categoryEnumNames,
                    description = "Kategori enum adı"
                ),
                "dueDayOfMonth" to Schema.integer(description = "Ayın kaçıncı günü (1-31)")
            )
        )
        val rootSchema = Schema.obj(
            properties = mapOf(
                "summary" to Schema.string(description = "Ekstrenin kısa Türkçe özeti"),
                "accountInfo" to accountSchema,
                "transactions" to Schema.array(
                    items = txSchema,
                    description = "Ekstreden çıkarılan tüm gelir ve gider işlemleri"
                ),
                "detectedBills" to Schema.array(
                    items = billSchema,
                    description = "Ekstrede tespit edilen tekrarlayan faturalar veya abonelikler"
                )
            ),
            optionalProperties = listOf("accountInfo")
        )
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = rootSchema
            }
        )
    }

    private val streamingCoachModel by lazy {
        Firebase.ai.generativeModel(modelName = MODEL_NAME)
    }

    suspend fun autoCategorizeTransactions(
        transactions: List<FinancialTransaction>
    ): Result<List<AiCategoryPrediction>> {
        if (transactions.isEmpty()) return Result.success(emptyList())
        return try {
            val itemsText = transactions.take(25).joinToString("\n") { tx ->
                "- id=${tx.id} | baslik=${tx.title} | tur=${tx.type.name} | tutar=${tx.amount} TL | not=${tx.note}"
            }
            val prompt = """
                Sen Türkiye'deki harcama ve gelir kalemlerini sınıflandıran uzman bir finans asistanısın.
                Aşağıdaki işlemleri geçerli ExpenseCategory enum değerlerinden birine ata:
                ${categoryEnumNames.joinToString(", ")}
                
                İşlemler:
                $itemsText
            """.trimIndent()

            val response = withTimeout(AI_TIMEOUT_MS) {
                categorizationModel.generateContent(prompt)
            }
            val rawJson = response.text ?: throw IllegalStateException("Yapay zeka boş yanıt döndürdü.")
            val root = JSONObject(rawJson)
            val arr = root.getJSONArray("predictions")
            val txTitleLookup = transactions.associateBy { it.id }

            val predictions = (0 until arr.length()).mapNotNull { idx ->
                val obj = arr.getJSONObject(idx)
                val txId = obj.optString("transactionId")
                val catName = obj.optString("category", ExpenseCategory.DIGER.name)
                val confidence = obj.optInt("confidence", 85).coerceIn(1, 100)
                val rationale = obj.optString("rationale", "İşlem adına göre sınıflandırıldı")
                val matchedTx = txTitleLookup[txId]
                if (txId.isBlank()) null else {
                    AiCategoryPrediction(
                        transactionId = txId,
                        title = matchedTx?.title ?: "İşlem",
                        suggestedCategory = ExpenseCategory.safeFromName(catName),
                        confidence = confidence,
                        rationale = rationale
                    )
                }
            }
            Result.success(predictions)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Auto-categorize timed out", e)
            Result.failure(Exception("Yapay zeka sınıflandırma isteği 60 saniye içinde yanıt vermedi."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Auto-categorize failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Sınıflandırma başarısız oldu."))
        }
    }

    suspend fun generateBudgetAndSavingsAdvice(
        financialSummary: String
    ): Result<AiBudgetAdviceResponse> {
        return try {
            val prompt = """
                Sen Finansım uygulamasının kıdemli yapay zeka bütçe koçusun.
                Aşağıda kullanıcının Firestore veritabanından şifresi çözülerek derlenmiş gerçek banka hesapları, harcama alışkanlıkları (hafta içi/hafta sonu, maaş döngüsü, tekrarlayan harcama noktaları), kategori dağılımları, özel kategorileri, bütçe hedefleri ve faturaları yer alıyor.
                
                Görevin:
                1. Kullanıcıya harcama karakterini özetleyen kısa bir "spendingPersona" belirle (2-4 kelime, Türkçe).
                2. Verilerdeki gerçek TL rakamlarını ve yüzdeleri referans alarak kişiselleştirilmiş "executiveSummary" yaz.
                3. "habitInsights" içinde 3 veya 4 somut harcama alışkanlığı tespiti ve her biri için uygulanabilir kişiselleştirilmiş tavsiye sun (tekrarlayan mağazalar, hafta sonu harcama yoğunluğu, bütçe aşım eğilimi veya olumlu tasarruf davranışı gibi).
                4. En az 4 kategori bütçe hedefi önerisi ("budgetRecommendations") ve en az 3 somut tasarruf aksiyonu ("savingTips") üret.
                
                Kullanıcının Firestore finansal ve alışkanlık analizi:
                $financialSummary
            """.trimIndent()

            val response = withTimeout(AI_TIMEOUT_MS) {
                budgetAdviceModel.generateContent(prompt)
            }
            val rawJson = response.text ?: throw IllegalStateException("Yapay zeka boş yanıt döndürdü.")
            val json = JSONObject(rawJson)

            val habitsArr = json.optJSONArray("habitInsights")
            val habits = buildList {
                if (habitsArr != null) {
                    for (i in 0 until habitsArr.length()) {
                        val obj = habitsArr.getJSONObject(i)
                        add(
                            AiHabitInsight(
                                habitTitle = obj.optString("habitTitle", "Harcama Alışkanlığı"),
                                observation = obj.optString("observation", ""),
                                personalizedAdvice = obj.optString("personalizedAdvice", ""),
                                impactLevel = HabitImpactLevel.safeFromName(obj.optString("impactLevel"))
                            )
                        )
                    }
                }
            }

            val recsArr = json.optJSONArray("budgetRecommendations")
            val recommendations = buildList {
                if (recsArr != null) {
                    for (i in 0 until recsArr.length()) {
                        val obj = recsArr.getJSONObject(i)
                        val rawLimit = obj.optDouble("suggestedLimit", 1000.0)
                        val safeLimit = if (rawLimit.isFinite()) rawLimit.coerceAtLeast(100.0) else 1000.0
                        add(
                            AiBudgetRecommendationItem(
                                category = ExpenseCategory.safeFromName(obj.optString("category")),
                                suggestedLimit = safeLimit,
                                rationale = obj.optString("rationale", "")
                            )
                        )
                    }
                }
            }

            val tipsArr = json.optJSONArray("savingTips")
            val tips = buildList {
                if (tipsArr != null) {
                    for (i in 0 until tipsArr.length()) {
                        val obj = tipsArr.getJSONObject(i)
                        val rawSavings = obj.optDouble("estimatedMonthlySavings", 0.0)
                        val safeSavings = if (rawSavings.isFinite()) rawSavings.coerceAtLeast(0.0) else 0.0
                        add(
                            AiSavingTip(
                                title = obj.optString("title", "Tasarruf Önerisi"),
                                description = obj.optString("description", ""),
                                estimatedMonthlySavings = safeSavings
                            )
                        )
                    }
                }
            }

            Result.success(
                AiBudgetAdviceResponse(
                    healthScore = json.optInt("healthScore", 75).coerceIn(0, 100),
                    spendingPersona = json.optString("spendingPersona", "Dengeli Planlayıcı"),
                    executiveSummary = json.optString("executiveSummary", ""),
                    habitInsights = habits,
                    budgetRecommendations = recommendations,
                    savingTips = tips
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Budget advice timed out", e)
            Result.failure(Exception("Bütçe analizi 60 saniye içinde tamamlanamadı. Lütfen tekrar deneyin."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Budget advice failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Bütçe analizi oluşturulamadı."))
        }
    }

    suspend fun parseBankStatementDocument(
        sourceLabel: String,
        rawText: String? = null,
        pdfBytes: ByteArray? = null,
        bitmap: Bitmap? = null,
        pdfMetadata: PdfStatementMetadata? = null
    ): Result<StatementParseResult> {
        return try {
            val pageHint = pdfMetadata?.let { "Bu belge ${it.pageCount} sayfalık bir banka PDF ekstresidir. Tüm sayfaları eksiksiz tara." }.orEmpty()
            val instruction = """
                Sen Türkiye'deki banka hesap ekstrelerini, vadesiz hesap hareketlerini, kredi kartı dönem içi işlemlerini ve PDF hesap özetlerini ayrıştıran uzman bir finansal veri motorusun.
                $pageHint
                Verilen banka ekstresini (PDF, görsel veya CSV/metin) analiz et ve tüm gelir ve gider işlemlerini doğru biçimde çıkar:
                1. Banka adı, hesap/kart adı, hesap türü (${AccountType.entries.joinToString(", ") { it.name }}), IBAN/kart son 4 hanesi ve varsa dönem sonu/güncel bakiyeyi tespit et (bakiye yoksa detectedBalance alanını null bırak).
                2. Tablo satırlarındaki Türkçe sayı biçimlerini (ör. 12.345,67 TL -> 12345.67) hatasız çöz; her satır için kısa işlem/mağaza başlığı, pozitif tutar (Double), işlem türü ve yyyy-MM-dd tarihini çıkar.
                3. İşlem türü kuralı: Gelen Havale/EFT/FAST, maaş, prim, kira geliri, iade/iptal, alacak veya (+) tutarlar -> INCOME. POS harcama, giden transfer, fatura ödeme, otomatik ödeme, komisyon/vergi, borç veya (-) tutarlar -> EXPENSE.
                4. Her işleme en uygun ExpenseCategory (${categoryEnumNames.joinToString(", ")}) değerini ata (maaş/gelir için MAAS veya YATIRIM/DIGER).
                5. Elektrik, su, doğalgaz, internet, GSM, kira, dijital abonelik (Netflix, Spotify vb.) gibi tekrarlayan fatura ödemeleri varsa detectedBills listesine ekle.
            """.trimIndent()

            val inputContent = content {
                text(instruction)
                if (!rawText.isNullOrBlank()) {
                    text("Ekstre içeriği:\n${rawText.take(60_000)}")
                }
                if (pdfBytes != null) {
                    inlineData(pdfBytes, "application/pdf")
                }
                if (bitmap != null) {
                    image(bitmap)
                }
            }

            val response = withTimeout(AI_TIMEOUT_MS) {
                statementParserModel.generateContent(inputContent)
            }
            val rawJson = response.text ?: throw IllegalStateException("Yapay zeka ekstreden veri çıkaramadı.")
            val root = JSONObject(rawJson)
            Result.success(decodeStatementParseResult(sourceLabel, root, pdfMetadata))
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Statement parsing timed out", e)
            Result.failure(Exception("Ekstre analizi 60 saniye içinde tamamlanamadı. Daha küçük bir PDF veya daha az sayfa içeren ekstre deneyin."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Statement parsing failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Banka ekstresi ayrıştırılamadı."))
        }
    }

    private fun decodeStatementParseResult(
        sourceLabel: String,
        root: JSONObject,
        pdfMetadata: PdfStatementMetadata?
    ): StatementParseResult {
        val summary = root.optString("summary", "Ekstre başarıyla analiz edildi.")
        val accObj = root.optJSONObject("accountInfo")
        val accountInfo = if (accObj != null && accObj.optString("bankName").isNotBlank()) {
            val rawBal = if (accObj.isNull("detectedBalance")) null else accObj.optDouble("detectedBalance", -1.0)
            StatementAccountInfo(
                bankName = accObj.optString("bankName", "Banka").trim(),
                accountName = accObj.optString("accountName", "Vadesiz TL").trim(),
                accountType = AccountType.safeFromName(accObj.optString("accountType")),
                ibanSuffix = accObj.optString("ibanSuffix", "0000").filter { it.isDigit() }.takeLast(4).padStart(4, '0'),
                detectedBalance = rawBal?.takeIf { it.isFinite() && it >= 0.0 }
            )
        } else {
            null
        }

        val dateParsers = listOf(
            SimpleDateFormat("yyyy-MM-dd", Locale.US),
            SimpleDateFormat("dd.MM.yyyy", Locale.US),
            SimpleDateFormat("dd/MM/yyyy", Locale.US)
        )
        val displayFormat = SimpleDateFormat("dd MMM yyyy", Locale.forLanguageTag("tr-TR"))
        val now = System.currentTimeMillis()

        val txArr = root.optJSONArray("transactions")
        val txs = buildList {
            if (txArr != null) {
                for (i in 0 until txArr.length()) {
                    val obj = txArr.getJSONObject(i)
                    val rawAmt = obj.optDouble("amount", 0.0)
                    val amt = if (rawAmt.isFinite()) kotlin.math.abs(rawAmt) else 0.0
                    if (amt <= 0.0) continue
                    val dateIso = obj.optString("dateIso", "").trim()
                    val parsedMillis = dateParsers.firstNotNullOfOrNull { fmt ->
                        try {
                            if (dateIso.isNotBlank()) fmt.parse(dateIso)?.time else null
                        } catch (_: Exception) {
                            null
                        }
                    } ?: now
                    add(
                        ExtractedStatementTx(
                            title = obj.optString("title", "Banka İşlemi").trim().ifBlank { "Banka İşlemi" },
                            amount = amt,
                            type = TransactionType.safeFromName(obj.optString("type")),
                            category = ExpenseCategory.safeFromName(obj.optString("category")),
                            dateMillis = parsedMillis,
                            dateLabel = displayFormat.format(parsedMillis),
                            note = obj.optString("note", "").trim(),
                            confidence = obj.optInt("confidence", 85).coerceIn(1, 100),
                            selected = true
                        )
                    )
                }
            }
        }

        val billArr = root.optJSONArray("detectedBills")
        val bills = buildList {
            if (billArr != null) {
                for (i in 0 until billArr.length()) {
                    val obj = billArr.getJSONObject(i)
                    val rawAmt = obj.optDouble("amount", 0.0)
                    val amt = if (rawAmt.isFinite()) kotlin.math.abs(rawAmt) else 0.0
                    if (amt <= 0.0) continue
                    add(
                        ExtractedStatementBill(
                            title = obj.optString("title", "Fatura").trim().ifBlank { "Fatura" },
                            amount = amt,
                            category = ExpenseCategory.safeFromName(obj.optString("category", ExpenseCategory.FATURA.name)),
                            dueDayOfMonth = obj.optInt("dueDayOfMonth", 15).coerceIn(1, 31),
                            selected = true
                        )
                    )
                }
            }
        }

        return StatementParseResult(
            sourceLabel = sourceLabel,
            summary = summary,
            accountInfo = accountInfo,
            transactions = txs,
            detectedBills = bills,
            pdfMetadata = pdfMetadata
        )
    }

    fun streamCoachResponse(
        question: String,
        financialContext: String,
        priorHistory: List<Pair<Boolean, String>> = emptyList()
    ): Flow<String> = flow {
        val systemContextMessage = content("user") {
            text(
                """
                Sen Finansım uygulamasının kişisel AI Bütçe Koçusun.
                Kullanıcının Firestore'daki güncel finansal verilerini ve harcama alışkanlıklarını esas alarak Türkçe, samimi, motive edici ama gerçekçi, somut ₺ rakamlı ve madde işaretli koçluk tavsiyeleri ver.
                
                Güncel Firestore Finansal & Alışkanlık Özeti:
                $financialContext
                """.trimIndent()
            )
        }
        val systemAck = content("model") {
            text("Anlaşıldı. Firestore verilerinizi ve harcama alışkanlıklarınızı inceledim. Sorularınızı bu gerçek verilere göre yanıtlamaya hazırım.")
        }

        val sanitizedTurns = mutableListOf<Pair<Boolean, String>>()
        for ((isUser, rawMsg) in priorHistory.takeLast(12)) {
            val cleaned = rawMsg.trim()
            if (cleaned.isBlank()) continue
            if (!isUser && (cleaned.startsWith("Yanıt alınamadı:") || cleaned == "Firestore verileriniz analiz ediliyor...")) {
                continue
            }
            if (sanitizedTurns.isEmpty()) {
                if (isUser) sanitizedTurns.add(true to cleaned)
            } else if (sanitizedTurns.last().first != isUser) {
                sanitizedTurns.add(isUser to cleaned)
            }
        }
        if (sanitizedTurns.lastOrNull()?.first == true) {
            sanitizedTurns.removeAt(sanitizedTurns.lastIndex)
        }

        val chatHistory = buildList {
            add(systemContextMessage)
            add(systemAck)
            sanitizedTurns.takeLast(8).forEach { (isUser, msgText) ->
                add(content(if (isUser) "user" else "model") { text(msgText) })
            }
        }

        val chat = streamingCoachModel.startChat(history = chatHistory)
        val accumulated = StringBuilder()
        withTimeout(AI_TIMEOUT_MS) {
            chat.sendMessageStream(question)
                .mapNotNull { it.text }
                .collect { chunk ->
                    accumulated.append(chunk)
                    emit(accumulated.toString())
                }
        }
        if (accumulated.isBlank()) {
            throw IllegalStateException("Yapay zeka boş yanıt döndürdü.")
        }
    }.catch { error ->
        if (error is CancellationException && error !is TimeoutCancellationException) {
            throw error
        }
        Log.e(TAG, "Streaming coach failed", error)
        throw error
    }
}
