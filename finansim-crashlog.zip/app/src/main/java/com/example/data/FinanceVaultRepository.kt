package com.example.data

import android.os.Build
import android.util.Log
import com.example.model.ActivityAlert
import com.example.model.BackupSummary
import com.example.model.BankAccount
import com.example.model.BillReminder
import com.example.model.BudgetGoal
import com.example.model.CustomCategory
import com.example.model.EncryptedBackupDoc
import com.example.model.EncryptedRecordDoc
import com.example.model.FinancialTransaction
import com.example.model.UserVaultProfile
import com.example.model.VaultSnapshotPayload
import com.example.security.EncryptedBlob
import com.example.security.VaultCryptoManager
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import javax.crypto.SecretKey

class FinanceVaultRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Devam etmek için Google ile giriş yapmalısınız.")
    }

    suspend fun getUserVaultProfile(userId: String): Result<UserVaultProfile?> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Kullanıcı kimliği uyuşmuyor." }
            val snap = db.collection("users").document(userId).get().await()
            val profile = if (snap.exists()) {
                snap.toObject(UserVaultProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            } else {
                null
            }
            Result.success(profile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    fun observeUserVaultProfile(userId: String): Flow<UserVaultProfile?> = flow {
        val uid = requireUserId()
        check(uid == userId) { "Kullanıcı kimliği uyuşmuyor." }
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            UserVaultProfile::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else {
                        null
                    }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    suspend fun createUserVaultProfile(
        userId: String,
        displayName: String,
        pinSalt: String,
        pinHash: String,
        wrappedVaultKey: String,
        wrappedVaultKeyIv: String,
        vaultKeyCheckCipher: String,
        vaultKeyCheckIv: String,
        biometricEnabled: Boolean
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Kullanıcı kimliği uyuşmuyor." }
            val payload = mapOf(
                "userId" to uid,
                "displayName" to displayName.take(100),
                "pinSalt" to pinSalt,
                "pinHash" to pinHash,
                "wrappedVaultKey" to wrappedVaultKey,
                "wrappedVaultKeyIv" to wrappedVaultKeyIv,
                "vaultKeyCheckCipher" to vaultKeyCheckCipher,
                "vaultKeyCheckIv" to vaultKeyCheckIv,
                "biometricEnabled" to biometricEnabled,
                "instantAlertsEnabled" to true,
                "alertThresholdAmount" to 500.0,
                "lastSyncLabel" to "Kasa oluşturuldu",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("users").document(uid).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateProfilePreferences(
        userId: String,
        biometricEnabled: Boolean? = null,
        instantAlertsEnabled: Boolean? = null,
        alertThresholdAmount: Double? = null,
        lastSyncLabel: String? = null,
        pinSalt: String? = null,
        pinHash: String? = null,
        wrappedVaultKey: String? = null,
        wrappedVaultKeyIv: String? = null
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Kullanıcı kimliği uyuşmuyor." }
            val updates = mutableMapOf<String, Any>(
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (biometricEnabled != null) updates["biometricEnabled"] = biometricEnabled
            if (instantAlertsEnabled != null) updates["instantAlertsEnabled"] = instantAlertsEnabled
            if (alertThresholdAmount != null) updates["alertThresholdAmount"] = alertThresholdAmount.coerceIn(0.0, 100_000_000.0)
            if (lastSyncLabel != null) updates["lastSyncLabel"] = lastSyncLabel.take(120)
            if (pinSalt != null) updates["pinSalt"] = pinSalt
            if (pinHash != null) updates["pinHash"] = pinHash
            if (wrappedVaultKey != null) updates["wrappedVaultKey"] = wrappedVaultKey
            if (wrappedVaultKeyIv != null) updates["wrappedVaultKeyIv"] = wrappedVaultKeyIv

            db.collection("users").document(uid).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeAccounts(userId: String, vaultKey: SecretKey): Flow<List<BankAccount>> =
        observeEncryptedCollection(userId, "accounts", vaultKey) { id, json ->
            BankAccount.fromJson(id, json)
        }

    fun observeTransactions(userId: String, vaultKey: SecretKey): Flow<List<FinancialTransaction>> =
        observeEncryptedCollection(userId, "transactions", vaultKey) { id, json ->
            FinancialTransaction.fromJson(id, json)
        }

    fun observeBudgets(userId: String, vaultKey: SecretKey): Flow<List<BudgetGoal>> =
        observeEncryptedCollection(userId, "budgets", vaultKey) { id, json ->
            BudgetGoal.fromJson(id, json)
        }

    fun observeBills(userId: String, vaultKey: SecretKey): Flow<List<BillReminder>> =
        observeEncryptedCollection(userId, "bills", vaultKey) { id, json ->
            BillReminder.fromJson(id, json)
        }

    fun observeAlerts(userId: String, vaultKey: SecretKey): Flow<List<ActivityAlert>> =
        observeEncryptedCollection(userId, "alerts", vaultKey) { id, json ->
            ActivityAlert.fromJson(id, json)
        }

    fun observeCategories(userId: String, vaultKey: SecretKey): Flow<List<CustomCategory>> =
        observeEncryptedCollection(userId, "categories", vaultKey) { id, json ->
            CustomCategory.fromJson(id, json)
        }

    fun observeBackups(userId: String): Flow<List<BackupSummary>> = flow {
        val uid = requireUserId()
        check(uid == userId) { "Kullanıcı kimliği uyuşmuyor." }
        val path = "users/$uid/backups"
        emitAll(
            db.collection("users").document(uid).collection("backups")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        EncryptedBackupDoc::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).map { doc ->
                        BackupSummary(
                            id = doc.id,
                            recordCount = doc.recordCount.toInt(),
                            checksum = doc.checksum,
                            deviceLabel = doc.deviceLabel,
                            createdAtMillis = doc.createdAt?.toDate()?.time ?: System.currentTimeMillis(),
                            encryptedPayload = doc.encryptedPayload,
                            iv = doc.iv
                        )
                    }.sortedByDescending { it.createdAtMillis }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun saveAccount(userId: String, account: BankAccount, vaultKey: SecretKey, isNew: Boolean): Result<Unit> =
        upsertEncryptedRecord(userId, "accounts", account.id, "ACCOUNT", account.toJson().toString(), vaultKey, isNew)

    suspend fun deleteAccount(userId: String, accountId: String): Result<Unit> =
        deleteRecord(userId, "accounts", accountId)

    suspend fun saveTransaction(userId: String, tx: FinancialTransaction, vaultKey: SecretKey, isNew: Boolean): Result<Unit> =
        upsertEncryptedRecord(userId, "transactions", tx.id, "TRANSACTION", tx.toJson().toString(), vaultKey, isNew)

    suspend fun deleteTransaction(userId: String, txId: String): Result<Unit> =
        deleteRecord(userId, "transactions", txId)

    suspend fun saveBudget(userId: String, budget: BudgetGoal, vaultKey: SecretKey, isNew: Boolean): Result<Unit> =
        upsertEncryptedRecord(userId, "budgets", budget.id, "BUDGET", budget.toJson().toString(), vaultKey, isNew)

    suspend fun deleteBudget(userId: String, budgetId: String): Result<Unit> =
        deleteRecord(userId, "budgets", budgetId)

    suspend fun saveBill(userId: String, bill: BillReminder, vaultKey: SecretKey, isNew: Boolean): Result<Unit> =
        upsertEncryptedRecord(userId, "bills", bill.id, "BILL", bill.toJson().toString(), vaultKey, isNew)

    suspend fun deleteBill(userId: String, billId: String): Result<Unit> =
        deleteRecord(userId, "bills", billId)

    suspend fun saveAlert(userId: String, alert: ActivityAlert, vaultKey: SecretKey, isNew: Boolean): Result<Unit> =
        upsertEncryptedRecord(userId, "alerts", alert.id, "ALERT", alert.toJson().toString(), vaultKey, isNew)

    suspend fun saveCategory(userId: String, category: CustomCategory, vaultKey: SecretKey, isNew: Boolean): Result<Unit> =
        upsertEncryptedRecord(userId, "categories", category.id, "CATEGORY", category.toJson().toString(), vaultKey, isNew)

    suspend fun deleteCategory(userId: String, categoryId: String): Result<Unit> =
        deleteRecord(userId, "categories", categoryId)

    suspend fun createEncryptedBackupSnapshot(
        userId: String,
        payload: VaultSnapshotPayload,
        vaultKey: SecretKey
    ): Result<BackupSummary> {
        val docId = "snap_${System.currentTimeMillis()}"
        val path = "users/$userId/backups/$docId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Kullanıcı kimliği uyuşmuyor." }
            val json = payload.toJsonString()
            val blob = VaultCryptoManager.encryptString(json, vaultKey)
            val checksum = VaultCryptoManager.sha256Hex(blob.ciphertextBase64).take(32)
            val count = payload.accounts.size + payload.transactions.size + payload.budgets.size + payload.bills.size + payload.customCategories.size
            val deviceLabel = "${Build.MANUFACTURER} ${Build.MODEL}".take(100)

            val docMap = mapOf(
                "userId" to uid,
                "encryptedPayload" to blob.ciphertextBase64,
                "iv" to blob.ivBase64,
                "keyVersion" to 1L,
                "recordCount" to count.toLong(),
                "checksum" to checksum,
                "deviceLabel" to deviceLabel,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("users").document(uid)
                .collection("backups").document(docId)
                .set(docMap).await()

            Result.success(
                BackupSummary(
                    id = docId,
                    recordCount = count,
                    checksum = checksum,
                    deviceLabel = deviceLabel,
                    createdAtMillis = System.currentTimeMillis(),
                    encryptedPayload = blob.ciphertextBase64,
                    iv = blob.ivBase64
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun restoreFromBackupSnapshot(
        userId: String,
        backup: BackupSummary,
        vaultKey: SecretKey
    ): Result<Int> {
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Kullanıcı kimliği uyuşmuyor." }
            val decrypted = VaultCryptoManager.decryptString(
                EncryptedBlob(backup.encryptedPayload, backup.iv),
                vaultKey
            )
            val snapshot = VaultSnapshotPayload.fromJsonString(decrypted)
            var restored = 0
            snapshot.accounts.forEach { acc ->
                val exists = db.collection("users").document(uid).collection("accounts").document(acc.id).get().await().exists()
                saveAccount(uid, acc, vaultKey, isNew = !exists).getOrThrow()
                restored++
            }
            snapshot.transactions.forEach { tx ->
                val exists = db.collection("users").document(uid).collection("transactions").document(tx.id).get().await().exists()
                saveTransaction(uid, tx, vaultKey, isNew = !exists).getOrThrow()
                restored++
            }
            snapshot.budgets.forEach { b ->
                val exists = db.collection("users").document(uid).collection("budgets").document(b.id).get().await().exists()
                saveBudget(uid, b, vaultKey, isNew = !exists).getOrThrow()
                restored++
            }
            snapshot.bills.forEach { bill ->
                val exists = db.collection("users").document(uid).collection("bills").document(bill.id).get().await().exists()
                saveBill(uid, bill, vaultKey, isNew = !exists).getOrThrow()
                restored++
            }
            snapshot.customCategories.forEach { cat ->
                val exists = db.collection("users").document(uid).collection("categories").document(cat.id).get().await().exists()
                saveCategory(uid, cat, vaultKey, isNew = !exists).getOrThrow()
                restored++
            }
            Result.success(restored)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "users/$userId/backups/${backup.id}")
            Result.failure(e)
        }
    }

    private fun <T> observeEncryptedCollection(
        userId: String,
        collectionName: String,
        vaultKey: SecretKey,
        mapper: (String, JSONObject) -> T
    ): Flow<List<T>> = flow {
        val uid = requireUserId()
        check(uid == userId) { "Kullanıcı kimliği uyuşmuyor." }
        val path = "users/$uid/$collectionName"
        emitAll(
            db.collection("users").document(uid).collection(collectionName)
                .snapshots()
                .map { snapshot ->
                    val docs = snapshot.toObjects(
                        EncryptedRecordDoc::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                    docs.mapNotNull { doc ->
                        try {
                            val plaintext = VaultCryptoManager.decryptString(
                                EncryptedBlob(doc.encryptedPayload, doc.iv),
                                vaultKey
                            )
                            mapper(doc.id, JSONObject(plaintext))
                        } catch (e: Exception) {
                            Log.w("FinanceVaultRepo", "Decrypt failed for $collectionName/${doc.id}", e)
                            null
                        }
                    }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    private suspend fun upsertEncryptedRecord(
        userId: String,
        collectionName: String,
        docId: String,
        recordType: String,
        jsonPayload: String,
        vaultKey: SecretKey,
        isNew: Boolean
    ): Result<Unit> {
        val sanitizedId = docId.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(120)
        val path = "users/$userId/$collectionName/$sanitizedId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Kullanıcı kimliği uyuşmuyor." }
            require(sanitizedId.isNotBlank()) { "Kayıt kimliği boş olamaz." }
            val blob = VaultCryptoManager.encryptString(jsonPayload, vaultKey)
            val docRef = db.collection("users").document(uid)
                .collection(collectionName).document(sanitizedId)

            if (isNew) {
                val payload = mapOf(
                    "userId" to uid,
                    "recordType" to recordType,
                    "encryptedPayload" to blob.ciphertextBase64,
                    "iv" to blob.ivBase64,
                    "keyVersion" to 1L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            } else {
                val updates = mapOf(
                    "encryptedPayload" to blob.ciphertextBase64,
                    "iv" to blob.ivBase64,
                    "keyVersion" to 1L,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                try {
                    docRef.update(updates).await()
                } catch (e: FirebaseFirestoreException) {
                    if (e.code == FirebaseFirestoreException.Code.NOT_FOUND) {
                        val createPayload = mapOf(
                            "userId" to uid,
                            "recordType" to recordType,
                            "encryptedPayload" to blob.ciphertextBase64,
                            "iv" to blob.ivBase64,
                            "keyVersion" to 1L,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                        docRef.set(createPayload).await()
                    } else {
                        throw e
                    }
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, if (isNew) OperationType.CREATE else OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    private suspend fun deleteRecord(
        userId: String,
        collectionName: String,
        docId: String
    ): Result<Unit> {
        val sanitizedId = docId.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(120)
        val path = "users/$userId/$collectionName/$sanitizedId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Kullanıcı kimliği uyuşmuyor." }
            require(sanitizedId.isNotBlank()) { "Kayıt kimliği boş olamaz." }
            db.collection("users").document(uid)
                .collection(collectionName).document(sanitizedId)
                .delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }
}
