package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class UserVaultProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val pinSalt: String = "",
    val pinHash: String = "",
    val wrappedVaultKey: String = "",
    val wrappedVaultKeyIv: String = "",
    val vaultKeyCheckCipher: String = "",
    val vaultKeyCheckIv: String = "",
    val biometricEnabled: Boolean = false,
    val instantAlertsEnabled: Boolean = true,
    val alertThresholdAmount: Double = 500.0,
    val lastSyncLabel: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class EncryptedRecordDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val recordType: String = "",
    val encryptedPayload: String = "",
    val iv: String = "",
    val keyVersion: Long = 1L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class EncryptedBackupDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val encryptedPayload: String = "",
    val iv: String = "",
    val keyVersion: Long = 1L,
    val recordCount: Long = 0L,
    val checksum: String = "",
    val deviceLabel: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
