package com.example.model

import androidx.compose.ui.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class AccountType(val labelTr: String) {
    CHECKING("Vadesiz Hesap"),
    SAVINGS("Birikim / Vadeli"),
    CREDIT_CARD("Kredi Kartı"),
    INVESTMENT("Yatırım Hesabı"),
    CASH("Nakit / Cüzdan");

    companion object {
        fun safeFromName(name: String): AccountType =
            entries.firstOrNull { it.name == name } ?: CHECKING
    }
}

enum class TransactionType(val labelTr: String) {
    EXPENSE("Gider"),
    INCOME("Gelir");

    companion object {
        fun safeFromName(name: String): TransactionType =
            entries.firstOrNull { it.name == name } ?: EXPENSE
    }
}

enum class ExpenseCategory(
    val labelTr: String,
    val colorHex: Long,
    val defaultForIncome: Boolean = false
) {
    MARKET("Market & Gıda", 0xFF16A37A),
    FATURA("Faturalar", 0xFFD98218),
    ULASIM("Ulaşım & Yakıt", 0xFF2563EB),
    YEME_ICME("Yeme & İçme", 0xFFE65C4F),
    KIRA("Kira & Konut", 0xFF7C3AED),
    SAGLIK("Sağlık", 0xFF0EA5E9),
    EGLENCE("Eğlence & Abonelik", 0xFFEC4899),
    GIYIM("Giyim & Alışveriş", 0xFFF59E0B),
    EGITIM("Eğitim", 0xFF14B8A6),
    MAAS("Maaş & Gelir", 0xFF0F6B4E, defaultForIncome = true),
    YATIRIM("Yatırım & Tasarruf", 0xFFB5891C, defaultForIncome = true),
    DIGER("Diğer", 0xFF64748B);

    val color: Color get() = Color(colorHex)

    companion object {
        fun safeFromName(name: String): ExpenseCategory =
            entries.firstOrNull { it.name == name } ?: DIGER

        fun expenseCategories(): List<ExpenseCategory> =
            entries.filter { it != MAAS }

        fun incomeCategories(): List<ExpenseCategory> =
            listOf(MAAS, YATIRIM, DIGER)
    }
}

enum class AlertSeverity(val labelTr: String) {
    INFO("Bilgi"),
    WARNING("Dikkat"),
    CRITICAL("Kritik");

    companion object {
        fun safeFromName(name: String): AlertSeverity =
            entries.firstOrNull { it.name == name } ?: INFO
    }
}

fun safeFiniteDouble(value: Double, fallback: Double = 0.0): Double =
    if (value.isFinite()) value else fallback

fun safeOpaqueColor(colorHex: Long, fallbackHex: Long = 0xFF0F6B4E): Color {
    if (colorHex == 0L) return Color(fallbackHex)
    val normalized = if ((colorHex ushr 24) and 0xFFL == 0L) {
        colorHex or 0xFF000000L
    } else {
        colorHex
    }
    return Color(normalized)
}

data class BankAccount(
    val id: String = UUID.randomUUID().toString(),
    val bankName: String = "",
    val accountName: String = "",
    val accountType: AccountType = AccountType.CHECKING,
    val ibanSuffix: String = "",
    val balance: Double = 0.0,
    val colorHex: Long = 0xFF0F6B4E,
    val updatedAtMillis: Long = System.currentTimeMillis()
) {
    val cardColor: Color get() = safeOpaqueColor(colorHex)

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("bankName", bankName)
        put("accountName", accountName)
        put("accountType", accountType.name)
        put("ibanSuffix", ibanSuffix)
        put("balance", safeFiniteDouble(balance))
        put("colorHex", colorHex)
        put("updatedAtMillis", updatedAtMillis)
    }

    companion object {
        fun fromJson(idOverride: String, json: JSONObject): BankAccount = BankAccount(
            id = idOverride.ifBlank { json.optString("id", UUID.randomUUID().toString()) },
            bankName = json.optString("bankName", "Banka"),
            accountName = json.optString("accountName", "Ana Hesap"),
            accountType = AccountType.safeFromName(json.optString("accountType")),
            ibanSuffix = json.optString("ibanSuffix", "0000"),
            balance = safeFiniteDouble(json.optDouble("balance", 0.0)),
            colorHex = json.optLong("colorHex", 0xFF0F6B4E).let { if (it == 0L) 0xFF0F6B4E else it },
            updatedAtMillis = json.optLong("updatedAtMillis", System.currentTimeMillis())
        )
    }
}

data class CustomCategory(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val iconKey: String = "LABEL",
    val colorHex: Long = 0xFF0F6B4E,
    val forIncome: Boolean = false,
    val updatedAtMillis: Long = System.currentTimeMillis()
) {
    val color: Color get() = safeOpaqueColor(colorHex)

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("iconKey", iconKey)
        put("colorHex", colorHex)
        put("forIncome", forIncome)
        put("updatedAtMillis", updatedAtMillis)
    }

    companion object {
        fun fromJson(idOverride: String, json: JSONObject): CustomCategory = CustomCategory(
            id = idOverride.ifBlank { json.optString("id", UUID.randomUUID().toString()) },
            name = json.optString("name", "Özel Kategori"),
            iconKey = json.optString("iconKey", "LABEL"),
            colorHex = json.optLong("colorHex", 0xFF0F6B4E).let { if (it == 0L) 0xFF0F6B4E else it },
            forIncome = json.optBoolean("forIncome", false),
            updatedAtMillis = json.optLong("updatedAtMillis", System.currentTimeMillis())
        )
    }
}

data class FinancialTransaction(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val amount: Double = 0.0,
    val type: TransactionType = TransactionType.EXPENSE,
    val category: ExpenseCategory = ExpenseCategory.DIGER,
    val customCategoryId: String = "",
    val customCategoryName: String = "",
    val customCategoryColorHex: Long = 0L,
    val customCategoryIconKey: String = "",
    val accountId: String = "",
    val accountName: String = "",
    val dateMillis: Long = System.currentTimeMillis(),
    val note: String = "",
    val aiCategorized: Boolean = false,
    val aiConfidence: Int = 0
) {
    val displayCategoryLabel: String
        get() = customCategoryName.ifBlank { category.labelTr }

    val displayCategoryColor: Color
        get() = if (customCategoryColorHex != 0L) safeOpaqueColor(customCategoryColorHex, category.colorHex) else category.color

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("title", title)
        put("amount", safeFiniteDouble(amount))
        put("type", type.name)
        put("category", category.name)
        put("customCategoryId", customCategoryId)
        put("customCategoryName", customCategoryName)
        put("customCategoryColorHex", customCategoryColorHex)
        put("customCategoryIconKey", customCategoryIconKey)
        put("accountId", accountId)
        put("accountName", accountName)
        put("dateMillis", dateMillis)
        put("note", note)
        put("aiCategorized", aiCategorized)
        put("aiConfidence", aiConfidence)
    }

    companion object {
        fun fromJson(idOverride: String, json: JSONObject): FinancialTransaction = FinancialTransaction(
            id = idOverride.ifBlank { json.optString("id", UUID.randomUUID().toString()) },
            title = json.optString("title", "İşlem"),
            amount = safeFiniteDouble(json.optDouble("amount", 0.0)),
            type = TransactionType.safeFromName(json.optString("type")),
            category = ExpenseCategory.safeFromName(json.optString("category")),
            customCategoryId = json.optString("customCategoryId", ""),
            customCategoryName = json.optString("customCategoryName", ""),
            customCategoryColorHex = json.optLong("customCategoryColorHex", 0L),
            customCategoryIconKey = json.optString("customCategoryIconKey", ""),
            accountId = json.optString("accountId", ""),
            accountName = json.optString("accountName", ""),
            dateMillis = json.optLong("dateMillis", System.currentTimeMillis()),
            note = json.optString("note", ""),
            aiCategorized = json.optBoolean("aiCategorized", false),
            aiConfidence = json.optInt("aiConfidence", 0)
        )
    }
}

data class BudgetGoal(
    val id: String = UUID.randomUUID().toString(),
    val category: ExpenseCategory = ExpenseCategory.MARKET,
    val monthlyLimit: Double = 5000.0,
    val aiRecommended: Boolean = false,
    val updatedAtMillis: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("category", category.name)
        put("monthlyLimit", safeFiniteDouble(monthlyLimit))
        put("aiRecommended", aiRecommended)
        put("updatedAtMillis", updatedAtMillis)
    }

    companion object {
        fun fromJson(idOverride: String, json: JSONObject): BudgetGoal = BudgetGoal(
            id = idOverride.ifBlank { json.optString("id", UUID.randomUUID().toString()) },
            category = ExpenseCategory.safeFromName(json.optString("category")),
            monthlyLimit = safeFiniteDouble(json.optDouble("monthlyLimit", 0.0)),
            aiRecommended = json.optBoolean("aiRecommended", false),
            updatedAtMillis = json.optLong("updatedAtMillis", System.currentTimeMillis())
        )
    }
}

data class BillReminder(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val amount: Double = 0.0,
    val category: ExpenseCategory = ExpenseCategory.FATURA,
    val dueDayOfMonth: Int = 15,
    val dueDateMillis: Long = System.currentTimeMillis(),
    val reminderDaysBefore: Int = 3,
    val paidForCurrentMonth: Boolean = false,
    val recurringMonthly: Boolean = true,
    val addedToCalendar: Boolean = false,
    val accountId: String = "",
    val note: String = ""
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("title", title)
        put("amount", safeFiniteDouble(amount))
        put("category", category.name)
        put("dueDayOfMonth", dueDayOfMonth)
        put("dueDateMillis", dueDateMillis)
        put("reminderDaysBefore", reminderDaysBefore)
        put("paidForCurrentMonth", paidForCurrentMonth)
        put("recurringMonthly", recurringMonthly)
        put("addedToCalendar", addedToCalendar)
        put("accountId", accountId)
        put("note", note)
    }

    companion object {
        fun fromJson(idOverride: String, json: JSONObject): BillReminder = BillReminder(
            id = idOverride.ifBlank { json.optString("id", UUID.randomUUID().toString()) },
            title = json.optString("title", "Fatura"),
            amount = safeFiniteDouble(json.optDouble("amount", 0.0)),
            category = ExpenseCategory.safeFromName(json.optString("category")),
            dueDayOfMonth = json.optInt("dueDayOfMonth", 15).coerceIn(1, 31),
            dueDateMillis = json.optLong("dueDateMillis", System.currentTimeMillis()),
            reminderDaysBefore = json.optInt("reminderDaysBefore", 3).coerceIn(0, 14),
            paidForCurrentMonth = json.optBoolean("paidForCurrentMonth", false),
            recurringMonthly = json.optBoolean("recurringMonthly", true),
            addedToCalendar = json.optBoolean("addedToCalendar", false),
            accountId = json.optString("accountId", ""),
            note = json.optString("note", "")
        )
    }
}

data class ActivityAlert(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val message: String = "",
    val severity: AlertSeverity = AlertSeverity.INFO,
    val timestampMillis: Long = System.currentTimeMillis(),
    val isReadFlag: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("title", title)
        put("message", message)
        put("severity", severity.name)
        put("timestampMillis", timestampMillis)
        put("isReadFlag", isReadFlag)
    }

    companion object {
        fun fromJson(idOverride: String, json: JSONObject): ActivityAlert = ActivityAlert(
            id = idOverride.ifBlank { json.optString("id", UUID.randomUUID().toString()) },
            title = json.optString("title", "Bildirim"),
            message = json.optString("message", ""),
            severity = AlertSeverity.safeFromName(json.optString("severity")),
            timestampMillis = json.optLong("timestampMillis", System.currentTimeMillis()),
            isReadFlag = json.optBoolean("isReadFlag", false)
        )
    }
}

data class BackupSummary(
    val id: String = "",
    val recordCount: Int = 0,
    val checksum: String = "",
    val deviceLabel: String = "",
    val createdAtMillis: Long = System.currentTimeMillis(),
    val encryptedPayload: String = "",
    val iv: String = ""
)

data class VaultSnapshotPayload(
    val accounts: List<BankAccount>,
    val transactions: List<FinancialTransaction>,
    val budgets: List<BudgetGoal>,
    val bills: List<BillReminder>,
    val customCategories: List<CustomCategory> = emptyList()
) {
    fun toJsonString(): String = JSONObject().apply {
        put("accounts", JSONArray(accounts.map { it.toJson() }))
        put("transactions", JSONArray(transactions.map { it.toJson() }))
        put("budgets", JSONArray(budgets.map { it.toJson() }))
        put("bills", JSONArray(bills.map { it.toJson() }))
        put("categories", JSONArray(customCategories.map { it.toJson() }))
    }.toString()

    companion object {
        fun fromJsonString(raw: String): VaultSnapshotPayload {
            val obj = JSONObject(raw)
            val accArr = obj.optJSONArray("accounts") ?: JSONArray()
            val txArr = obj.optJSONArray("transactions") ?: JSONArray()
            val budArr = obj.optJSONArray("budgets") ?: JSONArray()
            val billArr = obj.optJSONArray("bills") ?: JSONArray()
            val catArr = obj.optJSONArray("categories") ?: JSONArray()

            return VaultSnapshotPayload(
                accounts = (0 until accArr.length()).map {
                    val item = accArr.getJSONObject(it)
                    BankAccount.fromJson(item.optString("id"), item)
                },
                transactions = (0 until txArr.length()).map {
                    val item = txArr.getJSONObject(it)
                    FinancialTransaction.fromJson(item.optString("id"), item)
                },
                budgets = (0 until budArr.length()).map {
                    val item = budArr.getJSONObject(it)
                    BudgetGoal.fromJson(item.optString("id"), item)
                },
                bills = (0 until billArr.length()).map {
                    val item = billArr.getJSONObject(it)
                    BillReminder.fromJson(item.optString("id"), item)
                },
                customCategories = (0 until catArr.length()).map {
                    val item = catArr.getJSONObject(it)
                    CustomCategory.fromJson(item.optString("id"), item)
                }
            )
        }
    }
}

data class MonthlyChartPoint(
    val monthLabel: String,
    val income: Double,
    val expense: Double
)

data class CategoryBreakdownItem(
    val category: ExpenseCategory,
    val amount: Double,
    val percentage: Float,
    val customCategoryId: String = "",
    val customLabel: String = "",
    val customColorHex: Long = 0L,
    val customIconKey: String = ""
) {
    val displayLabel: String
        get() = customLabel.ifBlank { category.labelTr }

    val displayColor: Color
        get() = if (customColorHex != 0L) safeOpaqueColor(customColorHex, category.colorHex) else category.color
}

data class AiCategoryPrediction(
    val transactionId: String,
    val title: String,
    val suggestedCategory: ExpenseCategory,
    val confidence: Int,
    val rationale: String
)

enum class HabitImpactLevel(val labelTr: String) {
    HIGH("Öncelikli Dikkat"),
    MEDIUM("İyileştirme Fırsatı"),
    POSITIVE("Güçlü Alışkanlık");

    companion object {
        fun safeFromName(name: String): HabitImpactLevel =
            entries.firstOrNull { it.name.equals(name.trim(), ignoreCase = true) } ?: MEDIUM
    }
}

data class AiHabitInsight(
    val habitTitle: String,
    val observation: String,
    val personalizedAdvice: String,
    val impactLevel: HabitImpactLevel = HabitImpactLevel.MEDIUM
)

data class AiBudgetRecommendationItem(
    val category: ExpenseCategory,
    val suggestedLimit: Double,
    val rationale: String
)

data class AiSavingTip(
    val title: String,
    val description: String,
    val estimatedMonthlySavings: Double
)

data class AiBudgetAdviceResponse(
    val healthScore: Int,
    val spendingPersona: String = "",
    val executiveSummary: String,
    val habitInsights: List<AiHabitInsight> = emptyList(),
    val budgetRecommendations: List<AiBudgetRecommendationItem>,
    val savingTips: List<AiSavingTip>
)

data class SpendingHabitProfile(
    val analyzedTransactionsCount: Int = 0,
    val thisMonthExpense: Double = 0.0,
    val lastMonthExpense: Double = 0.0,
    val momDeltaPercent: Int? = null,
    val savingsRatePercent: Int? = null,
    val weekendSharePercent: Int = 0,
    val weekendExpenseTotal: Double = 0.0,
    val weekdayExpenseTotal: Double = 0.0,
    val topHabitMerchant: String = "",
    val topHabitMerchantCount: Int = 0,
    val topHabitMerchantTotal: Double = 0.0,
    val topCategoryLabel: String = "",
    val topCategorySharePercent: Int = 0,
    val overBudgetCategories: List<String> = emptyList(),
    val nearBudgetCategories: List<String> = emptyList(),
    val paycheckCycleEarlyPct: Int = 0,
    val paycheckCycleMidPct: Int = 0,
    val paycheckCycleLatePct: Int = 0
)

data class StatementAccountInfo(
    val bankName: String,
    val accountName: String,
    val accountType: AccountType,
    val ibanSuffix: String,
    val detectedBalance: Double?
)

data class PdfStatementMetadata(
    val fileName: String,
    val pageCount: Int,
    val fileSizeBytes: Long
)

data class ExtractedStatementTx(
    val tempId: String = UUID.randomUUID().toString(),
    val title: String,
    val amount: Double,
    val type: TransactionType,
    val category: ExpenseCategory,
    val dateMillis: Long,
    val dateLabel: String,
    val note: String,
    val confidence: Int,
    val selected: Boolean = true,
    val isDuplicate: Boolean = false
)

data class ExtractedStatementBill(
    val tempId: String = UUID.randomUUID().toString(),
    val title: String,
    val amount: Double,
    val category: ExpenseCategory,
    val dueDayOfMonth: Int,
    val selected: Boolean = true
)

data class StatementParseResult(
    val sourceLabel: String,
    val summary: String,
    val accountInfo: StatementAccountInfo?,
    val transactions: List<ExtractedStatementTx>,
    val detectedBills: List<ExtractedStatementBill>,
    val pdfMetadata: PdfStatementMetadata? = null
)

sealed interface UiState<out T> {
    data object Idle : UiState<Nothing>
    data object Loading : UiState<Nothing>
    data class Streaming(val text: String) : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

fun formatTry(amount: Double): String {
    val safe = safeFiniteDouble(amount)
    val formatter = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("tr-TR"))
    return formatter.format(safe)
}

fun formatCompactTry(amount: Double): String {
    val safe = safeFiniteDouble(amount)
    val abs = kotlin.math.abs(safe)
    val sign = if (safe < 0) "-" else ""
    return when {
        abs >= 1_000_000 -> "${sign}₺${String.format(Locale.forLanguageTag("tr-TR"), "%.1fM", abs / 1_000_000)}"
        abs >= 1_000 -> "${sign}₺${String.format(Locale.forLanguageTag("tr-TR"), "%.1fB", abs / 1_000)}"
        else -> formatTry(safe)
    }
}

fun formatDateShort(millis: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy", Locale.forLanguageTag("tr-TR"))
    return sdf.format(Date(millis))
}

fun formatDateTimeShort(millis: Long): String {
    val sdf = SimpleDateFormat("dd MMM • HH:mm", Locale.forLanguageTag("tr-TR"))
    return sdf.format(Date(millis))
}
