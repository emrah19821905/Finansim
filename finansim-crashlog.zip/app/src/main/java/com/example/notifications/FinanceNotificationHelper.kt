package com.example.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import java.text.NumberFormat
import java.util.Locale

object FinanceNotificationHelper {
    const val CHANNEL_TRANSACTIONS = "finansim_transactions"
    const val CHANNEL_BUDGETS = "finansim_budgets"
    const val CHANNEL_BILLS = "finansim_bills"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channels = listOf(
                NotificationChannel(
                    CHANNEL_TRANSACTIONS,
                    "Anlık Harcama ve Gelir Bildirimleri",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Yeni harcama veya gelir hareketi eklendiğinde anlık uyarı verir."
                },
                NotificationChannel(
                    CHANNEL_BUDGETS,
                    "Bütçe Hedefi Uyarıları",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Kategori bütçesi %80 veya %100 sınırına ulaştığında uyarır."
                },
                NotificationChannel(
                    CHANNEL_BILLS,
                    "Fatura Ödeme Hatırlatıcıları",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Yaklaşan fatura son ödeme tarihleri için hatırlatma gönderir."
                }
            )
            manager.createNotificationChannels(channels)
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun notifyTransactionRecorded(
        context: Context,
        title: String,
        amount: Double,
        isExpense: Boolean,
        categoryLabel: String,
        accountName: String,
        isHighSpend: Boolean
    ) {
        ensureChannels(context)
        if (!hasNotificationPermission(context)) return

        val formattedAmount = formatCurrency(amount)
        val prefix = if (isExpense) "Harcama" else "Gelir"
        val notifTitle = if (isHighSpend && isExpense) {
            "Yüksek Harcama Uyarısı: $formattedAmount"
        } else {
            "Anlık $prefix Hareketi: $formattedAmount"
        }
        val body = "$title • $categoryLabel ($accountName)"

        postNotification(
            context = context,
            channelId = CHANNEL_TRANSACTIONS,
            notificationId = (System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
            title = notifTitle,
            body = body
        )
    }

    fun notifyBudgetThreshold(
        context: Context,
        categoryLabel: String,
        ratioPercent: Int,
        spentAmount: Double,
        limitAmount: Double
    ) {
        ensureChannels(context)
        if (!hasNotificationPermission(context)) return

        val title = if (ratioPercent >= 100) {
            "Bütçe Aşıldı: $categoryLabel"
        } else {
            "Bütçe Sınırına Yaklaşıldı (%$ratioPercent): $categoryLabel"
        }
        val body = "Harcanan ${formatCurrency(spentAmount)} / Hedef ${formatCurrency(limitAmount)}"

        postNotification(
            context = context,
            channelId = CHANNEL_BUDGETS,
            notificationId = ("budget_$categoryLabel".hashCode() and 0x7FFFFFFF),
            title = title,
            body = body
        )
    }

    fun notifyBillReminder(
        context: Context,
        billTitle: String,
        amount: Double,
        daysRemaining: Int
    ) {
        ensureChannels(context)
        if (!hasNotificationPermission(context)) return

        val whenLabel = when {
            daysRemaining < 0 -> "${-daysRemaining} gün gecikti"
            daysRemaining == 0 -> "Son ödeme günü BUGÜN"
            daysRemaining == 1 -> "Son ödeme günü YARIN"
            else -> "$daysRemaining gün kaldı"
        }
        val title = "Fatura Hatırlatması: $billTitle"
        val body = "${formatCurrency(amount)} • $whenLabel"

        postNotification(
            context = context,
            channelId = CHANNEL_BILLS,
            notificationId = ("bill_$billTitle".hashCode() and 0x7FFFFFFF),
            title = title,
            body = body
        )
    }

    private fun postNotification(
        context: Context,
        channelId: String,
        notificationId: Int,
        title: String,
        body: String
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
        } catch (_: SecurityException) {
            // Permission was revoked at OS level
        }
    }

    private fun formatCurrency(amount: Double): String {
        val formatter = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("tr-TR"))
        return formatter.format(amount)
    }
}
