package com.example.notifications

import android.content.Context
import android.content.Intent
import android.provider.CalendarContract
import com.example.model.BillReminder
import com.example.model.formatTry
import java.util.Calendar

object CalendarIntegrationHelper {
    fun openInsertBillCalendarEvent(context: Context, bill: BillReminder): Boolean {
        val cal = Calendar.getInstance().apply {
            timeInMillis = bill.dueDateMillis
            set(Calendar.HOUR_OF_DAY, 10)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }
        val startMillis = cal.timeInMillis
        val endMillis = startMillis + 30 * 60 * 1000L

        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
            putExtra(CalendarContract.Events.TITLE, "Fatura Ödeme: ${bill.title} (${formatTry(bill.amount)})")
            putExtra(
                CalendarContract.Events.DESCRIPTION,
                "Finansım Fatura Hatırlatıcısı • Kategori: ${bill.category.labelTr}" +
                    if (bill.note.isNotBlank()) "\nNot: ${bill.note}" else ""
            )
            if (bill.recurringMonthly) {
                putExtra(CalendarContract.Events.RRULE, "FREQ=MONTHLY;BYMONTHDAY=${bill.dueDayOfMonth}")
            }
            putExtra(CalendarContract.Events.HAS_ALARM, 1)
        }

        return try {
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }
}
