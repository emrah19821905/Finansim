package com.example.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.security.VaultSessionStore
import org.json.JSONArray
import java.util.concurrent.TimeUnit

class BillReminderWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val sessionStore = VaultSessionStore(applicationContext)
        val cachedJson = sessionStore.loadReminderSummaryCache() ?: return Result.success()
        return try {
            val array = JSONArray(cachedJson)
            val nowMillis = System.currentTimeMillis()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val title = obj.optString("title", "Fatura")
                val amount = obj.optDouble("amount", 0.0)
                val dueMillis = obj.optLong("dueMillis", 0L)
                val reminderDays = obj.optInt("reminderDays", 3)
                val paid = obj.optBoolean("paid", false)
                if (!paid && dueMillis > 0L) {
                    val diffDays = ((dueMillis - nowMillis) / (24L * 60L * 60L * 1000L)).toInt()
                    if (diffDays <= reminderDays) {
                        FinanceNotificationHelper.notifyBillReminder(
                            context = applicationContext,
                            billTitle = title,
                            amount = amount,
                            daysRemaining = diffDays
                        )
                    }
                }
            }
            Result.success()
        } catch (_: Exception) {
            Result.success()
        }
    }

    companion object {
        private const val WORK_NAME = "finansim_bill_reminder_periodic"

        fun schedulePeriodicCheck(context: Context) {
            val request = PeriodicWorkRequestBuilder<BillReminderWorker>(
                12, TimeUnit.HOURS
            ).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }
}
