const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function buildVaultProfile(uid, ts) {
  return {
    userId: uid,
    displayName: "Alice",
    pinSalt: "c2FsdF92YWx1ZQ==",
    pinHash: "aGFzaF92YWx1ZV8xMjM0NTY=",
    wrappedVaultKey: "ZW5jcnlwdGVkX3dyYXBwZWRfa2V5",
    wrappedVaultKeyIv: "aXZfMTJfYnl0ZXM=",
    vaultKeyCheckCipher: "Y2hlY2tfY2lwaGVy",
    vaultKeyCheckIv: "Y2hlY2tfaXZfMTI=",
    biometricEnabled: true,
    instantAlertsEnabled: true,
    alertThresholdAmount: 500.0,
    lastSyncLabel: "Az önce senkronize edildi",
    createdAt: ts,
    updatedAt: ts,
  };
}

function buildEncryptedRecord(uid, type, ts) {
  return {
    userId: uid,
    recordType: type,
    encryptedPayload: "ZW5jcnlwdGVkX2ZpbmFuY2lhbF9wYXlsb2FkX2RhdGE=",
    iv: "MTJieXRlaXZkYXRh",
    keyVersion: 1,
    createdAt: ts,
    updatedAt: ts,
  };
}

test("Unauthenticated user cannot read or write profiles or encrypted records", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const ts = new Date(Date.now() - 1000);
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).set(buildVaultProfile(ALICE_UID, ts))
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("transactions").get()
  );
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("transactions")
      .doc("tx_1")
      .set(buildEncryptedRecord(ALICE_UID, "TRANSACTION", ts))
  );
});

test("Authenticated owner can create, read, and partially update their UserVaultProfile", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(buildVaultProfile(ALICE_UID, created))
  );
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      biometricEnabled: false,
      lastSyncLabel: "Güncellendi",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject immutable createdAt modification
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject shadow/ghost field
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isAdmin: true,
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Authenticated owner can CRUD encrypted subcollections (accounts, transactions, budgets, bills, alerts, backups)", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  const pairs = [
    ["accounts", "ACCOUNT"],
    ["transactions", "TRANSACTION"],
    ["budgets", "BUDGET"],
    ["bills", "BILL"],
    ["alerts", "ALERT"],
    ["categories", "CATEGORY"],
  ];

  for (const [col, type] of pairs) {
    const docRef = aliceDb.collection("users").doc(ALICE_UID).collection(col).doc("item_1");
    await assertSucceeds(docRef.set(buildEncryptedRecord(ALICE_UID, type, created)));
    await assertSucceeds(
      aliceDb.collection("users").doc(ALICE_UID).collection(col).get()
    );
    await assertSucceeds(
      docRef.update({
        encryptedPayload: "dXBkYXRlZF9jaXBoZXJ0ZXh0X3BheWxvYWQ=",
        iv: "bmV3MTJieXRlaXY=",
        updatedAt: new Date(Date.now() - 1000),
      })
    );
    // Reject changing recordType or injecting @DocumentId 'id'
    await assertFails(
      docRef.update({
        recordType: "OTHER",
        updatedAt: new Date(Date.now() - 500),
      })
    );
    await assertFails(
      aliceDb
        .collection("users")
        .doc(ALICE_UID)
        .collection(col)
        .doc("item_2")
        .set({
          id: "item_2",
          ...buildEncryptedRecord(ALICE_UID, type, created),
        })
    );
    await assertSucceeds(docRef.delete());
  }

  // Backup snapshot test
  const backupRef = aliceDb.collection("users").doc(ALICE_UID).collection("backups").doc("snap_1");
  await assertSucceeds(
    backupRef.set({
      userId: ALICE_UID,
      encryptedPayload: "ZnVsbF92YXVsdF9lbmNyeXB0ZWRfc25hcHNob3Q=",
      iv: "MTJieXRlaXZkYXRh",
      keyVersion: 1,
      recordCount: 12,
      checksum: "9f86d081884c7d659a2feaa0c55ad015",
      deviceLabel: "Pixel 9 Pro",
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("backups").get());
});

test("Cross-user isolation blocks Bob from reading or writing Alice's vault", async () => {
  const created = new Date(Date.now() - 10000);
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("users").doc(ALICE_UID).set(buildVaultProfile(ALICE_UID, created));
    await db
      .collection("users")
      .doc(ALICE_UID)
      .collection("transactions")
      .doc("tx_1")
      .set(buildEncryptedRecord(ALICE_UID, "TRANSACTION", created));
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("transactions").get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("transactions")
      .doc("tx_1")
      .update({
        encryptedPayload: "aGlqYWNrZWRfcGF5bG9hZA==",
        updatedAt: new Date(Date.now() - 500),
      })
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("transactions")
      .doc("tx_2")
      .set(buildEncryptedRecord(BOB_UID, "TRANSACTION", created))
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("categories").get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("categories")
      .doc("cat_1")
      .set(buildEncryptedRecord(BOB_UID, "CATEGORY", created))
  );
});

test("Future timestamp tampering and wrong recordType are rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const future = new Date(Date.now() + 120000);

  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("accounts")
      .doc("acc_1")
      .set(buildEncryptedRecord(ALICE_UID, "ACCOUNT", future))
  );

  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("accounts")
      .doc("acc_2")
      .set(buildEncryptedRecord(ALICE_UID, "TRANSACTION", new Date(Date.now() - 1000)))
  );
});
